README - Scripts ICONS FIFA FC25
================================

Ce répertoire contient les scripts Lua pour injecter automatiquement les joueurs ICÔNES dans FIFA FC25 via Live Editor.

Structure des dossiers :
-----------------------
scripts/
└── icons/
    ├── main.lua
    └── icons_lua_playerexists_by_version/
        ├── <Version1>/
        │   ├── <playerid>_<Nom>.lua
        │   └── ...
        ├── <Version2>/
        │   └── ...
        └── ...

- **main.lua** : charge et exécute tous les scripts `.lua` par version et par ordre alphabétique.
- **icons_lua_playerexists_by_version/** : sous-dossiers classés par version d’ICÔNE (ex: Base, FUT_Birthday, TOTY, ...). Chaque sous-dossier contient les scripts `.lua` pour chaque joueur.

Installation :
-------------
1. Copier ce dossier `icons/` dans `FIFA Live Editor/scripts/`.
2. Vérifier que la structure est bien :
   ```
   scripts/icons/
   ├── main.lua
   └── icons_lua_playerexists_by_version/
       └── ...
   ```
3. Dans Live Editor, exécuter :
   ```lua
   dofile("scripts/icons/main.lua")
   ```

Utilisation :
------------
- Le script `main.lua` parcourt chaque version et exécute les scripts.
- Chaque script vérifie si le joueur existe (`PlayerExists`) puis crée ou met à jour le joueur avec ses attributs complets.
- Les logs indiquent l’injection de chaque joueur.

Personnalisation :
-----------------
- Modifier `main.lua` pour changer l’ordre ou cibler uniquement certaines versions.
- Adapter les dossiers de version en renommant les répertoires.

Support :
--------
Pour toute question ou problème, contacter Fabrice (Administrateur réseau, CFP Les Charmilles).

---
