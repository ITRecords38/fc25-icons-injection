-- ICON Player Script - PlayerExists Check Only
local playerid = 250

if PlayerExists(playerid) then
    Log("Player with ID: 250 exists")
else
    Log("Player with ID: 250 doesn't exists")
end

local player_data = {
    playerid = "250",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Beckham",
    overallrating = "88",
    preferredposition1 = "12",
    preferredposition2 = "14",
    preferredposition3 = "23",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "77",
    sprintspeed = "82",
    agility = "76",
    balance = "81",
    jumping = "81",
    stamina = "90",
    strength = "75",
    reactions = "90",
    aggression = "78",
    composure = "91",
    interceptions = "68",
    positioning = "88",
    vision = "92",
    ballcontrol = "88",
    crossing = "95",
    dribbling = "84",
    finishing = "80",
    freekickaccuracy = "94",
    headingaccuracy = "71",
    longpassing = "93",
    shortpassing = "90",
    defensiveawareness = "65",
    shotpower = "86",
    longshots = "93",
    standingtackle = "67",
    slidingtackle = "61",
    volleys = "81",
    curve = "95",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "8389283",
    trait2 = "0",
    icontrait1 = "8",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "David",
    lastname = "Beckham",
    surname = "Beckham",
    commonname = "David Beckham",
    playerjerseyname = "Beckham"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - David Beckham (ID: %s).", entry.playerid))
