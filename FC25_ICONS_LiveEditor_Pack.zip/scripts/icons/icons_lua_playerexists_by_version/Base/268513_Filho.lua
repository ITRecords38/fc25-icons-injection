-- ICON Player Script - PlayerExists Check Only
local playerid = 268513

if PlayerExists(playerid) then
    Log("Player with ID: 268513 exists")
else
    Log("Player with ID: 268513 doesn't exists")
end

local player_data = {
    playerid = "268513",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Filho",
    overallrating = "89",
    preferredposition1 = "23",
    preferredposition2 = "12",
    preferredposition3 = "25",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "90",
    agility = "90",
    balance = "85",
    jumping = "83",
    stamina = "82",
    strength = "80",
    reactions = "88",
    aggression = "44",
    composure = "91",
    interceptions = "47",
    positioning = "89",
    vision = "89",
    ballcontrol = "88",
    crossing = "82",
    dribbling = "93",
    finishing = "92",
    freekickaccuracy = "76",
    headingaccuracy = "86",
    longpassing = "78",
    shortpassing = "85",
    defensiveawareness = "43",
    shotpower = "91",
    longshots = "78",
    standingtackle = "45",
    slidingtackle = "43",
    volleys = "86",
    curve = "81",
    penalties = "78",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21233668",
    trait2 = "0",
    icontrait1 = "131072",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Jair Ventura",
    lastname = "Filho",
    surname = "Filho",
    commonname = "Jair Ventura Filho",
    playerjerseyname = "Filho"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Jair Ventura Filho (ID: %s).", entry.playerid))
