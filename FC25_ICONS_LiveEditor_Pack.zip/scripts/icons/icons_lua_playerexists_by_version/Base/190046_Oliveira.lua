-- ICON Player Script - PlayerExists Check Only
local playerid = 190046

if PlayerExists(playerid) then
    Log("Player with ID: 190046 exists")
else
    Log("Player with ID: 190046 doesn't exists")
end

local player_data = {
    playerid = "190046",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Oliveira",
    overallrating = "90",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "86",
    agility = "83",
    balance = "80",
    jumping = "70",
    stamina = "91",
    strength = "83",
    reactions = "85",
    aggression = "76",
    composure = "96",
    interceptions = "33",
    positioning = "87",
    vision = "93",
    ballcontrol = "94",
    crossing = "88",
    dribbling = "91",
    finishing = "87",
    freekickaccuracy = "88",
    headingaccuracy = "87",
    longpassing = "90",
    shortpassing = "89",
    defensiveawareness = "29",
    shotpower = "92",
    longshots = "90",
    standingtackle = "52",
    slidingtackle = "47",
    volleys = "91",
    curve = "88",
    penalties = "89",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "151322658",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Sócrates Vieira de",
    lastname = "Oliveira",
    surname = "Oliveira",
    commonname = "Sócrates Vieira de Oliveira",
    playerjerseyname = "Oliveira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Sócrates Vieira de Oliveira (ID: %s).", entry.playerid))
