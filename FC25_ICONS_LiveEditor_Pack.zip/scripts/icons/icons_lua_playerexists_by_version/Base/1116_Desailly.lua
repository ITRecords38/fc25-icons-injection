-- ICON Player Script - PlayerExists Check Only
local playerid = 1116

if PlayerExists(playerid) then
    Log("Player with ID: 1116 exists")
else
    Log("Player with ID: 1116 doesn't exists")
end

local player_data = {
    playerid = "1116",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Desailly",
    overallrating = "90",
    preferredposition1 = "5",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "82",
    sprintspeed = "85",
    agility = "60",
    balance = "59",
    jumping = "84",
    stamina = "83",
    strength = "92",
    reactions = "89",
    aggression = "93",
    composure = "94",
    interceptions = "91",
    positioning = "52",
    vision = "74",
    ballcontrol = "77",
    crossing = "54",
    dribbling = "62",
    finishing = "42",
    freekickaccuracy = "42",
    headingaccuracy = "89",
    longpassing = "73",
    shortpassing = "77",
    defensiveawareness = "92",
    shotpower = "73",
    longshots = "73",
    standingtackle = "89",
    slidingtackle = "87",
    volleys = "52",
    curve = "50",
    penalties = "55",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "136376336",
    trait2 = "0",
    icontrait1 = "2048",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marcel",
    lastname = "Desailly",
    surname = "Desailly",
    commonname = "Marcel Desailly",
    playerjerseyname = "Desailly"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marcel Desailly (ID: %s).", entry.playerid))
