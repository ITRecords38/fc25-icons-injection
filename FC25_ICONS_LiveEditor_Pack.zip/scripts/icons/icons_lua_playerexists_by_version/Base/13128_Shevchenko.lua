-- ICON Player Script - PlayerExists Check Only
local playerid = 13128

if PlayerExists(playerid) then
    Log("Player with ID: 13128 exists")
else
    Log("Player with ID: 13128 doesn't exists")
end

local player_data = {
    playerid = "13128",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Shevchenko",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "23",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "88",
    sprintspeed = "90",
    agility = "84",
    balance = "85",
    jumping = "85",
    stamina = "80",
    strength = "78",
    reactions = "88",
    aggression = "61",
    composure = "86",
    interceptions = "38",
    positioning = "94",
    vision = "76",
    ballcontrol = "87",
    crossing = "63",
    dribbling = "88",
    finishing = "92",
    freekickaccuracy = "90",
    headingaccuracy = "87",
    longpassing = "65",
    shortpassing = "74",
    defensiveawareness = "24",
    shotpower = "92",
    longshots = "65",
    standingtackle = "33",
    slidingtackle = "30",
    volleys = "88",
    curve = "90",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134938689",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Andriy",
    lastname = "Shevchenko",
    surname = "Shevchenko",
    commonname = "Andriy Shevchenko",
    playerjerseyname = "Shevchenko"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Andriy Shevchenko (ID: %s).", entry.playerid))
