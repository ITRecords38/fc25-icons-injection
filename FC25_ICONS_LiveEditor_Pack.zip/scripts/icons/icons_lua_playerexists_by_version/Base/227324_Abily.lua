-- ICON Player Script - PlayerExists Check Only
local playerid = 227324

if PlayerExists(playerid) then
    Log("Player with ID: 227324 exists")
else
    Log("Player with ID: 227324 doesn't exists")
end

local player_data = {
    playerid = "227324",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Abily",
    overallrating = "92",
    preferredposition1 = "14",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "88",
    sprintspeed = "84",
    agility = "87",
    balance = "85",
    jumping = "70",
    stamina = "88",
    strength = "81",
    reactions = "90",
    aggression = "79",
    composure = "92",
    interceptions = "87",
    positioning = "90",
    vision = "93",
    ballcontrol = "95",
    crossing = "84",
    dribbling = "90",
    finishing = "90",
    freekickaccuracy = "94",
    headingaccuracy = "70",
    longpassing = "93",
    shortpassing = "94",
    defensiveawareness = "84",
    shotpower = "90",
    longshots = "93",
    standingtackle = "86",
    slidingtackle = "83",
    volleys = "94",
    curve = "91",
    penalties = "80",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "33882123",
    trait2 = "0",
    icontrait1 = "288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Camille",
    lastname = "Abily",
    surname = "Abily",
    commonname = "Camille Abily",
    playerjerseyname = "Abily"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Camille Abily (ID: %s).", entry.playerid))
