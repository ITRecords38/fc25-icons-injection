-- ICON Player Script - PlayerExists Check Only
local playerid = 5419

if PlayerExists(playerid) then
    Log("Player with ID: 5419 exists")
else
    Log("Player with ID: 5419 doesn't exists")
end

local player_data = {
    playerid = "5419",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Owen",
    overallrating = "88",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "90",
    sprintspeed = "89",
    agility = "85",
    balance = "84",
    jumping = "83",
    stamina = "79",
    strength = "61",
    reactions = "89",
    aggression = "56",
    composure = "82",
    interceptions = "31",
    positioning = "93",
    vision = "71",
    ballcontrol = "85",
    crossing = "66",
    dribbling = "89",
    finishing = "93",
    freekickaccuracy = "66",
    headingaccuracy = "82",
    longpassing = "52",
    shortpassing = "78",
    defensiveawareness = "28",
    shotpower = "85",
    longshots = "52",
    standingtackle = "30",
    slidingtackle = "30",
    volleys = "88",
    curve = "71",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4325377",
    trait2 = "0",
    icontrait1 = "2",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Michael",
    lastname = "Owen",
    surname = "Owen",
    commonname = "Michael Owen",
    playerjerseyname = "Owen"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Michael Owen (ID: %s).", entry.playerid))
