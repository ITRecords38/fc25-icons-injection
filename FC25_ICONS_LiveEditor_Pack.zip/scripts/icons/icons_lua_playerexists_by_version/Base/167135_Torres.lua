-- ICON Player Script - PlayerExists Check Only
local playerid = 167135

if PlayerExists(playerid) then
    Log("Player with ID: 167135 exists")
else
    Log("Player with ID: 167135 doesn't exists")
end

local player_data = {
    playerid = "167135",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Torres",
    overallrating = "92",
    preferredposition1 = "10",
    preferredposition2 = "3",
    preferredposition3 = "5",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "91",
    agility = "85",
    balance = "80",
    jumping = "84",
    stamina = "90",
    strength = "87",
    reactions = "91",
    aggression = "80",
    composure = "85",
    interceptions = "90",
    positioning = "84",
    vision = "88",
    ballcontrol = "90",
    crossing = "90",
    dribbling = "86",
    finishing = "58",
    freekickaccuracy = "37",
    headingaccuracy = "85",
    longpassing = "83",
    shortpassing = "91",
    defensiveawareness = "88",
    shotpower = "85",
    longshots = "83",
    standingtackle = "90",
    slidingtackle = "89",
    volleys = "46",
    curve = "71",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "8394244",
    trait2 = "0",
    icontrait1 = "8320",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Carlos Alberto",
    lastname = "Torres",
    surname = "Torres",
    commonname = "Carlos Alberto Torres",
    playerjerseyname = "Torres"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Carlos Alberto Torres (ID: %s).", entry.playerid))
