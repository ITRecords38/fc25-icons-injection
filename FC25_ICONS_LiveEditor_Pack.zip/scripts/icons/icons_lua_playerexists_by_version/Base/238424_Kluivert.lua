-- ICON Player Script - PlayerExists Check Only
local playerid = 238424

if PlayerExists(playerid) then
    Log("Player with ID: 238424 exists")
else
    Log("Player with ID: 238424 doesn't exists")
end

local player_data = {
    playerid = "238424",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Kluivert",
    overallrating = "87",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "83",
    sprintspeed = "84",
    agility = "73",
    balance = "74",
    jumping = "88",
    stamina = "76",
    strength = "83",
    reactions = "87",
    aggression = "71",
    composure = "80",
    interceptions = "36",
    positioning = "89",
    vision = "81",
    ballcontrol = "86",
    crossing = "64",
    dribbling = "79",
    finishing = "88",
    freekickaccuracy = "75",
    headingaccuracy = "88",
    longpassing = "75",
    shortpassing = "82",
    defensiveawareness = "35",
    shotpower = "89",
    longshots = "75",
    standingtackle = "33",
    slidingtackle = "38",
    volleys = "82",
    curve = "72",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "19398656",
    trait2 = "0",
    icontrait1 = "16",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Patrick",
    lastname = "Kluivert",
    surname = "Kluivert",
    commonname = "Patrick Kluivert",
    playerjerseyname = "Kluivert"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Patrick Kluivert (ID: %s).", entry.playerid))
