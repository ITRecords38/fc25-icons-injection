-- ICON Player Script - PlayerExists Check Only
local playerid = 4231

if PlayerExists(playerid) then
    Log("Player with ID: 4231 exists")
else
    Log("Player with ID: 4231 doesn't exists")
end

local player_data = {
    playerid = "4231",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ferreira",
    overallrating = "92",
    preferredposition1 = "27",
    preferredposition2 = "16",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "89",
    agility = "91",
    balance = "80",
    jumping = "99",
    stamina = "99",
    strength = "99",
    reactions = "92",
    aggression = "99",
    composure = "93",
    interceptions = "39",
    positioning = "91",
    vision = "89",
    ballcontrol = "94",
    crossing = "88",
    dribbling = "94",
    finishing = "88",
    freekickaccuracy = "92",
    headingaccuracy = "77",
    longpassing = "85",
    shortpassing = "89",
    defensiveawareness = "39",
    shotpower = "93",
    longshots = "85",
    standingtackle = "44",
    slidingtackle = "40",
    volleys = "92",
    curve = "95",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "786445",
    trait2 = "0",
    icontrait1 = "33619968",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Rivaldo Vítor Borba",
    lastname = "Ferreira",
    surname = "Ferreira",
    commonname = "Rivaldo Vítor Borba Ferreira",
    playerjerseyname = "Ferreira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Rivaldo Vítor Borba Ferreira (ID: %s).", entry.playerid))
