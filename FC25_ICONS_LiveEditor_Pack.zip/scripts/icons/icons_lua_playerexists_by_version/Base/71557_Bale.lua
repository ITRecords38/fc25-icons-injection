-- ICON Player Script - PlayerExists Check Only
local playerid = 71557

if PlayerExists(playerid) then
    Log("Player with ID: 71557 exists")
else
    Log("Player with ID: 71557 doesn't exists")
end

local player_data = {
    playerid = "71557",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Bale",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "12",
    preferredposition3 = "23",
    preferredposition4 = "27",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "97",
    sprintspeed = "98",
    agility = "90",
    balance = "88",
    jumping = "87",
    stamina = "90",
    strength = "83",
    reactions = "94",
    aggression = "73",
    composure = "90",
    interceptions = "67",
    positioning = "90",
    vision = "88",
    ballcontrol = "92",
    crossing = "90",
    dribbling = "94",
    finishing = "91",
    freekickaccuracy = "92",
    headingaccuracy = "91",
    longpassing = "88",
    shortpassing = "90",
    defensiveawareness = "68",
    shotpower = "96",
    longshots = "88",
    standingtackle = "68",
    slidingtackle = "62",
    volleys = "91",
    curve = "92",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "138674181",
    trait2 = "0",
    icontrait1 = "33685504",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gareth",
    lastname = "Bale",
    surname = "Bale",
    commonname = "Gareth Bale",
    playerjerseyname = "Bale"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gareth Bale (ID: %s).", entry.playerid))
