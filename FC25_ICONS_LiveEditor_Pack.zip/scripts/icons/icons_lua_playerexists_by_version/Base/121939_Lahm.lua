-- ICON Player Script - PlayerExists Check Only
local playerid = 121939

if PlayerExists(playerid) then
    Log("Player with ID: 121939 exists")
else
    Log("Player with ID: 121939 doesn't exists")
end

local player_data = {
    playerid = "121939",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lahm",
    overallrating = "89",
    preferredposition1 = "3",
    preferredposition2 = "7",
    preferredposition3 = "10",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "85",
    sprintspeed = "83",
    agility = "83",
    balance = "91",
    jumping = "74",
    stamina = "90",
    strength = "61",
    reactions = "89",
    aggression = "67",
    composure = "91",
    interceptions = "89",
    positioning = "72",
    vision = "81",
    ballcontrol = "86",
    crossing = "87",
    dribbling = "78",
    finishing = "64",
    freekickaccuracy = "58",
    headingaccuracy = "66",
    longpassing = "83",
    shortpassing = "84",
    defensiveawareness = "90",
    shotpower = "67",
    longshots = "83",
    standingtackle = "84",
    slidingtackle = "94",
    volleys = "62",
    curve = "83",
    penalties = "74",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2122368",
    trait2 = "0",
    icontrait1 = "4096",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Philipp",
    lastname = "Lahm",
    surname = "Lahm",
    commonname = "Philipp Lahm",
    playerjerseyname = "Lahm"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Philipp Lahm (ID: %s).", entry.playerid))
