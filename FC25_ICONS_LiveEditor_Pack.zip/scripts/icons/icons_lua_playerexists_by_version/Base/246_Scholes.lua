-- ICON Player Script - PlayerExists Check Only
local playerid = 246

if PlayerExists(playerid) then
    Log("Player with ID: 246 exists")
else
    Log("Player with ID: 246 doesn't exists")
end

local player_data = {
    playerid = "246",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Scholes",
    overallrating = "89",
    preferredposition1 = "14",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "83",
    sprintspeed = "81",
    agility = "77",
    balance = "88",
    jumping = "85",
    stamina = "93",
    strength = "72",
    reactions = "88",
    aggression = "88",
    composure = "88",
    interceptions = "85",
    positioning = "91",
    vision = "99",
    ballcontrol = "86",
    crossing = "99",
    dribbling = "75",
    finishing = "83",
    freekickaccuracy = "99",
    headingaccuracy = "85",
    longpassing = "99",
    shortpassing = "99",
    defensiveawareness = "83",
    shotpower = "91",
    longshots = "99",
    standingtackle = "80",
    slidingtackle = "60",
    volleys = "84",
    curve = "99",
    penalties = "72",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "82310",
    trait2 = "0",
    icontrait1 = "32",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Paul",
    lastname = "Scholes",
    surname = "Scholes",
    commonname = "Paul Scholes",
    playerjerseyname = "Scholes"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Paul Scholes (ID: %s).", entry.playerid))
