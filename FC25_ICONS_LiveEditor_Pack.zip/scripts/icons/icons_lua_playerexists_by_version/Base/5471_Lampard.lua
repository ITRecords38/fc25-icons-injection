-- ICON Player Script - PlayerExists Check Only
local playerid = 5471

if PlayerExists(playerid) then
    Log("Player with ID: 5471 exists")
else
    Log("Player with ID: 5471 doesn't exists")
end

local player_data = {
    playerid = "5471",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lampard",
    overallrating = "87",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "75",
    sprintspeed = "78",
    agility = "70",
    balance = "71",
    jumping = "77",
    stamina = "90",
    strength = "78",
    reactions = "87",
    aggression = "73",
    composure = "87",
    interceptions = "76",
    positioning = "83",
    vision = "82",
    ballcontrol = "89",
    crossing = "80",
    dribbling = "84",
    finishing = "87",
    freekickaccuracy = "85",
    headingaccuracy = "68",
    longpassing = "90",
    shortpassing = "91",
    defensiveawareness = "70",
    shotpower = "90",
    longshots = "90",
    standingtackle = "73",
    slidingtackle = "60",
    volleys = "84",
    curve = "82",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18874728",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Frank",
    lastname = "Lampard",
    surname = "Lampard",
    commonname = "Frank Lampard",
    playerjerseyname = "Lampard"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Frank Lampard (ID: %s).", entry.playerid))
