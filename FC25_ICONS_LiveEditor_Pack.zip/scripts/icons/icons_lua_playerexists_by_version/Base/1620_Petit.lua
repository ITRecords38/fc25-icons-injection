-- ICON Player Script - PlayerExists Check Only
local playerid = 1620

if PlayerExists(playerid) then
    Log("Player with ID: 1620 exists")
else
    Log("Player with ID: 1620 doesn't exists")
end

local player_data = {
    playerid = "1620",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Petit",
    overallrating = "87",
    preferredposition1 = "10",
    preferredposition2 = "7",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "75",
    sprintspeed = "78",
    agility = "77",
    balance = "71",
    jumping = "76",
    stamina = "90",
    strength = "86",
    reactions = "82",
    aggression = "88",
    composure = "85",
    interceptions = "87",
    positioning = "79",
    vision = "75",
    ballcontrol = "84",
    crossing = "71",
    dribbling = "70",
    finishing = "69",
    freekickaccuracy = "69",
    headingaccuracy = "77",
    longpassing = "82",
    shortpassing = "88",
    defensiveawareness = "82",
    shotpower = "88",
    longshots = "82",
    standingtackle = "88",
    slidingtackle = "84",
    volleys = "74",
    curve = "71",
    penalties = "62",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2125860",
    trait2 = "0",
    icontrait1 = "8388608",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Emmanuel",
    lastname = "Petit",
    surname = "Petit",
    commonname = "Emmanuel Petit",
    playerjerseyname = "Petit"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Emmanuel Petit (ID: %s).", entry.playerid))
