-- ICON Player Script - PlayerExists Check Only
local playerid = 226369

if PlayerExists(playerid) then
    Log("Player with ID: 226369 exists")
else
    Log("Player with ID: 226369 doesn't exists")
end

local player_data = {
    playerid = "226369",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Schelin",
    overallrating = "90",
    preferredposition1 = "25",
    preferredposition2 = "16",
    preferredposition3 = "27",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "90",
    sprintspeed = "91",
    agility = "81",
    balance = "81",
    jumping = "80",
    stamina = "85",
    strength = "89",
    reactions = "86",
    aggression = "61",
    composure = "88",
    interceptions = "39",
    positioning = "93",
    vision = "85",
    ballcontrol = "90",
    crossing = "78",
    dribbling = "91",
    finishing = "93",
    freekickaccuracy = "76",
    headingaccuracy = "87",
    longpassing = "75",
    shortpassing = "86",
    defensiveawareness = "43",
    shotpower = "84",
    longshots = "75",
    standingtackle = "44",
    slidingtackle = "38",
    volleys = "89",
    curve = "82",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4849666",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lotta",
    lastname = "Schelin",
    surname = "Schelin",
    commonname = "Lotta Schelin",
    playerjerseyname = "Schelin"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lotta Schelin (ID: %s).", entry.playerid))
