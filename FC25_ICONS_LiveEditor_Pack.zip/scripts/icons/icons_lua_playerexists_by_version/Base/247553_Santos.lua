-- ICON Player Script - PlayerExists Check Only
local playerid = 247553

if PlayerExists(playerid) then
    Log("Player with ID: 247553 exists")
else
    Log("Player with ID: 247553 doesn't exists")
end

local player_data = {
    playerid = "247553",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Santos",
    overallrating = "92",
    preferredposition1 = "23",
    preferredposition2 = "12",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "90",
    sprintspeed = "89",
    agility = "93",
    balance = "89",
    jumping = "63",
    stamina = "80",
    strength = "64",
    reactions = "94",
    aggression = "52",
    composure = "89",
    interceptions = "44",
    positioning = "89",
    vision = "92",
    ballcontrol = "94",
    crossing = "93",
    dribbling = "96",
    finishing = "87",
    freekickaccuracy = "88",
    headingaccuracy = "65",
    longpassing = "90",
    shortpassing = "92",
    defensiveawareness = "34",
    shotpower = "84",
    longshots = "90",
    standingtackle = "37",
    slidingtackle = "34",
    volleys = "83",
    curve = "90",
    penalties = "80",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "5505024",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Manuel Franc. dos",
    lastname = "Santos",
    surname = "Santos",
    commonname = "Manuel Franc. dos Santos",
    playerjerseyname = "Santos"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Manuel Franc. dos Santos (ID: %s).", entry.playerid))
