-- ICON Player Script - PlayerExists Check Only
local playerid = 9676

if PlayerExists(playerid) then
    Log("Player with ID: 9676 exists")
else
    Log("Player with ID: 9676 doesn't exists")
end

local player_data = {
    playerid = "9676",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Eto'o",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "92",
    sprintspeed = "92",
    agility = "87",
    balance = "80",
    jumping = "88",
    stamina = "87",
    strength = "78",
    reactions = "92",
    aggression = "75",
    composure = "91",
    interceptions = "41",
    positioning = "91",
    vision = "82",
    ballcontrol = "88",
    crossing = "75",
    dribbling = "87",
    finishing = "93",
    freekickaccuracy = "83",
    headingaccuracy = "81",
    longpassing = "69",
    shortpassing = "82",
    defensiveawareness = "45",
    shotpower = "88",
    longshots = "69",
    standingtackle = "39",
    slidingtackle = "34",
    volleys = "87",
    curve = "79",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17367297",
    trait2 = "0",
    icontrait1 = "4194304",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Samuel",
    lastname = "Eto'o",
    surname = "Eto'o",
    commonname = "Samuel Eto'o",
    playerjerseyname = "Eto'o"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Samuel Eto'o (ID: %s).", entry.playerid))
