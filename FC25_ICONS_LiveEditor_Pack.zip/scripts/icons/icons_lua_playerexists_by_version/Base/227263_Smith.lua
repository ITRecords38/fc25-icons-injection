-- ICON Player Script - PlayerExists Check Only
local playerid = 227263

if PlayerExists(playerid) then
    Log("Player with ID: 227263 exists")
else
    Log("Player with ID: 227263 doesn't exists")
end

local player_data = {
    playerid = "227263",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Smith",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "88",
    agility = "82",
    balance = "83",
    jumping = "79",
    stamina = "84",
    strength = "82",
    reactions = "90",
    aggression = "57",
    composure = "89",
    interceptions = "36",
    positioning = "91",
    vision = "87",
    ballcontrol = "90",
    crossing = "83",
    dribbling = "90",
    finishing = "92",
    freekickaccuracy = "91",
    headingaccuracy = "87",
    longpassing = "71",
    shortpassing = "87",
    defensiveawareness = "35",
    shotpower = "87",
    longshots = "71",
    standingtackle = "51",
    slidingtackle = "47",
    volleys = "86",
    curve = "90",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134742033",
    trait2 = "0",
    icontrait1 = "8",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Kelly",
    lastname = "Smith",
    surname = "Smith",
    commonname = "Kelly Smith",
    playerjerseyname = "Smith"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Kelly Smith (ID: %s).", entry.playerid))
