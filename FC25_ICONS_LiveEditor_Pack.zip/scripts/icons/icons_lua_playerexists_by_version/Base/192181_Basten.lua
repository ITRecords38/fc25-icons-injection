-- ICON Player Script - PlayerExists Check Only
local playerid = 192181

if PlayerExists(playerid) then
    Log("Player with ID: 192181 exists")
else
    Log("Player with ID: 192181 doesn't exists")
end

local player_data = {
    playerid = "192181",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Basten",
    overallrating = "91",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "82",
    sprintspeed = "85",
    agility = "84",
    balance = "73",
    jumping = "83",
    stamina = "76",
    strength = "80",
    reactions = "93",
    aggression = "50",
    composure = "90",
    interceptions = "45",
    positioning = "94",
    vision = "75",
    ballcontrol = "91",
    crossing = "72",
    dribbling = "86",
    finishing = "95",
    freekickaccuracy = "76",
    headingaccuracy = "88",
    longpassing = "64",
    shortpassing = "78",
    defensiveawareness = "24",
    shotpower = "92",
    longshots = "64",
    standingtackle = "31",
    slidingtackle = "30",
    volleys = "96",
    curve = "76",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17367041",
    trait2 = "0",
    icontrait1 = "33554432",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marco van",
    lastname = "Basten",
    surname = "Basten",
    commonname = "Marco van Basten",
    playerjerseyname = "Basten"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marco van Basten (ID: %s).", entry.playerid))
