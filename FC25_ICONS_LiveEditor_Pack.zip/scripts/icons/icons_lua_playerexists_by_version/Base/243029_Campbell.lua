-- ICON Player Script - PlayerExists Check Only
local playerid = 243029

if PlayerExists(playerid) then
    Log("Player with ID: 243029 exists")
else
    Log("Player with ID: 243029 doesn't exists")
end

local player_data = {
    playerid = "243029",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Campbell",
    overallrating = "86",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "77",
    sprintspeed = "84",
    agility = "52",
    balance = "55",
    jumping = "86",
    stamina = "78",
    strength = "93",
    reactions = "85",
    aggression = "86",
    composure = "82",
    interceptions = "86",
    positioning = "34",
    vision = "55",
    ballcontrol = "65",
    crossing = "51",
    dribbling = "50",
    finishing = "42",
    freekickaccuracy = "30",
    headingaccuracy = "89",
    longpassing = "66",
    shortpassing = "73",
    defensiveawareness = "88",
    shotpower = "60",
    longshots = "66",
    standingtackle = "85",
    slidingtackle = "90",
    volleys = "40",
    curve = "37",
    penalties = "48",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134252560",
    trait2 = "0",
    icontrait1 = "16384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Sol",
    lastname = "Campbell",
    surname = "Campbell",
    commonname = "Sol Campbell",
    playerjerseyname = "Campbell"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Sol Campbell (ID: %s).", entry.playerid))
