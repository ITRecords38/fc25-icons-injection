-- ICON Player Script - PlayerExists Check Only
local playerid = 275276

if PlayerExists(playerid) then
    Log("Player with ID: 275276 exists")
else
    Log("Player with ID: 275276 doesn't exists")
end

local player_data = {
    playerid = "275276",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Prinz",
    overallrating = "93",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "84",
    sprintspeed = "87",
    agility = "80",
    balance = "80",
    jumping = "85",
    stamina = "84",
    strength = "96",
    reactions = "91",
    aggression = "83",
    composure = "90",
    interceptions = "46",
    positioning = "95",
    vision = "85",
    ballcontrol = "89",
    crossing = "71",
    dribbling = "84",
    finishing = "95",
    freekickaccuracy = "83",
    headingaccuracy = "95",
    longpassing = "71",
    shortpassing = "88",
    defensiveawareness = "47",
    shotpower = "95",
    longshots = "71",
    standingtackle = "54",
    slidingtackle = "42",
    volleys = "92",
    curve = "78",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17367061",
    trait2 = "0",
    icontrait1 = "136314880",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Birgit",
    lastname = "Prinz",
    surname = "Prinz",
    commonname = "Birgit Prinz",
    playerjerseyname = "Prinz"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Birgit Prinz (ID: %s).", entry.playerid))
