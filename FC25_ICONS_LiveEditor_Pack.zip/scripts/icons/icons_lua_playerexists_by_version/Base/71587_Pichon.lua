-- ICON Player Script - PlayerExists Check Only
local playerid = 71587

if PlayerExists(playerid) then
    Log("Player with ID: 71587 exists")
else
    Log("Player with ID: 71587 doesn't exists")
end

local player_data = {
    playerid = "71587",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Pichon",
    overallrating = "88",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "82",
    sprintspeed = "87",
    agility = "87",
    balance = "85",
    jumping = "82",
    stamina = "88",
    strength = "74",
    reactions = "87",
    aggression = "58",
    composure = "86",
    interceptions = "41",
    positioning = "91",
    vision = "82",
    ballcontrol = "90",
    crossing = "73",
    dribbling = "88",
    finishing = "92",
    freekickaccuracy = "79",
    headingaccuracy = "80",
    longpassing = "75",
    shortpassing = "85",
    defensiveawareness = "37",
    shotpower = "84",
    longshots = "75",
    standingtackle = "43",
    slidingtackle = "33",
    volleys = "92",
    curve = "82",
    penalties = "82",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17629185",
    trait2 = "0",
    icontrait1 = "33554432",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marinette",
    lastname = "Pichon",
    surname = "Pichon",
    commonname = "Marinette Pichon",
    playerjerseyname = "Pichon"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marinette Pichon (ID: %s).", entry.playerid))
