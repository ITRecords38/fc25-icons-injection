-- ICON Player Script - PlayerExists Check Only
local playerid = 239261

if PlayerExists(playerid) then
    Log("Player with ID: 239261 exists")
else
    Log("Player with ID: 239261 doesn't exists")
end

local player_data = {
    playerid = "239261",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Larsson",
    overallrating = "86",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "89",
    sprintspeed = "85",
    agility = "87",
    balance = "79",
    jumping = "89",
    stamina = "84",
    strength = "63",
    reactions = "89",
    aggression = "71",
    composure = "80",
    interceptions = "41",
    positioning = "87",
    vision = "71",
    ballcontrol = "83",
    crossing = "66",
    dribbling = "80",
    finishing = "91",
    freekickaccuracy = "79",
    headingaccuracy = "93",
    longpassing = "71",
    shortpassing = "75",
    defensiveawareness = "33",
    shotpower = "80",
    longshots = "71",
    standingtackle = "45",
    slidingtackle = "44",
    volleys = "85",
    curve = "85",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4194305",
    trait2 = "0",
    icontrait1 = "2",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Henrik",
    lastname = "Larsson",
    surname = "Larsson",
    commonname = "Henrik Larsson",
    playerjerseyname = "Larsson"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Henrik Larsson (ID: %s).", entry.playerid))
