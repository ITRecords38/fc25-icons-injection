-- ICON Player Script - PlayerExists Check Only
local playerid = 1179

if PlayerExists(playerid) then
    Log("Player with ID: 1179 exists")
else
    Log("Player with ID: 1179 doesn't exists")
end

local player_data = {
    playerid = "1179",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Buffon",
    overallrating = "91",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "81",
    sprintspeed = "86",
    agility = "87",
    balance = "88",
    jumping = "89",
    stamina = "80",
    strength = "91",
    reactions = "88",
    aggression = "82",
    composure = "85",
    interceptions = "91",
    positioning = "90",
    vision = "90",
    ballcontrol = "87",
    crossing = "82",
    dribbling = "87",
    finishing = "90",
    freekickaccuracy = "70",
    headingaccuracy = "91",
    longpassing = "85",
    shortpassing = "88",
    defensiveawareness = "87",
    shotpower = "94",
    longshots = "85",
    standingtackle = "90",
    slidingtackle = "81",
    volleys = "86",
    curve = "74",
    penalties = "93",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "100663315",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gianluigi",
    lastname = "Buffon",
    surname = "Buffon",
    commonname = "Gianluigi Buffon",
    playerjerseyname = "Buffon"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gianluigi Buffon (ID: %s).", entry.playerid))
