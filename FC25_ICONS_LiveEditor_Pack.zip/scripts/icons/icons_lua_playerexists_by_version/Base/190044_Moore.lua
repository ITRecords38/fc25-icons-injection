-- ICON Player Script - PlayerExists Check Only
local playerid = 190044

if PlayerExists(playerid) then
    Log("Player with ID: 190044 exists")
else
    Log("Player with ID: 190044 doesn't exists")
end

local player_data = {
    playerid = "190044",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Moore",
    overallrating = "90",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "69",
    sprintspeed = "71",
    agility = "81",
    balance = "82",
    jumping = "83",
    stamina = "88",
    strength = "82",
    reactions = "92",
    aggression = "79",
    composure = "93",
    interceptions = "91",
    positioning = "60",
    vision = "79",
    ballcontrol = "85",
    crossing = "71",
    dribbling = "65",
    finishing = "54",
    freekickaccuracy = "64",
    headingaccuracy = "87",
    longpassing = "88",
    shortpassing = "90",
    defensiveawareness = "93",
    shotpower = "75",
    longshots = "88",
    standingtackle = "93",
    slidingtackle = "91",
    volleys = "62",
    curve = "71",
    penalties = "74",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2100352",
    trait2 = "0",
    icontrait1 = "8192",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Bobby",
    lastname = "Moore",
    surname = "Moore",
    commonname = "Bobby Moore",
    playerjerseyname = "Moore"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Bobby Moore (ID: %s).", entry.playerid))
