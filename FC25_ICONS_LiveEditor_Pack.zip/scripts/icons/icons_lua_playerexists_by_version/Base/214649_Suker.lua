-- ICON Player Script - PlayerExists Check Only
local playerid = 214649

if PlayerExists(playerid) then
    Log("Player with ID: 214649 exists")
else
    Log("Player with ID: 214649 doesn't exists")
end

local player_data = {
    playerid = "214649",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Šuker",
    overallrating = "87",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "82",
    sprintspeed = "84",
    agility = "85",
    balance = "84",
    jumping = "77",
    stamina = "85",
    strength = "72",
    reactions = "88",
    aggression = "68",
    composure = "90",
    interceptions = "43",
    positioning = "90",
    vision = "80",
    ballcontrol = "88",
    crossing = "74",
    dribbling = "89",
    finishing = "90",
    freekickaccuracy = "85",
    headingaccuracy = "80",
    longpassing = "68",
    shortpassing = "84",
    defensiveawareness = "39",
    shotpower = "87",
    longshots = "68",
    standingtackle = "39",
    slidingtackle = "31",
    volleys = "92",
    curve = "87",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "65538",
    trait2 = "0",
    icontrait1 = "16777216",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Davor",
    lastname = "Šuker",
    surname = "Šuker",
    commonname = "Davor Šuker",
    playerjerseyname = "Šuker"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Davor Šuker (ID: %s).", entry.playerid))
