-- ICON Player Script - PlayerExists Check Only
local playerid = 230025

if PlayerExists(playerid) then
    Log("Player with ID: 230025 exists")
else
    Log("Player with ID: 230025 doesn't exists")
end

local player_data = {
    playerid = "230025",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Charlton",
    overallrating = "92",
    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "91",
    sprintspeed = "90",
    agility = "91",
    balance = "93",
    jumping = "85",
    stamina = "86",
    strength = "68",
    reactions = "93",
    aggression = "72",
    composure = "93",
    interceptions = "48",
    positioning = "92",
    vision = "91",
    ballcontrol = "89",
    crossing = "82",
    dribbling = "92",
    finishing = "91",
    freekickaccuracy = "88",
    headingaccuracy = "78",
    longpassing = "89",
    shortpassing = "88",
    defensiveawareness = "50",
    shotpower = "93",
    longshots = "89",
    standingtackle = "47",
    slidingtackle = "31",
    volleys = "87",
    curve = "84",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21561504",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Bobby",
    lastname = "Charlton",
    surname = "Charlton",
    commonname = "Bobby Charlton",
    playerjerseyname = "Charlton"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Bobby Charlton (ID: %s).", entry.playerid))
