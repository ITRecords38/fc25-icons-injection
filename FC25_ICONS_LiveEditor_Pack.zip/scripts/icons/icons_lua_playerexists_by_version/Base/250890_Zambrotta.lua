-- ICON Player Script - PlayerExists Check Only
local playerid = 250890

if PlayerExists(playerid) then
    Log("Player with ID: 250890 exists")
else
    Log("Player with ID: 250890 doesn't exists")
end

local player_data = {
    playerid = "250890",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Zambrotta",
    overallrating = "86",
    preferredposition1 = "3",
    preferredposition2 = "7",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "86",
    sprintspeed = "87",
    agility = "75",
    balance = "73",
    jumping = "76",
    stamina = "86",
    strength = "80",
    reactions = "84",
    aggression = "84",
    composure = "83",
    interceptions = "84",
    positioning = "78",
    vision = "77",
    ballcontrol = "84",
    crossing = "85",
    dribbling = "81",
    finishing = "60",
    freekickaccuracy = "60",
    headingaccuracy = "76",
    longpassing = "79",
    shortpassing = "81",
    defensiveawareness = "82",
    shotpower = "80",
    longshots = "79",
    standingtackle = "87",
    slidingtackle = "86",
    volleys = "69",
    curve = "80",
    penalties = "69",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2115584",
    trait2 = "0",
    icontrait1 = "8388608",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gianluca",
    lastname = "Zambrotta",
    surname = "Zambrotta",
    commonname = "Gianluca Zambrotta",
    playerjerseyname = "Zambrotta"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gianluca Zambrotta (ID: %s).", entry.playerid))
