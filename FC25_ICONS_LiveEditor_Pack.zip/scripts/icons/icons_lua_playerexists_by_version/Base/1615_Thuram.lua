-- ICON Player Script - PlayerExists Check Only
local playerid = 1615

if PlayerExists(playerid) then
    Log("Player with ID: 1615 exists")
else
    Log("Player with ID: 1615 doesn't exists")
end

local player_data = {
    playerid = "1615",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Thuram",
    overallrating = "88",
    preferredposition1 = "3",
    preferredposition2 = "5",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "89",
    sprintspeed = "88",
    agility = "77",
    balance = "83",
    jumping = "86",
    stamina = "89",
    strength = "90",
    reactions = "83",
    aggression = "90",
    composure = "84",
    interceptions = "88",
    positioning = "68",
    vision = "74",
    ballcontrol = "77",
    crossing = "74",
    dribbling = "71",
    finishing = "57",
    freekickaccuracy = "42",
    headingaccuracy = "87",
    longpassing = "78",
    shortpassing = "83",
    defensiveawareness = "92",
    shotpower = "63",
    longshots = "78",
    standingtackle = "88",
    slidingtackle = "94",
    volleys = "55",
    curve = "63",
    penalties = "42",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134261760",
    trait2 = "0",
    icontrait1 = "16384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lilian",
    lastname = "Thuram",
    surname = "Thuram",
    commonname = "Lilian Thuram",
    playerjerseyname = "Thuram"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lilian Thuram (ID: %s).", entry.playerid))
