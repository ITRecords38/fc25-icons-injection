-- ICON Player Script - PlayerExists Check Only
local playerid = 71608

if PlayerExists(playerid) then
    Log("Player with ID: 71608 exists")
else
    Log("Player with ID: 71608 doesn't exists")
end

local player_data = {
    playerid = "71608",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Foudy",
    overallrating = "90",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "78",
    sprintspeed = "82",
    agility = "83",
    balance = "85",
    jumping = "78",
    stamina = "92",
    strength = "76",
    reactions = "89",
    aggression = "80",
    composure = "86",
    interceptions = "78",
    positioning = "88",
    vision = "92",
    ballcontrol = "88",
    crossing = "81",
    dribbling = "87",
    finishing = "84",
    freekickaccuracy = "79",
    headingaccuracy = "77",
    longpassing = "90",
    shortpassing = "92",
    defensiveawareness = "73",
    shotpower = "83",
    longshots = "90",
    standingtackle = "79",
    slidingtackle = "71",
    volleys = "67",
    curve = "78",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2097312",
    trait2 = "0",
    icontrait1 = "8388608",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Julie",
    lastname = "Foudy",
    surname = "Foudy",
    commonname = "Julie Foudy",
    playerjerseyname = "Foudy"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Julie Foudy (ID: %s).", entry.playerid))
