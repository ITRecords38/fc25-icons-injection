-- ICON Player Script - PlayerExists Check Only
local playerid = 1201

if PlayerExists(playerid) then
    Log("Player with ID: 1201 exists")
else
    Log("Player with ID: 1201 doesn't exists")
end

local player_data = {
    playerid = "1201",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Zola",
    overallrating = "87",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "87",
    sprintspeed = "83",
    agility = "82",
    balance = "84",
    jumping = "51",
    stamina = "74",
    strength = "59",
    reactions = "88",
    aggression = "62",
    composure = "83",
    interceptions = "32",
    positioning = "87",
    vision = "85",
    ballcontrol = "89",
    crossing = "82",
    dribbling = "91",
    finishing = "90",
    freekickaccuracy = "90",
    headingaccuracy = "62",
    longpassing = "81",
    shortpassing = "87",
    defensiveawareness = "40",
    shotpower = "88",
    longshots = "81",
    standingtackle = "43",
    slidingtackle = "36",
    volleys = "81",
    curve = "87",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17104904",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gianfranco",
    lastname = "Zola",
    surname = "Zola",
    commonname = "Gianfranco Zola",
    playerjerseyname = "Zola"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gianfranco Zola (ID: %s).", entry.playerid))
