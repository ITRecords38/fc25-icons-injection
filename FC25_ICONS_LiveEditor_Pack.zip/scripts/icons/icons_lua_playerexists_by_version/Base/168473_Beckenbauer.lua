-- ICON Player Script - PlayerExists Check Only
local playerid = 168473

if PlayerExists(playerid) then
    Log("Player with ID: 168473 exists")
else
    Log("Player with ID: 168473 doesn't exists")
end

local player_data = {
    playerid = "168473",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Beckenbauer",
    overallrating = "92",
    preferredposition1 = "5",
    preferredposition2 = "10",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "83",
    sprintspeed = "81",
    agility = "80",
    balance = "77",
    jumping = "95",
    stamina = "85",
    strength = "81",
    reactions = "92",
    aggression = "73",
    composure = "89",
    interceptions = "96",
    positioning = "75",
    vision = "88",
    ballcontrol = "91",
    crossing = "75",
    dribbling = "79",
    finishing = "70",
    freekickaccuracy = "80",
    headingaccuracy = "88",
    longpassing = "95",
    shortpassing = "94",
    defensiveawareness = "95",
    shotpower = "75",
    longshots = "95",
    standingtackle = "91",
    slidingtackle = "90",
    volleys = "68",
    curve = "76",
    penalties = "66",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "16855072",
    trait2 = "0",
    icontrait1 = "128",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Franz",
    lastname = "Beckenbauer",
    surname = "Beckenbauer",
    commonname = "Franz Beckenbauer",
    playerjerseyname = "Beckenbauer"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Franz Beckenbauer (ID: %s).", entry.playerid))
