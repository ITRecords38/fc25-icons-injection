-- ICON Player Script - PlayerExists Check Only
local playerid = 214267

if PlayerExists(playerid) then
    Log("Player with ID: 214267 exists")
else
    Log("Player with ID: 214267 doesn't exists")
end

local player_data = {
    playerid = "214267",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lineker",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "85",
    agility = "81",
    balance = "77",
    jumping = "76",
    stamina = "83",
    strength = "78",
    reactions = "90",
    aggression = "55",
    composure = "85",
    interceptions = "42",
    positioning = "92",
    vision = "70",
    ballcontrol = "87",
    crossing = "59",
    dribbling = "83",
    finishing = "93",
    freekickaccuracy = "65",
    headingaccuracy = "87",
    longpassing = "68",
    shortpassing = "81",
    defensiveawareness = "29",
    shotpower = "87",
    longshots = "68",
    standingtackle = "35",
    slidingtackle = "33",
    volleys = "89",
    curve = "62",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "0",
    trait2 = "0",
    icontrait1 = "2",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gary",
    lastname = "Lineker",
    surname = "Lineker",
    commonname = "Gary Lineker",
    playerjerseyname = "Lineker"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gary Lineker (ID: %s).", entry.playerid))
