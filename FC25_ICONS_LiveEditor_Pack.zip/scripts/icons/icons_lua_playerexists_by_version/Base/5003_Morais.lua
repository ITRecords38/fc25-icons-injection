-- ICON Player Script - PlayerExists Check Only
local playerid = 5003

if PlayerExists(playerid) then
    Log("Player with ID: 5003 exists")
else
    Log("Player with ID: 5003 doesn't exists")
end

local player_data = {
    playerid = "5003",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Morais",
    overallrating = "91",
    preferredposition1 = "3",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "3",
    acceleration = "91",
    sprintspeed = "90",
    agility = "75",
    balance = "79",
    jumping = "80",
    stamina = "92",
    strength = "83",
    reactions = "89",
    aggression = "74",
    composure = "87",
    interceptions = "90",
    positioning = "71",
    vision = "82",
    ballcontrol = "87",
    crossing = "91",
    dribbling = "86",
    finishing = "44",
    freekickaccuracy = "61",
    headingaccuracy = "78",
    longpassing = "71",
    shortpassing = "87",
    defensiveawareness = "88",
    shotpower = "65",
    longshots = "71",
    standingtackle = "90",
    slidingtackle = "84",
    volleys = "60",
    curve = "75",
    penalties = "71",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17040384",
    trait2 = "0",
    icontrait1 = "8388608",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marcos de",
    lastname = "Morais",
    surname = "Morais",
    commonname = "Marcos de Morais",
    playerjerseyname = "Morais"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marcos de Morais (ID: %s).", entry.playerid))
