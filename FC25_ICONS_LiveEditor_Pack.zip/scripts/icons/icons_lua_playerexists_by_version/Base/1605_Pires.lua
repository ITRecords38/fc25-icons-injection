-- ICON Player Script - PlayerExists Check Only
local playerid = 1605

if PlayerExists(playerid) then
    Log("Player with ID: 1605 exists")
else
    Log("Player with ID: 1605 doesn't exists")
end

local player_data = {
    playerid = "1605",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Pirès",
    overallrating = "89",
    preferredposition1 = "18",
    preferredposition2 = "12",
    preferredposition3 = "16",
    preferredposition4 = "27",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "89",
    sprintspeed = "88",
    agility = "84",
    balance = "86",
    jumping = "75",
    stamina = "84",
    strength = "65",
    reactions = "85",
    aggression = "46",
    composure = "85",
    interceptions = "46",
    positioning = "89",
    vision = "90",
    ballcontrol = "91",
    crossing = "86",
    dribbling = "91",
    finishing = "86",
    freekickaccuracy = "82",
    headingaccuracy = "58",
    longpassing = "85",
    shortpassing = "85",
    defensiveawareness = "33",
    shotpower = "80",
    longshots = "85",
    standingtackle = "38",
    slidingtackle = "36",
    volleys = "80",
    curve = "88",
    penalties = "83",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "8323104",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Robert",
    lastname = "Pirès",
    surname = "Pirès",
    commonname = "Robert Pirès",
    playerjerseyname = "Pirès"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Robert Pirès (ID: %s).", entry.playerid))
