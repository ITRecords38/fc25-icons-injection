-- ICON Player Script - PlayerExists Check Only
local playerid = 226293

if PlayerExists(playerid) then
    Log("Player with ID: 226293 exists")
else
    Log("Player with ID: 226293 doesn't exists")
end

local player_data = {
    playerid = "226293",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Angerer",
    overallrating = "92",
    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "0",
    weakfootabilitytypecode = "3",
    acceleration = "60",
    sprintspeed = "57",
    agility = "61",
    balance = "61",
    jumping = "73",
    stamina = "43",
    strength = "70",
    reactions = "93",
    aggression = "52",
    composure = "64",
    interceptions = "29",
    positioning = "12",
    vision = "63",
    ballcontrol = "26",
    crossing = "12",
    dribbling = "13",
    finishing = "12",
    freekickaccuracy = "18",
    headingaccuracy = "9",
    longpassing = "32",
    shortpassing = "35",
    defensiveawareness = "27",
    shotpower = "59",
    longshots = "32",
    standingtackle = "21",
    slidingtackle = "26",
    volleys = "11",
    curve = "20",
    penalties = "23",
    gkdiving = "92",
    gkhandling = "88",
    gkkicking = "79",
    gkreflexes = "94",
    gkpositioning = "92",
    trait1 = "0",
    trait2 = "1",
    icontrait1 = "0",
    icontrait2 = "4",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Nadine",
    lastname = "Angerer",
    surname = "Angerer",
    commonname = "Nadine Angerer",
    playerjerseyname = "Angerer"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Nadine Angerer (ID: %s).", entry.playerid))
