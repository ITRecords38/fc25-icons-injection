-- ICON Player Script - PlayerExists Check Only
local playerid = 248146

if PlayerExists(playerid) then
    Log("Player with ID: 248146 exists")
else
    Log("Player with ID: 248146 doesn't exists")
end

local player_data = {
    playerid = "248146",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Wright",
    overallrating = "87",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "87",
    sprintspeed = "88",
    agility = "82",
    balance = "78",
    jumping = "75",
    stamina = "86",
    strength = "73",
    reactions = "86",
    aggression = "70",
    composure = "87",
    interceptions = "35",
    positioning = "88",
    vision = "73",
    ballcontrol = "85",
    crossing = "56",
    dribbling = "78",
    finishing = "91",
    freekickaccuracy = "65",
    headingaccuracy = "85",
    longpassing = "64",
    shortpassing = "78",
    defensiveawareness = "31",
    shotpower = "87",
    longshots = "64",
    standingtackle = "38",
    slidingtackle = "33",
    volleys = "85",
    curve = "66",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4849664",
    trait2 = "0",
    icontrait1 = "2",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ian",
    lastname = "Wright",
    surname = "Wright",
    commonname = "Ian Wright",
    playerjerseyname = "Wright"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ian Wright (ID: %s).", entry.playerid))
