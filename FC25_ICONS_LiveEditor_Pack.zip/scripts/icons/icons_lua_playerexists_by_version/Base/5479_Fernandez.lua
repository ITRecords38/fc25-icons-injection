-- ICON Player Script - PlayerExists Check Only
local playerid = 5479

if PlayerExists(playerid) then
    Log("Player with ID: 5479 exists")
else
    Log("Player with ID: 5479 doesn't exists")
end

local player_data = {
    playerid = "5479",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Fernández",
    overallrating = "93",
    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "0",
    weakfootabilitytypecode = "4",
    acceleration = "74",
    sprintspeed = "70",
    agility = "66",
    balance = "56",
    jumping = "81",
    stamina = "44",
    strength = "69",
    reactions = "89",
    aggression = "30",
    composure = "68",
    interceptions = "27",
    positioning = "18",
    vision = "69",
    ballcontrol = "33",
    crossing = "29",
    dribbling = "29",
    finishing = "31",
    freekickaccuracy = "27",
    headingaccuracy = "37",
    longpassing = "56",
    shortpassing = "59",
    defensiveawareness = "28",
    shotpower = "63",
    longshots = "56",
    standingtackle = "16",
    slidingtackle = "21",
    volleys = "27",
    curve = "24",
    penalties = "29",
    gkdiving = "93",
    gkhandling = "91",
    gkkicking = "89",
    gkreflexes = "96",
    gkpositioning = "91",
    trait1 = "268435648",
    trait2 = "11",
    icontrait1 = "536870912",
    icontrait2 = "4",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Iker Casillas",
    lastname = "Fernández",
    surname = "Fernández",
    commonname = "Iker Casillas Fernández",
    playerjerseyname = "Fernández"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Iker Casillas Fernández (ID: %s).", entry.playerid))
