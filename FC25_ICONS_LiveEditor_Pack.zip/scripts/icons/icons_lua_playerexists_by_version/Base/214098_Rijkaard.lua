-- ICON Player Script - PlayerExists Check Only
local playerid = 214098

if PlayerExists(playerid) then
    Log("Player with ID: 214098 exists")
else
    Log("Player with ID: 214098 doesn't exists")
end

local player_data = {
    playerid = "214098",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Rijkaard",
    overallrating = "87",
    preferredposition1 = "10",
    preferredposition2 = "5",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "75",
    sprintspeed = "78",
    agility = "70",
    balance = "65",
    jumping = "80",
    stamina = "89",
    strength = "89",
    reactions = "85",
    aggression = "75",
    composure = "89",
    interceptions = "88",
    positioning = "69",
    vision = "82",
    ballcontrol = "87",
    crossing = "74",
    dribbling = "72",
    finishing = "66",
    freekickaccuracy = "57",
    headingaccuracy = "84",
    longpassing = "84",
    shortpassing = "87",
    defensiveawareness = "86",
    shotpower = "83",
    longshots = "84",
    standingtackle = "88",
    slidingtackle = "84",
    volleys = "67",
    curve = "53",
    penalties = "75",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "16787492",
    trait2 = "0",
    icontrait1 = "4096",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Frank",
    lastname = "Rijkaard",
    surname = "Rijkaard",
    commonname = "Frank Rijkaard",
    playerjerseyname = "Rijkaard"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Frank Rijkaard (ID: %s).", entry.playerid))
