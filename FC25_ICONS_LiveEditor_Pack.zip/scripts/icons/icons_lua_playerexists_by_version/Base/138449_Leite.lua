-- ICON Player Script - PlayerExists Check Only
local playerid = 138449

if PlayerExists(playerid) then
    Log("Player with ID: 138449 exists")
else
    Log("Player with ID: 138449 doesn't exists")
end

local player_data = {
    playerid = "138449",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Leite",
    overallrating = "89",
    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "90",
    sprintspeed = "88",
    agility = "86",
    balance = "84",
    jumping = "55",
    stamina = "85",
    strength = "76",
    reactions = "88",
    aggression = "47",
    composure = "93",
    interceptions = "46",
    positioning = "84",
    vision = "89",
    ballcontrol = "90",
    crossing = "85",
    dribbling = "91",
    finishing = "84",
    freekickaccuracy = "80",
    headingaccuracy = "60",
    longpassing = "82",
    shortpassing = "88",
    defensiveawareness = "44",
    shotpower = "86",
    longshots = "82",
    standingtackle = "37",
    slidingtackle = "35",
    volleys = "84",
    curve = "87",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4194337",
    trait2 = "0",
    icontrait1 = "131072",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ricardo Izecson dos Santos",
    lastname = "Leite",
    surname = "Leite",
    commonname = "Ricardo Izecson dos Santos Leite",
    playerjerseyname = "Leite"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ricardo Izecson dos Santos Leite (ID: %s).", entry.playerid))
