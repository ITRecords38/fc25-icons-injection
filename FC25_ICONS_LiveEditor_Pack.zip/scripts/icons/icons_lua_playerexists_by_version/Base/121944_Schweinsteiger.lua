-- ICON Player Script - PlayerExists Check Only
local playerid = 121944

if PlayerExists(playerid) then
    Log("Player with ID: 121944 exists")
else
    Log("Player with ID: 121944 doesn't exists")
end

local player_data = {
    playerid = "121944",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Schweinsteiger",
    overallrating = "88",
    preferredposition1 = "14",
    preferredposition2 = "16",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "73",
    sprintspeed = "78",
    agility = "75",
    balance = "79",
    jumping = "82",
    stamina = "89",
    strength = "80",
    reactions = "90",
    aggression = "84",
    composure = "86",
    interceptions = "86",
    positioning = "83",
    vision = "87",
    ballcontrol = "87",
    crossing = "81",
    dribbling = "81",
    finishing = "78",
    freekickaccuracy = "82",
    headingaccuracy = "78",
    longpassing = "87",
    shortpassing = "89",
    defensiveawareness = "82",
    shotpower = "91",
    longshots = "87",
    standingtackle = "83",
    slidingtackle = "81",
    volleys = "85",
    curve = "84",
    penalties = "75",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10489860",
    trait2 = "0",
    icontrait1 = "128",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Bastian",
    lastname = "Schweinsteiger",
    surname = "Schweinsteiger",
    commonname = "Bastian Schweinsteiger",
    playerjerseyname = "Schweinsteiger"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Bastian Schweinsteiger (ID: %s).", entry.playerid))
