-- ICON Player Script - PlayerExists Check Only
local playerid = 238435

if PlayerExists(playerid) then
    Log("Player with ID: 238435 exists")
else
    Log("Player with ID: 238435 doesn't exists")
end

local player_data = {
    playerid = "238435",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Matthäus",
    overallrating = "90",
    preferredposition1 = "14",
    preferredposition2 = "5",
    preferredposition3 = "10",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "92",
    sprintspeed = "84",
    agility = "75",
    balance = "79",
    jumping = "72",
    stamina = "91",
    strength = "76",
    reactions = "89",
    aggression = "90",
    composure = "89",
    interceptions = "91",
    positioning = "87",
    vision = "89",
    ballcontrol = "87",
    crossing = "82",
    dribbling = "76",
    finishing = "79",
    freekickaccuracy = "90",
    headingaccuracy = "79",
    longpassing = "91",
    shortpassing = "91",
    defensiveawareness = "87",
    shotpower = "95",
    longshots = "91",
    standingtackle = "92",
    slidingtackle = "89",
    volleys = "88",
    curve = "75",
    penalties = "93",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "12722176",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lothar",
    lastname = "Matthäus",
    surname = "Matthäus",
    commonname = "Lothar Matthäus",
    playerjerseyname = "Matthäus"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lothar Matthäus (ID: %s).", entry.playerid))
