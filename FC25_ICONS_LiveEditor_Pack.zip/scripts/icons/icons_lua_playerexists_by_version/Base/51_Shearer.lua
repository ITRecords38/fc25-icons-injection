-- ICON Player Script - PlayerExists Check Only
local playerid = 51

if PlayerExists(playerid) then
    Log("Player with ID: 51 exists")
else
    Log("Player with ID: 51 doesn't exists")
end

local player_data = {
    playerid = "51",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Shearer",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "83",
    sprintspeed = "81",
    agility = "70",
    balance = "73",
    jumping = "87",
    stamina = "83",
    strength = "87",
    reactions = "86",
    aggression = "79",
    composure = "87",
    interceptions = "43",
    positioning = "91",
    vision = "74",
    ballcontrol = "82",
    crossing = "76",
    dribbling = "76",
    finishing = "93",
    freekickaccuracy = "85",
    headingaccuracy = "94",
    longpassing = "62",
    shortpassing = "82",
    defensiveawareness = "27",
    shotpower = "93",
    longshots = "62",
    standingtackle = "57",
    slidingtackle = "53",
    volleys = "92",
    curve = "80",
    penalties = "92",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134742020",
    trait2 = "0",
    icontrait1 = "16",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Alan",
    lastname = "Shearer",
    surname = "Shearer",
    commonname = "Alan Shearer",
    playerjerseyname = "Shearer"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Alan Shearer (ID: %s).", entry.playerid))
