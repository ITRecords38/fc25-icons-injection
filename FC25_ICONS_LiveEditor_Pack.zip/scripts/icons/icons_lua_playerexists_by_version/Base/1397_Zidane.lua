-- ICON Player Script - PlayerExists Check Only
local playerid = 1397

if PlayerExists(playerid) then
    Log("Player with ID: 1397 exists")
else
    Log("Player with ID: 1397 doesn't exists")
end

local player_data = {
    playerid = "1397",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Zidane",
    overallrating = "94",
    preferredposition1 = "18",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "84",
    sprintspeed = "82",
    agility = "78",
    balance = "85",
    jumping = "73",
    stamina = "86",
    strength = "86",
    reactions = "94",
    aggression = "77",
    composure = "96",
    interceptions = "83",
    positioning = "90",
    vision = "96",
    ballcontrol = "96",
    crossing = "92",
    dribbling = "96",
    finishing = "89",
    freekickaccuracy = "90",
    headingaccuracy = "86",
    longpassing = "95",
    shortpassing = "96",
    defensiveawareness = "62",
    shotpower = "88",
    longshots = "95",
    standingtackle = "76",
    slidingtackle = "65",
    volleys = "91",
    curve = "87",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17629313",
    trait2 = "0",
    icontrait1 = "32",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Zinedine",
    lastname = "Zidane",
    surname = "Zidane",
    commonname = "Zinedine Zidane",
    playerjerseyname = "Zidane"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Zinedine Zidane (ID: %s).", entry.playerid))
