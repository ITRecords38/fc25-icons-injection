-- ICON Player Script - PlayerExists Check Only
local playerid = 140601

if PlayerExists(playerid) then
    Log("Player with ID: 140601 exists")
else
    Log("Player with ID: 140601 doesn't exists")
end

local player_data = {
    playerid = "140601",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Vidic",
    overallrating = "88",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "78",
    sprintspeed = "82",
    agility = "70",
    balance = "71",
    jumping = "91",
    stamina = "86",
    strength = "92",
    reactions = "83",
    aggression = "89",
    composure = "86",
    interceptions = "87",
    positioning = "35",
    vision = "56",
    ballcontrol = "72",
    crossing = "51",
    dribbling = "51",
    finishing = "44",
    freekickaccuracy = "47",
    headingaccuracy = "91",
    longpassing = "70",
    shortpassing = "74",
    defensiveawareness = "93",
    shotpower = "70",
    longshots = "70",
    standingtackle = "92",
    slidingtackle = "88",
    volleys = "51",
    curve = "51",
    penalties = "66",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "167830544",
    trait2 = "0",
    icontrait1 = "2048",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Nemanja",
    lastname = "Vidic",
    surname = "Vidic",
    commonname = "Nemanja Vidic",
    playerjerseyname = "Vidic"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Nemanja Vidic (ID: %s).", entry.playerid))
