-- ICON Player Script - PlayerExists Check Only
local playerid = 166124

if PlayerExists(playerid) then
    Log("Player with ID: 166124 exists")
else
    Log("Player with ID: 166124 doesn't exists")
end

local player_data = {
    playerid = "166124",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Hagi",
    overallrating = "89",
    preferredposition1 = "18",
    preferredposition2 = "14",
    preferredposition3 = "16",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "86",
    sprintspeed = "85",
    agility = "84",
    balance = "86",
    jumping = "73",
    stamina = "77",
    strength = "61",
    reactions = "86",
    aggression = "60",
    composure = "88",
    interceptions = "44",
    positioning = "88",
    vision = "90",
    ballcontrol = "91",
    crossing = "87",
    dribbling = "90",
    finishing = "83",
    freekickaccuracy = "93",
    headingaccuracy = "58",
    longpassing = "87",
    shortpassing = "91",
    defensiveawareness = "33",
    shotpower = "92",
    longshots = "87",
    standingtackle = "46",
    slidingtackle = "40",
    volleys = "86",
    curve = "88",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "327723",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gheorghe",
    lastname = "Hagi",
    surname = "Hagi",
    commonname = "Gheorghe Hagi",
    playerjerseyname = "Hagi"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gheorghe Hagi (ID: %s).", entry.playerid))
