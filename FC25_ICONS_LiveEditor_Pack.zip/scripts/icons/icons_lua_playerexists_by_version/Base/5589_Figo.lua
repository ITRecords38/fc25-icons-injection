-- ICON Player Script - PlayerExists Check Only
local playerid = 5589

if PlayerExists(playerid) then
    Log("Player with ID: 5589 exists")
else
    Log("Player with ID: 5589 doesn't exists")
end

local player_data = {
    playerid = "5589",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Figo",
    overallrating = "89",
    preferredposition1 = "23",
    preferredposition2 = "12",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "88",
    agility = "89",
    balance = "77",
    jumping = "67",
    stamina = "85",
    strength = "75",
    reactions = "87",
    aggression = "75",
    composure = "87",
    interceptions = "38",
    positioning = "88",
    vision = "85",
    ballcontrol = "91",
    crossing = "90",
    dribbling = "92",
    finishing = "85",
    freekickaccuracy = "81",
    headingaccuracy = "59",
    longpassing = "81",
    shortpassing = "88",
    defensiveawareness = "33",
    shotpower = "81",
    longshots = "81",
    standingtackle = "38",
    slidingtackle = "36",
    volleys = "77",
    curve = "75",
    penalties = "82",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18088460",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Luís Filipe Madeira Caeiro",
    lastname = "Figo",
    surname = "Figo",
    commonname = "Luís Filipe Madeira Caeiro Figo",
    playerjerseyname = "Figo"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Luís Filipe Madeira Caeiro Figo (ID: %s).", entry.playerid))
