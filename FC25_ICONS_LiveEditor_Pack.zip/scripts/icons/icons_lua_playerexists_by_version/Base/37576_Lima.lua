-- ICON Player Script - PlayerExists Check Only
local playerid = 37576

if PlayerExists(playerid) then
    Log("Player with ID: 37576 exists")
else
    Log("Player with ID: 37576 doesn't exists")
end

local player_data = {
    playerid = "37576",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lima",
    overallrating = "90",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "97",
    sprintspeed = "96",
    agility = "85",
    balance = "80",
    jumping = "84",
    stamina = "86",
    strength = "88",
    reactions = "90",
    aggression = "51",
    composure = "85",
    interceptions = "35",
    positioning = "93",
    vision = "74",
    ballcontrol = "90",
    crossing = "66",
    dribbling = "92",
    finishing = "95",
    freekickaccuracy = "80",
    headingaccuracy = "74",
    longpassing = "67",
    shortpassing = "78",
    defensiveawareness = "32",
    shotpower = "91",
    longshots = "67",
    standingtackle = "35",
    slidingtackle = "31",
    volleys = "93",
    curve = "79",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "5767169",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ronaldo Luís Nazário de",
    lastname = "Lima",
    surname = "Lima",
    commonname = "Ronaldo Luís Nazário de Lima",
    playerjerseyname = "Lima"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ronaldo Luís Nazário de Lima (ID: %s).", entry.playerid))
