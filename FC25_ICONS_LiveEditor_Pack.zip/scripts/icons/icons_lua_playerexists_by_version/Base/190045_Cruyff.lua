-- ICON Player Script - PlayerExists Check Only
local playerid = 190045

if PlayerExists(playerid) then
    Log("Player with ID: 190045 exists")
else
    Log("Player with ID: 190045 doesn't exists")
end

local player_data = {
    playerid = "190045",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Cruyff",
    overallrating = "93",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "92",
    sprintspeed = "88",
    agility = "92",
    balance = "80",
    jumping = "65",
    stamina = "81",
    strength = "70",
    reactions = "95",
    aggression = "70",
    composure = "94",
    interceptions = "43",
    positioning = "94",
    vision = "93",
    ballcontrol = "95",
    crossing = "86",
    dribbling = "94",
    finishing = "94",
    freekickaccuracy = "83",
    headingaccuracy = "64",
    longpassing = "86",
    shortpassing = "92",
    defensiveawareness = "42",
    shotpower = "84",
    longshots = "86",
    standingtackle = "35",
    slidingtackle = "39",
    volleys = "94",
    curve = "92",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18088226",
    trait2 = "0",
    icontrait1 = "524288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Johan",
    lastname = "Cruyff",
    surname = "Cruyff",
    commonname = "Johan Cruyff",
    playerjerseyname = "Cruyff"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Johan Cruyff (ID: %s).", entry.playerid))
