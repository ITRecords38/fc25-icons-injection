-- ICON Player Script - PlayerExists Check Only
local playerid = 247699

if PlayerExists(playerid) then
    Log("Player with ID: 247699 exists")
else
    Log("Player with ID: 247699 doesn't exists")
end

local player_data = {
    playerid = "247699",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Dalglish",
    overallrating = "88",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "93",
    sprintspeed = "90",
    agility = "87",
    balance = "85",
    jumping = "76",
    stamina = "83",
    strength = "64",
    reactions = "88",
    aggression = "67",
    composure = "84",
    interceptions = "30",
    positioning = "87",
    vision = "81",
    ballcontrol = "85",
    crossing = "81",
    dribbling = "83",
    finishing = "88",
    freekickaccuracy = "95",
    headingaccuracy = "84",
    longpassing = "60",
    shortpassing = "91",
    defensiveawareness = "34",
    shotpower = "83",
    longshots = "60",
    standingtackle = "38",
    slidingtackle = "35",
    volleys = "87",
    curve = "87",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21299462",
    trait2 = "0",
    icontrait1 = "65",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Kenny",
    lastname = "Dalglish",
    surname = "Dalglish",
    commonname = "Kenny Dalglish",
    playerjerseyname = "Dalglish"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Kenny Dalglish (ID: %s).", entry.playerid))
