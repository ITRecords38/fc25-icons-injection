-- ICON Player Script - PlayerExists Check Only
local playerid = 45197

if PlayerExists(playerid) then
    Log("Player with ID: 45197 exists")
else
    Log("Player with ID: 45197 doesn't exists")
end

local player_data = {
    playerid = "45197",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Olano",
    overallrating = "87",
    preferredposition1 = "10",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "67",
    sprintspeed = "74",
    agility = "66",
    balance = "77",
    jumping = "61",
    stamina = "83",
    strength = "79",
    reactions = "85",
    aggression = "81",
    composure = "88",
    interceptions = "86",
    positioning = "70",
    vision = "85",
    ballcontrol = "87",
    crossing = "81",
    dribbling = "72",
    finishing = "68",
    freekickaccuracy = "84",
    headingaccuracy = "73",
    longpassing = "88",
    shortpassing = "89",
    defensiveawareness = "83",
    shotpower = "87",
    longshots = "88",
    standingtackle = "84",
    slidingtackle = "77",
    volleys = "75",
    curve = "78",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "540676",
    trait2 = "0",
    icontrait1 = "128",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Xabier Alonso",
    lastname = "Olano",
    surname = "Olano",
    commonname = "Xabier Alonso Olano",
    playerjerseyname = "Olano"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Xabier Alonso Olano (ID: %s).", entry.playerid))
