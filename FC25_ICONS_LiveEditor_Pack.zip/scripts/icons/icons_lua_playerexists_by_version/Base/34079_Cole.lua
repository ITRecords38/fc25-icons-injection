-- ICON Player Script - PlayerExists Check Only
local playerid = 34079

if PlayerExists(playerid) then
    Log("Player with ID: 34079 exists")
else
    Log("Player with ID: 34079 doesn't exists")
end

local player_data = {
    playerid = "34079",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Cole",
    overallrating = "86",
    preferredposition1 = "7",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "2",
    acceleration = "88",
    sprintspeed = "86",
    agility = "81",
    balance = "82",
    jumping = "79",
    stamina = "89",
    strength = "69",
    reactions = "85",
    aggression = "83",
    composure = "82",
    interceptions = "85",
    positioning = "75",
    vision = "78",
    ballcontrol = "80",
    crossing = "83",
    dribbling = "78",
    finishing = "55",
    freekickaccuracy = "62",
    headingaccuracy = "62",
    longpassing = "79",
    shortpassing = "80",
    defensiveawareness = "86",
    shotpower = "73",
    longshots = "79",
    standingtackle = "86",
    slidingtackle = "89",
    volleys = "70",
    curve = "79",
    penalties = "72",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "16861696",
    trait2 = "0",
    icontrait1 = "1024",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ashley",
    lastname = "Cole",
    surname = "Cole",
    commonname = "Ashley Cole",
    playerjerseyname = "Cole"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ashley Cole (ID: %s).", entry.playerid))
