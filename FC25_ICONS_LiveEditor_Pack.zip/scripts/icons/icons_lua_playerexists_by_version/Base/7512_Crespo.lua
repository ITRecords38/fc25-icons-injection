-- ICON Player Script - PlayerExists Check Only
local playerid = 7512

if PlayerExists(playerid) then
    Log("Player with ID: 7512 exists")
else
    Log("Player with ID: 7512 doesn't exists")
end

local player_data = {
    playerid = "7512",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Crespo",
    overallrating = "86",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "86",
    sprintspeed = "86",
    agility = "86",
    balance = "81",
    jumping = "84",
    stamina = "76",
    strength = "74",
    reactions = "85",
    aggression = "48",
    composure = "88",
    interceptions = "30",
    positioning = "87",
    vision = "79",
    ballcontrol = "84",
    crossing = "73",
    dribbling = "85",
    finishing = "90",
    freekickaccuracy = "64",
    headingaccuracy = "88",
    longpassing = "54",
    shortpassing = "71",
    defensiveawareness = "29",
    shotpower = "83",
    longshots = "54",
    standingtackle = "31",
    slidingtackle = "30",
    volleys = "83",
    curve = "68",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "167772161",
    trait2 = "0",
    icontrait1 = "16",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Hernán",
    lastname = "Crespo",
    surname = "Crespo",
    commonname = "Hernán Crespo",
    playerjerseyname = "Crespo"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Hernán Crespo (ID: %s).", entry.playerid))
