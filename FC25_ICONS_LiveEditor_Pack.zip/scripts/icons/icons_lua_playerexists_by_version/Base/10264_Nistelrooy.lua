-- ICON Player Script - PlayerExists Check Only
local playerid = 10264

if PlayerExists(playerid) then
    Log("Player with ID: 10264 exists")
else
    Log("Player with ID: 10264 doesn't exists")
end

local player_data = {
    playerid = "10264",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Nistelrooy",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "83",
    sprintspeed = "84",
    agility = "73",
    balance = "71",
    jumping = "77",
    stamina = "78",
    strength = "83",
    reactions = "92",
    aggression = "76",
    composure = "83",
    interceptions = "31",
    positioning = "89",
    vision = "69",
    ballcontrol = "87",
    crossing = "70",
    dribbling = "82",
    finishing = "94",
    freekickaccuracy = "74",
    headingaccuracy = "87",
    longpassing = "56",
    shortpassing = "79",
    defensiveawareness = "28",
    shotpower = "90",
    longshots = "56",
    standingtackle = "37",
    slidingtackle = "31",
    volleys = "91",
    curve = "77",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "33718291",
    trait2 = "0",
    icontrait1 = "524288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ruud van",
    lastname = "Nistelrooy",
    surname = "Nistelrooy",
    commonname = "Ruud van Nistelrooy",
    playerjerseyname = "Nistelrooy"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ruud van Nistelrooy (ID: %s).", entry.playerid))
