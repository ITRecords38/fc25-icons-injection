-- ICON Player Script - PlayerExists Check Only
local playerid = 23174

if PlayerExists(playerid) then
    Log("Player with ID: 23174 exists")
else
    Log("Player with ID: 23174 doesn't exists")
end

local player_data = {
    playerid = "23174",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Riquelme",
    overallrating = "88",
    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "68",
    sprintspeed = "73",
    agility = "79",
    balance = "85",
    jumping = "61",
    stamina = "71",
    strength = "71",
    reactions = "83",
    aggression = "50",
    composure = "92",
    interceptions = "31",
    positioning = "82",
    vision = "92",
    ballcontrol = "93",
    crossing = "88",
    dribbling = "92",
    finishing = "81",
    freekickaccuracy = "90",
    headingaccuracy = "56",
    longpassing = "90",
    shortpassing = "91",
    defensiveawareness = "27",
    shotpower = "87",
    longshots = "90",
    standingtackle = "34",
    slidingtackle = "32",
    volleys = "76",
    curve = "88",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18350124",
    trait2 = "0",
    icontrait1 = "262144",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Juan Román",
    lastname = "Riquelme",
    surname = "Riquelme",
    commonname = "Juan Román Riquelme",
    playerjerseyname = "Riquelme"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Juan Román Riquelme (ID: %s).", entry.playerid))
