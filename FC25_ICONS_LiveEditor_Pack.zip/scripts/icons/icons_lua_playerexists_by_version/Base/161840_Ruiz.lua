-- ICON Player Script - PlayerExists Check Only
local playerid = 161840

if PlayerExists(playerid) then
    Log("Player with ID: 161840 exists")
else
    Log("Player with ID: 161840 doesn't exists")
end

local player_data = {
    playerid = "161840",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ruiz",
    overallrating = "88",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "74",
    sprintspeed = "74",
    agility = "63",
    balance = "83",
    jumping = "90",
    stamina = "81",
    strength = "87",
    reactions = "82",
    aggression = "81",
    composure = "86",
    interceptions = "92",
    positioning = "64",
    vision = "70",
    ballcontrol = "72",
    crossing = "62",
    dribbling = "61",
    finishing = "54",
    freekickaccuracy = "73",
    headingaccuracy = "93",
    longpassing = "86",
    shortpassing = "79",
    defensiveawareness = "93",
    shotpower = "82",
    longshots = "86",
    standingtackle = "94",
    slidingtackle = "77",
    volleys = "75",
    curve = "64",
    penalties = "73",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134236312",
    trait2 = "0",
    icontrait1 = "32768",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Fernando Hierro",
    lastname = "Ruiz",
    surname = "Ruiz",
    commonname = "Fernando Hierro Ruiz",
    playerjerseyname = "Ruiz"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Fernando Hierro Ruiz (ID: %s).", entry.playerid))
