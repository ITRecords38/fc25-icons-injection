-- ICON Player Script - PlayerExists Check Only
local playerid = 240

if PlayerExists(playerid) then
    Log("Player with ID: 240 exists")
else
    Log("Player with ID: 240 doesn't exists")
end

local player_data = {
    playerid = "240",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Keane",
    overallrating = "86",
    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "70",
    sprintspeed = "73",
    agility = "68",
    balance = "75",
    jumping = "77",
    stamina = "91",
    strength = "84",
    reactions = "90",
    aggression = "93",
    composure = "88",
    interceptions = "92",
    positioning = "68",
    vision = "84",
    ballcontrol = "84",
    crossing = "71",
    dribbling = "75",
    finishing = "69",
    freekickaccuracy = "70",
    headingaccuracy = "75",
    longpassing = "86",
    shortpassing = "89",
    defensiveawareness = "76",
    shotpower = "63",
    longshots = "86",
    standingtackle = "90",
    slidingtackle = "85",
    volleys = "56",
    curve = "68",
    penalties = "68",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "11030528",
    trait2 = "0",
    icontrait1 = "64",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Roy",
    lastname = "Keane",
    surname = "Keane",
    commonname = "Roy Keane",
    playerjerseyname = "Keane"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Roy Keane (ID: %s).", entry.playerid))
