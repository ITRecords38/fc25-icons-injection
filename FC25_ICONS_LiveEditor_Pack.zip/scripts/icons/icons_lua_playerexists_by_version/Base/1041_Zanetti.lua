-- ICON Player Script - PlayerExists Check Only
local playerid = 1041

if PlayerExists(playerid) then
    Log("Player with ID: 1041 exists")
else
    Log("Player with ID: 1041 doesn't exists")
end

local player_data = {
    playerid = "1041",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Zanetti",
    overallrating = "89",
    preferredposition1 = "3",
    preferredposition2 = "7",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "4",
    acceleration = "82",
    sprintspeed = "83",
    agility = "75",
    balance = "81",
    jumping = "50",
    stamina = "88",
    strength = "73",
    reactions = "87",
    aggression = "83",
    composure = "84",
    interceptions = "89",
    positioning = "73",
    vision = "80",
    ballcontrol = "88",
    crossing = "91",
    dribbling = "77",
    finishing = "58",
    freekickaccuracy = "55",
    headingaccuracy = "81",
    longpassing = "84",
    shortpassing = "90",
    defensiveawareness = "84",
    shotpower = "71",
    longshots = "84",
    standingtackle = "87",
    slidingtackle = "85",
    volleys = "57",
    curve = "57",
    penalties = "65",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2110468",
    trait2 = "0",
    icontrait1 = "8388608",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Javier",
    lastname = "Zanetti",
    surname = "Zanetti",
    commonname = "Javier Zanetti",
    playerjerseyname = "Zanetti"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Javier Zanetti (ID: %s).", entry.playerid))
