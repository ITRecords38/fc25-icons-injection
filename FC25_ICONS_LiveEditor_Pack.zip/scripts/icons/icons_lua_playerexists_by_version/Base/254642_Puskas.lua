-- ICON Player Script - PlayerExists Check Only
local playerid = 254642

if PlayerExists(playerid) then
    Log("Player with ID: 254642 exists")
else
    Log("Player with ID: 254642 doesn't exists")
end

local player_data = {
    playerid = "254642",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Puskás",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "3",
    acceleration = "91",
    sprintspeed = "89",
    agility = "90",
    balance = "91",
    jumping = "69",
    stamina = "88",
    strength = "75",
    reactions = "95",
    aggression = "55",
    composure = "95",
    interceptions = "44",
    positioning = "96",
    vision = "91",
    ballcontrol = "93",
    crossing = "86",
    dribbling = "90",
    finishing = "95",
    freekickaccuracy = "87",
    headingaccuracy = "74",
    longpassing = "87",
    shortpassing = "90",
    defensiveawareness = "42",
    shotpower = "94",
    longshots = "87",
    standingtackle = "41",
    slidingtackle = "38",
    volleys = "92",
    curve = "90",
    penalties = "92",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21364740",
    trait2 = "0",
    icontrait1 = "524288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ferenc",
    lastname = "Puskás",
    surname = "Puskás",
    commonname = "Ferenc Puskás",
    playerjerseyname = "Puskás"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ferenc Puskás (ID: %s).", entry.playerid))
