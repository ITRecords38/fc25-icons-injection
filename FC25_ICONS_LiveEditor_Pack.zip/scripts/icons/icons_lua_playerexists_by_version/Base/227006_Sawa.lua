-- ICON Player Script - PlayerExists Check Only
local playerid = 227006

if PlayerExists(playerid) then
    Log("Player with ID: 227006 exists")
else
    Log("Player with ID: 227006 doesn't exists")
end

local player_data = {
    playerid = "227006",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Sawa",
    overallrating = "92",
    preferredposition1 = "14",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "83",
    agility = "89",
    balance = "83",
    jumping = "79",
    stamina = "93",
    strength = "70",
    reactions = "92",
    aggression = "72",
    composure = "94",
    interceptions = "85",
    positioning = "92",
    vision = "93",
    ballcontrol = "93",
    crossing = "88",
    dribbling = "92",
    finishing = "93",
    freekickaccuracy = "81",
    headingaccuracy = "89",
    longpassing = "95",
    shortpassing = "96",
    defensiveawareness = "84",
    shotpower = "80",
    longshots = "95",
    standingtackle = "88",
    slidingtackle = "70",
    volleys = "75",
    curve = "88",
    penalties = "82",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "6816128",
    trait2 = "0",
    icontrait1 = "8388640",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Homare",
    lastname = "Sawa",
    surname = "Sawa",
    commonname = "Homare Sawa",
    playerjerseyname = "Sawa"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Homare Sawa (ID: %s).", entry.playerid))
