-- ICON Player Script - PlayerExists Check Only
local playerid = 190042

if PlayerExists(playerid) then
    Log("Player with ID: 190042 exists")
else
    Log("Player with ID: 190042 doesn't exists")
end

local player_data = {
    playerid = "190042",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Maradona",
    overallrating = "95",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "3",
    acceleration = "92",
    sprintspeed = "88",
    agility = "90",
    balance = "95",
    jumping = "82",
    stamina = "78",
    strength = "75",
    reactions = "93",
    aggression = "77",
    composure = "95",
    interceptions = "45",
    positioning = "92",
    vision = "95",
    ballcontrol = "96",
    crossing = "88",
    dribbling = "97",
    finishing = "94",
    freekickaccuracy = "93",
    headingaccuracy = "67",
    longpassing = "89",
    shortpassing = "90",
    defensiveawareness = "28",
    shotpower = "86",
    longshots = "89",
    standingtackle = "41",
    slidingtackle = "38",
    volleys = "87",
    curve = "95",
    penalties = "93",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "786729",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Diego",
    lastname = "Maradona",
    surname = "Maradona",
    commonname = "Diego Maradona",
    playerjerseyname = "Maradona"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Diego Maradona (ID: %s).", entry.playerid))
