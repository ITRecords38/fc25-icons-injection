-- ICON Player Script - PlayerExists Check Only
local playerid = 7289

if PlayerExists(playerid) then
    Log("Player with ID: 7289 exists")
else
    Log("Player with ID: 7289 doesn't exists")
end

local player_data = {
    playerid = "7289",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ferdinand",
    overallrating = "88",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "83",
    sprintspeed = "81",
    agility = "59",
    balance = "56",
    jumping = "81",
    stamina = "82",
    strength = "86",
    reactions = "84",
    aggression = "85",
    composure = "88",
    interceptions = "89",
    positioning = "46",
    vision = "54",
    ballcontrol = "73",
    crossing = "52",
    dribbling = "54",
    finishing = "43",
    freekickaccuracy = "31",
    headingaccuracy = "85",
    longpassing = "75",
    shortpassing = "81",
    defensiveawareness = "91",
    shotpower = "63",
    longshots = "75",
    standingtackle = "91",
    slidingtackle = "88",
    volleys = "55",
    curve = "52",
    penalties = "59",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "167822352",
    trait2 = "0",
    icontrait1 = "8192",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Rio",
    lastname = "Ferdinand",
    surname = "Ferdinand",
    commonname = "Rio Ferdinand",
    playerjerseyname = "Ferdinand"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Rio Ferdinand (ID: %s).", entry.playerid))
