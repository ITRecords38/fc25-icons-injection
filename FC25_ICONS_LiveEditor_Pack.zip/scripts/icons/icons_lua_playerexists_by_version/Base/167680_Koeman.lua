-- ICON Player Script - PlayerExists Check Only
local playerid = 167680

if PlayerExists(playerid) then
    Log("Player with ID: 167680 exists")
else
    Log("Player with ID: 167680 doesn't exists")
end

local player_data = {
    playerid = "167680",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Koeman",
    overallrating = "88",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "73",
    sprintspeed = "78",
    agility = "65",
    balance = "70",
    jumping = "83",
    stamina = "84",
    strength = "85",
    reactions = "89",
    aggression = "84",
    composure = "85",
    interceptions = "91",
    positioning = "76",
    vision = "80",
    ballcontrol = "84",
    crossing = "79",
    dribbling = "76",
    finishing = "80",
    freekickaccuracy = "95",
    headingaccuracy = "83",
    longpassing = "94",
    shortpassing = "86",
    defensiveawareness = "86",
    shotpower = "96",
    longshots = "94",
    standingtackle = "90",
    slidingtackle = "87",
    volleys = "81",
    curve = "92",
    penalties = "95",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "49284",
    trait2 = "0",
    icontrait1 = "8",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ronald",
    lastname = "Koeman",
    surname = "Koeman",
    commonname = "Ronald Koeman",
    playerjerseyname = "Koeman"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ronald Koeman (ID: %s).", entry.playerid))
