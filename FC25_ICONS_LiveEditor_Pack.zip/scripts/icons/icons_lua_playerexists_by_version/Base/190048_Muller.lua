-- ICON Player Script - PlayerExists Check Only
local playerid = 190048

if PlayerExists(playerid) then
    Log("Player with ID: 190048 exists")
else
    Log("Player with ID: 190048 doesn't exists")
end

local player_data = {
    playerid = "190048",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Müller",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "92",
    sprintspeed = "82",
    agility = "83",
    balance = "93",
    jumping = "88",
    stamina = "79",
    strength = "75",
    reactions = "96",
    aggression = "61",
    composure = "89",
    interceptions = "41",
    positioning = "96",
    vision = "81",
    ballcontrol = "89",
    crossing = "66",
    dribbling = "80",
    finishing = "97",
    freekickaccuracy = "74",
    headingaccuracy = "94",
    longpassing = "66",
    shortpassing = "82",
    defensiveawareness = "44",
    shotpower = "94",
    longshots = "66",
    standingtackle = "32",
    slidingtackle = "31",
    volleys = "94",
    curve = "77",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "151519232",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gerd",
    lastname = "Müller",
    surname = "Müller",
    commonname = "Gerd Müller",
    playerjerseyname = "Müller"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gerd Müller (ID: %s).", entry.playerid))
