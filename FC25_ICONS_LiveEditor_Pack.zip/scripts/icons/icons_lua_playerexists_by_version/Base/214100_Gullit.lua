-- ICON Player Script - PlayerExists Check Only
local playerid = 214100

if PlayerExists(playerid) then
    Log("Player with ID: 214100 exists")
else
    Log("Player with ID: 214100 doesn't exists")
end

local player_data = {
    playerid = "214100",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Gullit",
    overallrating = "90",
    preferredposition1 = "18",
    preferredposition2 = "14",
    preferredposition3 = "25",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "83",
    sprintspeed = "86",
    agility = "76",
    balance = "82",
    jumping = "83",
    stamina = "92",
    strength = "86",
    reactions = "92",
    aggression = "84",
    composure = "88",
    interceptions = "79",
    positioning = "91",
    vision = "89",
    ballcontrol = "89",
    crossing = "85",
    dribbling = "86",
    finishing = "86",
    freekickaccuracy = "89",
    headingaccuracy = "92",
    longpassing = "91",
    shortpassing = "89",
    defensiveawareness = "77",
    shotpower = "93",
    longshots = "91",
    standingtackle = "80",
    slidingtackle = "75",
    volleys = "85",
    curve = "87",
    penalties = "82",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "131094",
    trait2 = "0",
    icontrait1 = "134217728",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ruud",
    lastname = "Gullit",
    surname = "Gullit",
    commonname = "Ruud Gullit",
    playerjerseyname = "Gullit"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ruud Gullit (ID: %s).", entry.playerid))
