-- ICON Player Script - PlayerExists Check Only
local playerid = 28130

if PlayerExists(playerid) then
    Log("Player with ID: 28130 exists")
else
    Log("Player with ID: 28130 doesn't exists")
end

local player_data = {
    playerid = "28130",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Moreira",
    overallrating = "93",
    preferredposition1 = "27",
    preferredposition2 = "16",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "90",
    agility = "94",
    balance = "88",
    jumping = "85",
    stamina = "82",
    strength = "83",
    reactions = "92",
    aggression = "68",
    composure = "94",
    interceptions = "31",
    positioning = "89",
    vision = "92",
    ballcontrol = "95",
    crossing = "89",
    dribbling = "96",
    finishing = "92",
    freekickaccuracy = "91",
    headingaccuracy = "52",
    longpassing = "85",
    shortpassing = "91",
    defensiveawareness = "37",
    shotpower = "86",
    longshots = "85",
    standingtackle = "40",
    slidingtackle = "31",
    volleys = "82",
    curve = "89",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17629193",
    trait2 = "0",
    icontrait1 = "1048576",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ronaldo de Assis",
    lastname = "Moreira",
    surname = "Moreira",
    commonname = "Ronaldo de Assis Moreira",
    playerjerseyname = "Moreira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ronaldo de Assis Moreira (ID: %s).", entry.playerid))
