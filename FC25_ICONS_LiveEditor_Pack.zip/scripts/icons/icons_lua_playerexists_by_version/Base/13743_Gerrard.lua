-- ICON Player Script - PlayerExists Check Only
local playerid = 13743

if PlayerExists(playerid) then
    Log("Player with ID: 13743 exists")
else
    Log("Player with ID: 13743 doesn't exists")
end

local player_data = {
    playerid = "13743",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Gerrard",
    overallrating = "88",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "77",
    sprintspeed = "79",
    agility = "70",
    balance = "70",
    jumping = "72",
    stamina = "87",
    strength = "80",
    reactions = "84",
    aggression = "83",
    composure = "83",
    interceptions = "74",
    positioning = "86",
    vision = "87",
    ballcontrol = "90",
    crossing = "85",
    dribbling = "83",
    finishing = "86",
    freekickaccuracy = "80",
    headingaccuracy = "72",
    longpassing = "93",
    shortpassing = "91",
    defensiveawareness = "74",
    shotpower = "90",
    longshots = "93",
    standingtackle = "77",
    slidingtackle = "72",
    volleys = "83",
    curve = "82",
    penalties = "83",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "16777952",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Steven",
    lastname = "Gerrard",
    surname = "Gerrard",
    commonname = "Steven Gerrard",
    playerjerseyname = "Gerrard"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Steven Gerrard (ID: %s).", entry.playerid))
