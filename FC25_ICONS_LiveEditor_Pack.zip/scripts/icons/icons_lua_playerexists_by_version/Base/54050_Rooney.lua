-- ICON Player Script - PlayerExists Check Only
local playerid = 54050

if PlayerExists(playerid) then
    Log("Player with ID: 54050 exists")
else
    Log("Player with ID: 54050 doesn't exists")
end

local player_data = {
    playerid = "54050",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Rooney",
    overallrating = "88",
    preferredposition1 = "25",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "89",
    sprintspeed = "87",
    agility = "82",
    balance = "82",
    jumping = "85",
    stamina = "89",
    strength = "85",
    reactions = "90",
    aggression = "88",
    composure = "85",
    interceptions = "43",
    positioning = "90",
    vision = "79",
    ballcontrol = "89",
    crossing = "77",
    dribbling = "84",
    finishing = "89",
    freekickaccuracy = "82",
    headingaccuracy = "87",
    longpassing = "83",
    shortpassing = "84",
    defensiveawareness = "51",
    shotpower = "92",
    longshots = "83",
    standingtackle = "55",
    slidingtackle = "43",
    volleys = "90",
    curve = "84",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "58720387",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Wayne",
    lastname = "Rooney",
    surname = "Rooney",
    commonname = "Wayne Rooney",
    playerjerseyname = "Rooney"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Wayne Rooney (ID: %s).", entry.playerid))
