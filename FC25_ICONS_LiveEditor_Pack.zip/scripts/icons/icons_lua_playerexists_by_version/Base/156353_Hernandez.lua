-- ICON Player Script - PlayerExists Check Only
local playerid = 156353

if PlayerExists(playerid) then
    Log("Player with ID: 156353 exists")
else
    Log("Player with ID: 156353 doesn't exists")
end

local player_data = {
    playerid = "156353",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Hernández",
    overallrating = "86",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "3",
    acceleration = "91",
    sprintspeed = "88",
    agility = "90",
    balance = "82",
    jumping = "86",
    stamina = "79",
    strength = "62",
    reactions = "85",
    aggression = "58",
    composure = "83",
    interceptions = "32",
    positioning = "88",
    vision = "70",
    ballcontrol = "86",
    crossing = "66",
    dribbling = "87",
    finishing = "88",
    freekickaccuracy = "78",
    headingaccuracy = "89",
    longpassing = "69",
    shortpassing = "73",
    defensiveawareness = "38",
    shotpower = "83",
    longshots = "69",
    standingtackle = "44",
    slidingtackle = "49",
    volleys = "80",
    curve = "72",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "151126034",
    trait2 = "0",
    icontrait1 = "524288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Luis",
    lastname = "Hernández",
    surname = "Hernández",
    commonname = "Luis Hernández",
    playerjerseyname = "Hernández"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Luis Hernández (ID: %s).", entry.playerid))
