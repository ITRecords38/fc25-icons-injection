-- ICON Player Script - PlayerExists Check Only
local playerid = 238428

if PlayerExists(playerid) then
    Log("Player with ID: 238428 exists")
else
    Log("Player with ID: 238428 doesn't exists")
end

local player_data = {
    playerid = "238428",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Schmeichel",
    overallrating = "89",
    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "0",
    weakfootabilitytypecode = "3",
    acceleration = "50",
    sprintspeed = "42",
    agility = "46",
    balance = "43",
    jumping = "73",
    stamina = "67",
    strength = "80",
    reactions = "86",
    aggression = "47",
    composure = "71",
    interceptions = "38",
    positioning = "31",
    vision = "71",
    ballcontrol = "34",
    crossing = "32",
    dribbling = "30",
    finishing = "34",
    freekickaccuracy = "30",
    headingaccuracy = "40",
    longpassing = "31",
    shortpassing = "33",
    defensiveawareness = "22",
    shotpower = "65",
    longshots = "31",
    standingtackle = "20",
    slidingtackle = "22",
    volleys = "23",
    curve = "24",
    penalties = "37",
    gkdiving = "89",
    gkhandling = "84",
    gkkicking = "86",
    gkreflexes = "91",
    gkpositioning = "87",
    trait1 = "536870976",
    trait2 = "2",
    icontrait1 = "268435456",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Peter",
    lastname = "Schmeichel",
    surname = "Schmeichel",
    commonname = "Peter Schmeichel",
    playerjerseyname = "Schmeichel"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Peter Schmeichel (ID: %s).", entry.playerid))
