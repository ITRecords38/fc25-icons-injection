-- ICON Player Script - PlayerExists Check Only
local playerid = 1668

if PlayerExists(playerid) then
    Log("Player with ID: 1668 exists")
else
    Log("Player with ID: 1668 doesn't exists")
end

local player_data = {
    playerid = "1668",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Makélélé",
    overallrating = "88",
    preferredposition1 = "10",
    preferredposition2 = "12",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "84",
    sprintspeed = "81",
    agility = "85",
    balance = "91",
    jumping = "85",
    stamina = "91",
    strength = "84",
    reactions = "90",
    aggression = "88",
    composure = "89",
    interceptions = "92",
    positioning = "61",
    vision = "80",
    ballcontrol = "84",
    crossing = "70",
    dribbling = "72",
    finishing = "43",
    freekickaccuracy = "35",
    headingaccuracy = "57",
    longpassing = "81",
    shortpassing = "88",
    defensiveawareness = "89",
    shotpower = "61",
    longshots = "81",
    standingtackle = "94",
    slidingtackle = "85",
    volleys = "42",
    curve = "50",
    penalties = "50",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10541056",
    trait2 = "0",
    icontrait1 = "1024",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Claude",
    lastname = "Makélélé",
    surname = "Makélélé",
    commonname = "Claude Makélélé",
    playerjerseyname = "Makélélé"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Claude Makélélé (ID: %s).", entry.playerid))
