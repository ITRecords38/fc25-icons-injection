-- ICON Player Script - PlayerExists Check Only
local playerid = 191695

if PlayerExists(playerid) then
    Log("Player with ID: 191695 exists")
else
    Log("Player with ID: 191695 doesn't exists")
end

local player_data = {
    playerid = "191695",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Santos",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "5",
    acceleration = "93",
    sprintspeed = "91",
    agility = "90",
    balance = "88",
    jumping = "81",
    stamina = "82",
    strength = "62",
    reactions = "89",
    aggression = "49",
    composure = "86",
    interceptions = "44",
    positioning = "91",
    vision = "87",
    ballcontrol = "90",
    crossing = "72",
    dribbling = "91",
    finishing = "94",
    freekickaccuracy = "75",
    headingaccuracy = "84",
    longpassing = "60",
    shortpassing = "83",
    defensiveawareness = "33",
    shotpower = "85",
    longshots = "60",
    standingtackle = "32",
    slidingtackle = "30",
    volleys = "85",
    curve = "78",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21757955",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Emilio Butragueño",
    lastname = "Santos",
    surname = "Santos",
    commonname = "Emilio Butragueño Santos",
    playerjerseyname = "Santos"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Emilio Butragueño Santos (ID: %s).", entry.playerid))
