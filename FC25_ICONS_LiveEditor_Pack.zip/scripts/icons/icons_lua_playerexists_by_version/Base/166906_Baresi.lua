-- ICON Player Script - PlayerExists Check Only
local playerid = 166906

if PlayerExists(playerid) then
    Log("Player with ID: 166906 exists")
else
    Log("Player with ID: 166906 doesn't exists")
end

local player_data = {
    playerid = "166906",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Baresi",
    overallrating = "91",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "69",
    sprintspeed = "77",
    agility = "73",
    balance = "75",
    jumping = "86",
    stamina = "86",
    strength = "79",
    reactions = "93",
    aggression = "86",
    composure = "84",
    interceptions = "94",
    positioning = "39",
    vision = "70",
    ballcontrol = "86",
    crossing = "63",
    dribbling = "55",
    finishing = "44",
    freekickaccuracy = "44",
    headingaccuracy = "89",
    longpassing = "85",
    shortpassing = "87",
    defensiveawareness = "94",
    shotpower = "53",
    longshots = "85",
    standingtackle = "94",
    slidingtackle = "94",
    volleys = "49",
    curve = "57",
    penalties = "62",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "5248",
    trait2 = "0",
    icontrait1 = "16384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Franco",
    lastname = "Baresi",
    surname = "Baresi",
    commonname = "Franco Baresi",
    playerjerseyname = "Baresi"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Franco Baresi (ID: %s).", entry.playerid))
