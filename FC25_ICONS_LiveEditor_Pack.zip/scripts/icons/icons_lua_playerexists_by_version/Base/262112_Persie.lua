-- ICON Player Script - PlayerExists Check Only
local playerid = 262112

if PlayerExists(playerid) then
    Log("Player with ID: 262112 exists")
else
    Log("Player with ID: 262112 doesn't exists")
end

local player_data = {
    playerid = "262112",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Persie",
    overallrating = "88",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "85",
    sprintspeed = "84",
    agility = "82",
    balance = "72",
    jumping = "67",
    stamina = "77",
    strength = "77",
    reactions = "90",
    aggression = "58",
    composure = "89",
    interceptions = "49",
    positioning = "93",
    vision = "84",
    ballcontrol = "91",
    crossing = "84",
    dribbling = "87",
    finishing = "92",
    freekickaccuracy = "86",
    headingaccuracy = "78",
    longpassing = "77",
    shortpassing = "86",
    defensiveawareness = "37",
    shotpower = "91",
    longshots = "77",
    standingtackle = "43",
    slidingtackle = "36",
    volleys = "93",
    curve = "87",
    penalties = "91",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17104903",
    trait2 = "0",
    icontrait1 = "524288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Robin van",
    lastname = "Persie",
    surname = "Persie",
    commonname = "Robin van Persie",
    playerjerseyname = "Persie"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Robin van Persie (ID: %s).", entry.playerid))
