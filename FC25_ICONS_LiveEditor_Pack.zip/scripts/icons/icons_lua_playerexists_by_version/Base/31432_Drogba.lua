-- ICON Player Script - PlayerExists Check Only
local playerid = 31432

if PlayerExists(playerid) then
    Log("Player with ID: 31432 exists")
else
    Log("Player with ID: 31432 doesn't exists")
end

local player_data = {
    playerid = "31432",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Drogba",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "86",
    agility = "73",
    balance = "70",
    jumping = "89",
    stamina = "86",
    strength = "93",
    reactions = "85",
    aggression = "75",
    composure = "85",
    interceptions = "44",
    positioning = "91",
    vision = "77",
    ballcontrol = "84",
    crossing = "74",
    dribbling = "79",
    finishing = "93",
    freekickaccuracy = "81",
    headingaccuracy = "94",
    longpassing = "66",
    shortpassing = "76",
    defensiveawareness = "36",
    shotpower = "92",
    longshots = "66",
    standingtackle = "38",
    slidingtackle = "35",
    volleys = "90",
    curve = "73",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "136839184",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Didier",
    lastname = "Drogba",
    surname = "Drogba",
    commonname = "Didier Drogba",
    playerjerseyname = "Drogba"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Didier Drogba (ID: %s).", entry.playerid))
