-- ICON Player Script - PlayerExists Check Only
local playerid = 243027

if PlayerExists(playerid) then
    Log("Player with ID: 243027 exists")
else
    Log("Player with ID: 243027 doesn't exists")
end

local player_data = {
    playerid = "243027",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Verón",
    overallrating = "86",
    preferredposition1 = "14",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "76",
    sprintspeed = "74",
    agility = "70",
    balance = "69",
    jumping = "65",
    stamina = "85",
    strength = "78",
    reactions = "83",
    aggression = "86",
    composure = "86",
    interceptions = "79",
    positioning = "80",
    vision = "86",
    ballcontrol = "88",
    crossing = "81",
    dribbling = "80",
    finishing = "72",
    freekickaccuracy = "85",
    headingaccuracy = "66",
    longpassing = "87",
    shortpassing = "88",
    defensiveawareness = "71",
    shotpower = "91",
    longshots = "87",
    standingtackle = "77",
    slidingtackle = "63",
    volleys = "75",
    curve = "84",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17039496",
    trait2 = "0",
    icontrait1 = "32",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Juan Sebastián",
    lastname = "Verón",
    surname = "Verón",
    commonname = "Juan Sebastián Verón",
    playerjerseyname = "Verón"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Juan Sebastián Verón (ID: %s).", entry.playerid))
