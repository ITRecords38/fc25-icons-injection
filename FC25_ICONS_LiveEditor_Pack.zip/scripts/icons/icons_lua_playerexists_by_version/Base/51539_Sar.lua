-- ICON Player Script - PlayerExists Check Only
local playerid = 51539

if PlayerExists(playerid) then
    Log("Player with ID: 51539 exists")
else
    Log("Player with ID: 51539 doesn't exists")
end

local player_data = {
    playerid = "51539",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Sar",
    overallrating = "88",
    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "0",
    weakfootabilitytypecode = "3",
    acceleration = "39",
    sprintspeed = "38",
    agility = "41",
    balance = "44",
    jumping = "73",
    stamina = "41",
    strength = "74",
    reactions = "82",
    aggression = "25",
    composure = "64",
    interceptions = "24",
    positioning = "15",
    vision = "68",
    ballcontrol = "30",
    crossing = "10",
    dribbling = "8",
    finishing = "6",
    freekickaccuracy = "9",
    headingaccuracy = "10",
    longpassing = "46",
    shortpassing = "46",
    defensiveawareness = "10",
    shotpower = "59",
    longshots = "46",
    standingtackle = "10",
    slidingtackle = "10",
    volleys = "11",
    curve = "8",
    penalties = "17",
    gkdiving = "84",
    gkhandling = "87",
    gkkicking = "79",
    gkreflexes = "86",
    gkpositioning = "92",
    trait1 = "0",
    trait2 = "8",
    icontrait1 = "0",
    icontrait2 = "2",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Edwin van der",
    lastname = "Sar",
    surname = "Sar",
    commonname = "Edwin van der Sar",
    playerjerseyname = "Sar"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Edwin van der Sar (ID: %s).", entry.playerid))
