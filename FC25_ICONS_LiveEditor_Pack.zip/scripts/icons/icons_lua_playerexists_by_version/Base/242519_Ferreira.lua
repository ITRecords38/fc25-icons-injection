-- ICON Player Script - PlayerExists Check Only
local playerid = 242519

if PlayerExists(playerid) then
    Log("Player with ID: 242519 exists")
else
    Log("Player with ID: 242519 doesn't exists")
end

local player_data = {
    playerid = "242519",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ferreira",
    overallrating = "91",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "91",
    sprintspeed = "92",
    agility = "92",
    balance = "90",
    jumping = "86",
    stamina = "91",
    strength = "72",
    reactions = "92",
    aggression = "70",
    composure = "92",
    interceptions = "39",
    positioning = "93",
    vision = "86",
    ballcontrol = "87",
    crossing = "84",
    dribbling = "94",
    finishing = "92",
    freekickaccuracy = "85",
    headingaccuracy = "86",
    longpassing = "82",
    shortpassing = "84",
    defensiveawareness = "41",
    shotpower = "92",
    longshots = "82",
    standingtackle = "39",
    slidingtackle = "34",
    volleys = "92",
    curve = "81",
    penalties = "92",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4194308",
    trait2 = "0",
    icontrait1 = "131072",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Eusébio da Silva",
    lastname = "Ferreira",
    surname = "Ferreira",
    commonname = "Eusébio da Silva Ferreira",
    playerjerseyname = "Ferreira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Eusébio da Silva Ferreira (ID: %s).", entry.playerid))
