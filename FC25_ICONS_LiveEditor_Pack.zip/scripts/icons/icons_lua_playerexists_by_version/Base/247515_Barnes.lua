-- ICON Player Script - PlayerExists Check Only
local playerid = 247515

if PlayerExists(playerid) then
    Log("Player with ID: 247515 exists")
else
    Log("Player with ID: 247515 doesn't exists")
end

local player_data = {
    playerid = "247515",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Barnes",
    overallrating = "87",
    preferredposition1 = "27",
    preferredposition2 = "16",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "87",
    sprintspeed = "90",
    agility = "84",
    balance = "75",
    jumping = "70",
    stamina = "87",
    strength = "84",
    reactions = "85",
    aggression = "80",
    composure = "88",
    interceptions = "31",
    positioning = "85",
    vision = "84",
    ballcontrol = "90",
    crossing = "85",
    dribbling = "91",
    finishing = "87",
    freekickaccuracy = "85",
    headingaccuracy = "72",
    longpassing = "76",
    shortpassing = "84",
    defensiveawareness = "45",
    shotpower = "84",
    longshots = "76",
    standingtackle = "45",
    slidingtackle = "35",
    volleys = "82",
    curve = "83",
    penalties = "71",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21233697",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "John",
    lastname = "Barnes",
    surname = "Barnes",
    commonname = "John Barnes",
    playerjerseyname = "Barnes"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - John Barnes (ID: %s).", entry.playerid))
