-- ICON Player Script - PlayerExists Check Only
local playerid = 242510

if PlayerExists(playerid) then
    Log("Player with ID: 242510 exists")
else
    Log("Player with ID: 242510 doesn't exists")
end

local player_data = {
    playerid = "242510",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Klose",
    overallrating = "88",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "90",
    sprintspeed = "82",
    agility = "77",
    balance = "73",
    jumping = "91",
    stamina = "79",
    strength = "82",
    reactions = "91",
    aggression = "66",
    composure = "83",
    interceptions = "49",
    positioning = "90",
    vision = "71",
    ballcontrol = "81",
    crossing = "74",
    dribbling = "80",
    finishing = "92",
    freekickaccuracy = "70",
    headingaccuracy = "93",
    longpassing = "71",
    shortpassing = "77",
    defensiveawareness = "22",
    shotpower = "84",
    longshots = "71",
    standingtackle = "36",
    slidingtackle = "35",
    volleys = "89",
    curve = "67",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "46137361",
    trait2 = "0",
    icontrait1 = "134217728",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Miroslav",
    lastname = "Klose",
    surname = "Klose",
    commonname = "Miroslav Klose",
    playerjerseyname = "Klose"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Miroslav Klose (ID: %s).", entry.playerid))
