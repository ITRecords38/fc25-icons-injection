-- ICON Player Script - PlayerExists Check Only
local playerid = 45661

if PlayerExists(playerid) then
    Log("Player with ID: 45661 exists")
else
    Log("Player with ID: 45661 doesn't exists")
end

local player_data = {
    playerid = "45661",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Blanco",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "86",
    sprintspeed = "89",
    agility = "89",
    balance = "91",
    jumping = "93",
    stamina = "89",
    strength = "75",
    reactions = "93",
    aggression = "47",
    composure = "93",
    interceptions = "40",
    positioning = "96",
    vision = "95",
    ballcontrol = "93",
    crossing = "72",
    dribbling = "87",
    finishing = "96",
    freekickaccuracy = "79",
    headingaccuracy = "99",
    longpassing = "66",
    shortpassing = "90",
    defensiveawareness = "45",
    shotpower = "89",
    longshots = "66",
    standingtackle = "45",
    slidingtackle = "33",
    volleys = "91",
    curve = "77",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "156041222",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Raúl González",
    lastname = "Blanco",
    surname = "Blanco",
    commonname = "Raúl González Blanco",
    playerjerseyname = "Blanco"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Raúl González Blanco (ID: %s).", entry.playerid))
