-- ICON Player Script - PlayerExists Check Only
local playerid = 238430

if PlayerExists(playerid) then
    Log("Player with ID: 238430 exists")
else
    Log("Player with ID: 238430 doesn't exists")
end

local player_data = {
    playerid = "238430",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Rocha",
    overallrating = "90",
    preferredposition1 = "7",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "2",
    acceleration = "92",
    sprintspeed = "90",
    agility = "77",
    balance = "86",
    jumping = "83",
    stamina = "93",
    strength = "83",
    reactions = "91",
    aggression = "85",
    composure = "83",
    interceptions = "92",
    positioning = "69",
    vision = "74",
    ballcontrol = "85",
    crossing = "88",
    dribbling = "76",
    finishing = "75",
    freekickaccuracy = "96",
    headingaccuracy = "76",
    longpassing = "82",
    shortpassing = "83",
    defensiveawareness = "83",
    shotpower = "96",
    longshots = "82",
    standingtackle = "85",
    slidingtackle = "87",
    volleys = "75",
    curve = "96",
    penalties = "75",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "88211972",
    trait2 = "0",
    icontrait1 = "8",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Roberto Carlos da Silva",
    lastname = "Rocha",
    surname = "Rocha",
    commonname = "Roberto Carlos da Silva Rocha",
    playerjerseyname = "Rocha"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Roberto Carlos da Silva Rocha (ID: %s).", entry.playerid))
