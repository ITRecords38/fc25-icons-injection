-- ICON Player Script - PlayerExists Check Only
local playerid = 10535

if PlayerExists(playerid) then
    Log("Player with ID: 10535 exists")
else
    Log("Player with ID: 10535 doesn't exists")
end

local player_data = {
    playerid = "10535",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Creus",
    overallrating = "91",
    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "87",
    sprintspeed = "84",
    agility = "90",
    balance = "93",
    jumping = "65",
    stamina = "96",
    strength = "71",
    reactions = "94",
    aggression = "60",
    composure = "96",
    interceptions = "91",
    positioning = "93",
    vision = "96",
    ballcontrol = "95",
    crossing = "88",
    dribbling = "88",
    finishing = "80",
    freekickaccuracy = "85",
    headingaccuracy = "52",
    longpassing = "94",
    shortpassing = "95",
    defensiveawareness = "75",
    shotpower = "85",
    longshots = "94",
    standingtackle = "73",
    slidingtackle = "67",
    volleys = "71",
    curve = "84",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "19136704",
    trait2 = "0",
    icontrait1 = "288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Xavier Hernández",
    lastname = "Creus",
    surname = "Creus",
    commonname = "Xavier Hernández Creus",
    playerjerseyname = "Creus"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Xavier Hernández Creus (ID: %s).", entry.playerid))
