-- ICON Player Script - PlayerExists Check Only
local playerid = 227002

if PlayerExists(playerid) then
    Log("Player with ID: 227002 exists")
else
    Log("Player with ID: 227002 doesn't exists")
end

local player_data = {
    playerid = "227002",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Miyama",
    overallrating = "90",
    preferredposition1 = "16",
    preferredposition2 = "14",
    preferredposition3 = "27",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "85",
    sprintspeed = "84",
    agility = "91",
    balance = "92",
    jumping = "81",
    stamina = "87",
    strength = "65",
    reactions = "86",
    aggression = "58",
    composure = "85",
    interceptions = "61",
    positioning = "87",
    vision = "90",
    ballcontrol = "91",
    crossing = "87",
    dribbling = "89",
    finishing = "85",
    freekickaccuracy = "91",
    headingaccuracy = "71",
    longpassing = "87",
    shortpassing = "88",
    defensiveawareness = "50",
    shotpower = "87",
    longshots = "87",
    standingtackle = "66",
    slidingtackle = "58",
    volleys = "71",
    curve = "85",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17301537",
    trait2 = "0",
    icontrait1 = "8",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Aya",
    lastname = "Miyama",
    surname = "Miyama",
    commonname = "Aya Miyama",
    playerjerseyname = "Miyama"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Aya Miyama (ID: %s).", entry.playerid))
