-- ICON Player Script - PlayerExists Check Only
local playerid = 238382

if PlayerExists(playerid) then
    Log("Player with ID: 238382 exists")
else
    Log("Player with ID: 238382 doesn't exists")
end

local player_data = {
    playerid = "238382",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Piero",
    overallrating = "90",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "84",
    sprintspeed = "83",
    agility = "82",
    balance = "77",
    jumping = "57",
    stamina = "81",
    strength = "63",
    reactions = "87",
    aggression = "57",
    composure = "91",
    interceptions = "39",
    positioning = "92",
    vision = "92",
    ballcontrol = "93",
    crossing = "87",
    dribbling = "93",
    finishing = "93",
    freekickaccuracy = "89",
    headingaccuracy = "74",
    longpassing = "78",
    shortpassing = "87",
    defensiveawareness = "36",
    shotpower = "84",
    longshots = "78",
    standingtackle = "40",
    slidingtackle = "34",
    volleys = "85",
    curve = "88",
    penalties = "92",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "327688",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Alessandro Del",
    lastname = "Piero",
    surname = "Piero",
    commonname = "Alessandro Del Piero",
    playerjerseyname = "Piero"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Alessandro Del Piero (ID: %s).", entry.playerid))
