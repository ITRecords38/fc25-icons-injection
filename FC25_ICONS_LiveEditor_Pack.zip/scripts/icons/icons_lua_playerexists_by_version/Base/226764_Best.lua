-- ICON Player Script - PlayerExists Check Only
local playerid = 226764

if PlayerExists(playerid) then
    Log("Player with ID: 226764 exists")
else
    Log("Player with ID: 226764 doesn't exists")
end

local player_data = {
    playerid = "226764",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Best",
    overallrating = "90",
    preferredposition1 = "23",
    preferredposition2 = "12",
    preferredposition3 = "18",
    preferredposition4 = "27",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "92",
    sprintspeed = "90",
    agility = "91",
    balance = "89",
    jumping = "77",
    stamina = "85",
    strength = "65",
    reactions = "88",
    aggression = "52",
    composure = "90",
    interceptions = "61",
    positioning = "86",
    vision = "83",
    ballcontrol = "93",
    crossing = "86",
    dribbling = "93",
    finishing = "91",
    freekickaccuracy = "73",
    headingaccuracy = "83",
    longpassing = "77",
    shortpassing = "82",
    defensiveawareness = "50",
    shotpower = "86",
    longshots = "77",
    standingtackle = "51",
    slidingtackle = "48",
    volleys = "85",
    curve = "80",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4980736",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "George",
    lastname = "Best",
    surname = "Best",
    commonname = "George Best",
    playerjerseyname = "Best"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - George Best (ID: %s).", entry.playerid))
