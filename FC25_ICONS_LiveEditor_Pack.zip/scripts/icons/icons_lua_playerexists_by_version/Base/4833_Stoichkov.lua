-- ICON Player Script - PlayerExists Check Only
local playerid = 4833

if PlayerExists(playerid) then
    Log("Player with ID: 4833 exists")
else
    Log("Player with ID: 4833 doesn't exists")
end

local player_data = {
    playerid = "4833",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Stoichkov",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "23",
    preferredposition3 = "27",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "3",
    acceleration = "91",
    sprintspeed = "89",
    agility = "88",
    balance = "82",
    jumping = "77",
    stamina = "84",
    strength = "81",
    reactions = "87",
    aggression = "91",
    composure = "87",
    interceptions = "52",
    positioning = "90",
    vision = "87",
    ballcontrol = "90",
    crossing = "84",
    dribbling = "91",
    finishing = "92",
    freekickaccuracy = "88",
    headingaccuracy = "80",
    longpassing = "81",
    shortpassing = "83",
    defensiveawareness = "35",
    shotpower = "90",
    longshots = "81",
    standingtackle = "52",
    slidingtackle = "47",
    volleys = "90",
    curve = "88",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "262153",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Hristo",
    lastname = "Stoichkov",
    surname = "Stoichkov",
    commonname = "Hristo Stoichkov",
    playerjerseyname = "Stoichkov"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Hristo Stoichkov (ID: %s).", entry.playerid))
