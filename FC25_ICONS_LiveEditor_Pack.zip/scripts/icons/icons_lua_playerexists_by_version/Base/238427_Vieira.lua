-- ICON Player Script - PlayerExists Check Only
local playerid = 238427

if PlayerExists(playerid) then
    Log("Player with ID: 238427 exists")
else
    Log("Player with ID: 238427 doesn't exists")
end

local player_data = {
    playerid = "238427",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Vieira",
    overallrating = "88",
    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "83",
    sprintspeed = "82",
    agility = "73",
    balance = "66",
    jumping = "79",
    stamina = "93",
    strength = "89",
    reactions = "88",
    aggression = "91",
    composure = "88",
    interceptions = "92",
    positioning = "77",
    vision = "87",
    ballcontrol = "87",
    crossing = "65",
    dribbling = "82",
    finishing = "75",
    freekickaccuracy = "58",
    headingaccuracy = "82",
    longpassing = "87",
    shortpassing = "87",
    defensiveawareness = "84",
    shotpower = "83",
    longshots = "87",
    standingtackle = "92",
    slidingtackle = "85",
    volleys = "66",
    curve = "64",
    penalties = "73",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10539024",
    trait2 = "0",
    icontrait1 = "2048",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Patrick",
    lastname = "Vieira",
    surname = "Vieira",
    commonname = "Patrick Vieira",
    playerjerseyname = "Vieira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Patrick Vieira (ID: %s).", entry.playerid))
