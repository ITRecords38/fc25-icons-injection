-- ICON Player Script - PlayerExists Check Only
local playerid = 167198

if PlayerExists(playerid) then
    Log("Player with ID: 167198 exists")
else
    Log("Player with ID: 167198 doesn't exists")
end

local player_data = {
    playerid = "167198",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Cantona",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "85",
    sprintspeed = "86",
    agility = "82",
    balance = "82",
    jumping = "88",
    stamina = "87",
    strength = "88",
    reactions = "87",
    aggression = "90",
    composure = "93",
    interceptions = "46",
    positioning = "89",
    vision = "90",
    ballcontrol = "91",
    crossing = "85",
    dribbling = "89",
    finishing = "88",
    freekickaccuracy = "84",
    headingaccuracy = "87",
    longpassing = "82",
    shortpassing = "85",
    defensiveawareness = "39",
    shotpower = "91",
    longshots = "82",
    standingtackle = "51",
    slidingtackle = "48",
    volleys = "94",
    curve = "88",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17629218",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Eric",
    lastname = "Cantona",
    surname = "Cantona",
    commonname = "Eric Cantona",
    playerjerseyname = "Cantona"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Eric Cantona (ID: %s).", entry.playerid))
