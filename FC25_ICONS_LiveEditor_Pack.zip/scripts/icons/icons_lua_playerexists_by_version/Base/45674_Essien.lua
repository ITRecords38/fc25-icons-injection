-- ICON Player Script - PlayerExists Check Only
local playerid = 45674

if PlayerExists(playerid) then
    Log("Player with ID: 45674 exists")
else
    Log("Player with ID: 45674 doesn't exists")
end

local player_data = {
    playerid = "45674",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Essien",
    overallrating = "86",
    preferredposition1 = "10",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "83",
    sprintspeed = "81",
    agility = "72",
    balance = "83",
    jumping = "81",
    stamina = "89",
    strength = "85",
    reactions = "81",
    aggression = "84",
    composure = "81",
    interceptions = "89",
    positioning = "72",
    vision = "72",
    ballcontrol = "85",
    crossing = "67",
    dribbling = "73",
    finishing = "64",
    freekickaccuracy = "54",
    headingaccuracy = "70",
    longpassing = "83",
    shortpassing = "87",
    defensiveawareness = "85",
    shotpower = "84",
    longshots = "83",
    standingtackle = "88",
    slidingtackle = "87",
    volleys = "75",
    curve = "63",
    penalties = "60",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10493988",
    trait2 = "0",
    icontrait1 = "1024",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Michaël",
    lastname = "Essien",
    surname = "Essien",
    commonname = "Michaël Essien",
    playerjerseyname = "Essien"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Michaël Essien (ID: %s).", entry.playerid))
