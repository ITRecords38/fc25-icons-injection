-- ICON Player Script - PlayerExists Check Only
local playerid = 156616

if PlayerExists(playerid) then
    Log("Player with ID: 156616 exists")
else
    Log("Player with ID: 156616 doesn't exists")
end

local player_data = {
    playerid = "156616",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ribéry",
    overallrating = "88",
    preferredposition1 = "16",
    preferredposition2 = "27",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "88",
    agility = "89",
    balance = "88",
    jumping = "50",
    stamina = "78",
    strength = "62",
    reactions = "86",
    aggression = "61",
    composure = "86",
    interceptions = "36",
    positioning = "84",
    vision = "88",
    ballcontrol = "91",
    crossing = "79",
    dribbling = "91",
    finishing = "85",
    freekickaccuracy = "84",
    headingaccuracy = "46",
    longpassing = "81",
    shortpassing = "88",
    defensiveawareness = "38",
    shotpower = "82",
    longshots = "81",
    standingtackle = "35",
    slidingtackle = "31",
    volleys = "87",
    curve = "81",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21233704",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Franck",
    lastname = "Ribéry",
    surname = "Ribéry",
    commonname = "Franck Ribéry",
    playerjerseyname = "Ribéry"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Franck Ribéry (ID: %s).", entry.playerid))
