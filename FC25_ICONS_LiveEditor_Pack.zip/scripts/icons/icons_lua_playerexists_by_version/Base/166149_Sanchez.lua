-- ICON Player Script - PlayerExists Check Only
local playerid = 166149

if PlayerExists(playerid) then
    Log("Player with ID: 166149 exists")
else
    Log("Player with ID: 166149 doesn't exists")
end

local player_data = {
    playerid = "166149",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Sánchez",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "89",
    agility = "90",
    balance = "87",
    jumping = "84",
    stamina = "76",
    strength = "72",
    reactions = "86",
    aggression = "64",
    composure = "82",
    interceptions = "42",
    positioning = "86",
    vision = "80",
    ballcontrol = "87",
    crossing = "82",
    dribbling = "90",
    finishing = "91",
    freekickaccuracy = "86",
    headingaccuracy = "90",
    longpassing = "55",
    shortpassing = "82",
    defensiveawareness = "35",
    shotpower = "91",
    longshots = "55",
    standingtackle = "34",
    slidingtackle = "32",
    volleys = "95",
    curve = "81",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "135004188",
    trait2 = "0",
    icontrait1 = "33554432",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Hugo",
    lastname = "Sánchez",
    surname = "Sánchez",
    commonname = "Hugo Sánchez",
    playerjerseyname = "Sánchez"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Hugo Sánchez (ID: %s).", entry.playerid))
