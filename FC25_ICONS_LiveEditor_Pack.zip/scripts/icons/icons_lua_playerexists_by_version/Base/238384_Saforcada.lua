-- ICON Player Script - PlayerExists Check Only
local playerid = 238384

if PlayerExists(playerid) then
    Log("Player with ID: 238384 exists")
else
    Log("Player with ID: 238384 doesn't exists")
end

local player_data = {
    playerid = "238384",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Saforcada",
    overallrating = "90",
    preferredposition1 = "10",
    preferredposition2 = "5",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "80",
    sprintspeed = "80",
    agility = "78",
    balance = "78",
    jumping = "85",
    stamina = "84",
    strength = "92",
    reactions = "88",
    aggression = "89",
    composure = "83",
    interceptions = "94",
    positioning = "40",
    vision = "68",
    ballcontrol = "82",
    crossing = "83",
    dribbling = "74",
    finishing = "40",
    freekickaccuracy = "56",
    headingaccuracy = "91",
    longpassing = "87",
    shortpassing = "91",
    defensiveawareness = "91",
    shotpower = "71",
    longshots = "87",
    standingtackle = "93",
    slidingtackle = "89",
    volleys = "41",
    curve = "60",
    penalties = "54",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "142617616",
    trait2 = "0",
    icontrait1 = "16384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Carles Puyol",
    lastname = "Saforcada",
    surname = "Saforcada",
    commonname = "Carles Puyol Saforcada",
    playerjerseyname = "Saforcada"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Carles Puyol Saforcada (ID: %s).", entry.playerid))
