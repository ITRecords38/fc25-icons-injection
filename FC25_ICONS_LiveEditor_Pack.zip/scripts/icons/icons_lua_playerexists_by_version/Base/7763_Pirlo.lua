-- ICON Player Script - PlayerExists Check Only
local playerid = 7763

if PlayerExists(playerid) then
    Log("Player with ID: 7763 exists")
else
    Log("Player with ID: 7763 doesn't exists")
end

local player_data = {
    playerid = "7763",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Pirlo",
    overallrating = "90",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "74",
    sprintspeed = "72",
    agility = "83",
    balance = "75",
    jumping = "57",
    stamina = "83",
    strength = "64",
    reactions = "93",
    aggression = "53",
    composure = "94",
    interceptions = "77",
    positioning = "85",
    vision = "94",
    ballcontrol = "93",
    crossing = "88",
    dribbling = "89",
    finishing = "76",
    freekickaccuracy = "94",
    headingaccuracy = "56",
    longpassing = "94",
    shortpassing = "94",
    defensiveawareness = "72",
    shotpower = "79",
    longshots = "94",
    standingtackle = "67",
    slidingtackle = "64",
    volleys = "77",
    curve = "92",
    penalties = "89",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "786440",
    trait2 = "0",
    icontrait1 = "128",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Andrea",
    lastname = "Pirlo",
    surname = "Pirlo",
    commonname = "Andrea Pirlo",
    playerjerseyname = "Pirlo"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Andrea Pirlo (ID: %s).", entry.playerid))
