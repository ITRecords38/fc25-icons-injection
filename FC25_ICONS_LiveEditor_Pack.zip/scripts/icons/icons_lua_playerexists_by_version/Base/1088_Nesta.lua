-- ICON Player Script - PlayerExists Check Only
local playerid = 1088

if PlayerExists(playerid) then
    Log("Player with ID: 1088 exists")
else
    Log("Player with ID: 1088 doesn't exists")
end

local player_data = {
    playerid = "1088",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Nesta",
    overallrating = "89",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "72",
    sprintspeed = "79",
    agility = "56",
    balance = "55",
    jumping = "83",
    stamina = "72",
    strength = "89",
    reactions = "86",
    aggression = "85",
    composure = "83",
    interceptions = "91",
    positioning = "36",
    vision = "56",
    ballcontrol = "76",
    crossing = "53",
    dribbling = "64",
    finishing = "41",
    freekickaccuracy = "32",
    headingaccuracy = "84",
    longpassing = "68",
    shortpassing = "77",
    defensiveawareness = "93",
    shotpower = "52",
    longshots = "68",
    standingtackle = "93",
    slidingtackle = "92",
    volleys = "42",
    curve = "45",
    penalties = "51",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "167780352",
    trait2 = "0",
    icontrait1 = "16384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Alessandro",
    lastname = "Nesta",
    surname = "Nesta",
    commonname = "Alessandro Nesta",
    playerjerseyname = "Nesta"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Alessandro Nesta (ID: %s).", entry.playerid))
