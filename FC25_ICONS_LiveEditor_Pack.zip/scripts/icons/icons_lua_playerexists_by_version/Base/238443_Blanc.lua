-- ICON Player Script - PlayerExists Check Only
local playerid = 238443

if PlayerExists(playerid) then
    Log("Player with ID: 238443 exists")
else
    Log("Player with ID: 238443 doesn't exists")
end

local player_data = {
    playerid = "238443",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Blanc",
    overallrating = "88",
    preferredposition1 = "5",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "76",
    sprintspeed = "80",
    agility = "69",
    balance = "68",
    jumping = "76",
    stamina = "87",
    strength = "84",
    reactions = "87",
    aggression = "86",
    composure = "84",
    interceptions = "89",
    positioning = "59",
    vision = "56",
    ballcontrol = "85",
    crossing = "55",
    dribbling = "70",
    finishing = "66",
    freekickaccuracy = "71",
    headingaccuracy = "84",
    longpassing = "80",
    shortpassing = "79",
    defensiveawareness = "91",
    shotpower = "76",
    longshots = "80",
    standingtackle = "92",
    slidingtackle = "87",
    volleys = "66",
    curve = "61",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134251520",
    trait2 = "0",
    icontrait1 = "8192",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Laurent",
    lastname = "Blanc",
    surname = "Blanc",
    commonname = "Laurent Blanc",
    playerjerseyname = "Blanc"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Laurent Blanc (ID: %s).", entry.playerid))
