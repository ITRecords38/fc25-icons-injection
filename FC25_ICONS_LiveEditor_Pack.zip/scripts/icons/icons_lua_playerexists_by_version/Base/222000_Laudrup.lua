-- ICON Player Script - PlayerExists Check Only
local playerid = 222000

if PlayerExists(playerid) then
    Log("Player with ID: 222000 exists")
else
    Log("Player with ID: 222000 doesn't exists")
end

local player_data = {
    playerid = "222000",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Laudrup",
    overallrating = "88",
    preferredposition1 = "18",
    preferredposition2 = "27",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "85",
    sprintspeed = "83",
    agility = "85",
    balance = "80",
    jumping = "63",
    stamina = "76",
    strength = "65",
    reactions = "87",
    aggression = "40",
    composure = "89",
    interceptions = "35",
    positioning = "83",
    vision = "92",
    ballcontrol = "91",
    crossing = "91",
    dribbling = "92",
    finishing = "80",
    freekickaccuracy = "77",
    headingaccuracy = "66",
    longpassing = "79",
    shortpassing = "89",
    defensiveawareness = "36",
    shotpower = "75",
    longshots = "79",
    standingtackle = "39",
    slidingtackle = "36",
    volleys = "83",
    curve = "87",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "786465",
    trait2 = "0",
    icontrait1 = "1048576",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Michael",
    lastname = "Laudrup",
    surname = "Laudrup",
    commonname = "Michael Laudrup",
    playerjerseyname = "Laudrup"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Michael Laudrup (ID: %s).", entry.playerid))
