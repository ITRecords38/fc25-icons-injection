-- ICON Player Script - PlayerExists Check Only
local playerid = 238439

if PlayerExists(playerid) then
    Log("Player with ID: 238439 exists")
else
    Log("Player with ID: 238439 doesn't exists")
end

local player_data = {
    playerid = "238439",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Maldini",
    overallrating = "92",
    preferredposition1 = "5",
    preferredposition2 = "7",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "4",
    acceleration = "84",
    sprintspeed = "85",
    agility = "65",
    balance = "68",
    jumping = "83",
    stamina = "80",
    strength = "84",
    reactions = "94",
    aggression = "78",
    composure = "94",
    interceptions = "95",
    positioning = "39",
    vision = "68",
    ballcontrol = "73",
    crossing = "75",
    dribbling = "62",
    finishing = "56",
    freekickaccuracy = "30",
    headingaccuracy = "93",
    longpassing = "78",
    shortpassing = "86",
    defensiveawareness = "94",
    shotpower = "72",
    longshots = "78",
    standingtackle = "96",
    slidingtackle = "95",
    volleys = "64",
    curve = "40",
    penalties = "53",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134231040",
    trait2 = "0",
    icontrait1 = "16384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Paolo",
    lastname = "Maldini",
    surname = "Maldini",
    commonname = "Paolo Maldini",
    playerjerseyname = "Maldini"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Paolo Maldini (ID: %s).", entry.playerid))
