-- ICON Player Script - PlayerExists Check Only
local playerid = 237067

if PlayerExists(playerid) then
    Log("Player with ID: 237067 exists")
else
    Log("Player with ID: 237067 doesn't exists")
end

local player_data = {
    playerid = "237067",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Nascimento",
    overallrating = "95",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "93",
    agility = "92",
    balance = "91",
    jumping = "86",
    stamina = "85",
    strength = "74",
    reactions = "96",
    aggression = "57",
    composure = "96",
    interceptions = "65",
    positioning = "95",
    vision = "95",
    ballcontrol = "95",
    crossing = "88",
    dribbling = "94",
    finishing = "96",
    freekickaccuracy = "87",
    headingaccuracy = "92",
    longpassing = "86",
    shortpassing = "94",
    defensiveawareness = "54",
    shotpower = "93",
    longshots = "86",
    standingtackle = "50",
    slidingtackle = "47",
    volleys = "94",
    curve = "87",
    penalties = "91",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "5242917",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Edson Arantes",
    lastname = "Nascimento",
    surname = "Nascimento",
    commonname = "Edson Arantes Nascimento",
    playerjerseyname = "Nascimento"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Edson Arantes Nascimento (ID: %s).", entry.playerid))
