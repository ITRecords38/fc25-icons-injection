-- ICON Player Script - PlayerExists Check Only
local playerid = 1625

if PlayerExists(playerid) then
    Log("Player with ID: 1625 exists")
else
    Log("Player with ID: 1625 doesn't exists")
end

local player_data = {
    playerid = "1625",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Henry",
    overallrating = "91",
    preferredposition1 = "25",
    preferredposition2 = "27",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "93",
    agility = "88",
    balance = "76",
    jumping = "69",
    stamina = "86",
    strength = "81",
    reactions = "90",
    aggression = "62",
    composure = "85",
    interceptions = "51",
    positioning = "92",
    vision = "80",
    ballcontrol = "92",
    crossing = "78",
    dribbling = "89",
    finishing = "93",
    freekickaccuracy = "85",
    headingaccuracy = "84",
    longpassing = "74",
    shortpassing = "86",
    defensiveawareness = "44",
    shotpower = "87",
    longshots = "74",
    standingtackle = "49",
    slidingtackle = "43",
    volleys = "89",
    curve = "92",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21757953",
    trait2 = "0",
    icontrait1 = "131072",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Thierry",
    lastname = "Henry",
    surname = "Henry",
    commonname = "Thierry Henry",
    playerjerseyname = "Henry"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Thierry Henry (ID: %s).", entry.playerid))
