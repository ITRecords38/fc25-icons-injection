-- ICON Player Script - PlayerExists Check Only
local playerid = 238388

if PlayerExists(playerid) then
    Log("Player with ID: 238388 exists")
else
    Log("Player with ID: 238388 doesn't exists")
end

local player_data = {
    playerid = "238388",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Bergkamp",
    overallrating = "90",
    preferredposition1 = "25",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "84",
    sprintspeed = "82",
    agility = "80",
    balance = "80",
    jumping = "76",
    stamina = "80",
    strength = "75",
    reactions = "93",
    aggression = "72",
    composure = "93",
    interceptions = "31",
    positioning = "92",
    vision = "89",
    ballcontrol = "92",
    crossing = "82",
    dribbling = "87",
    finishing = "91",
    freekickaccuracy = "82",
    headingaccuracy = "62",
    longpassing = "75",
    shortpassing = "88",
    defensiveawareness = "26",
    shotpower = "89",
    longshots = "75",
    standingtackle = "39",
    slidingtackle = "34",
    volleys = "91",
    curve = "80",
    penalties = "92",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17039395",
    trait2 = "0",
    icontrait1 = "524288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Dennis",
    lastname = "Bergkamp",
    surname = "Bergkamp",
    commonname = "Dennis Bergkamp",
    playerjerseyname = "Bergkamp"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Dennis Bergkamp (ID: %s).", entry.playerid))
