-- ICON Player Script - PlayerExists Check Only
local playerid = 1114

if PlayerExists(playerid) then
    Log("Player with ID: 1114 exists")
else
    Log("Player with ID: 1114 doesn't exists")
end

local player_data = {
    playerid = "1114",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Baggio",
    overallrating = "92",
    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "87",
    sprintspeed = "83",
    agility = "81",
    balance = "82",
    jumping = "68",
    stamina = "80",
    strength = "64",
    reactions = "88",
    aggression = "42",
    composure = "85",
    interceptions = "40",
    positioning = "87",
    vision = "94",
    ballcontrol = "95",
    crossing = "86",
    dribbling = "94",
    finishing = "87",
    freekickaccuracy = "90",
    headingaccuracy = "76",
    longpassing = "90",
    shortpassing = "93",
    defensiveawareness = "40",
    shotpower = "73",
    longshots = "90",
    standingtackle = "35",
    slidingtackle = "35",
    volleys = "84",
    curve = "93",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2883721",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Roberto",
    lastname = "Baggio",
    surname = "Baggio",
    commonname = "Roberto Baggio",
    playerjerseyname = "Baggio"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Roberto Baggio (ID: %s).", entry.playerid))
