-- ICON Player Script - PlayerExists Check Only
local playerid = 275243

if PlayerExists(playerid) then
    Log("Player with ID: 275243 exists")
else
    Log("Player with ID: 275243 doesn't exists")
end

local player_data = {
    playerid = "275243",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Hamm",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "18",
    preferredposition3 = "23",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "95",
    sprintspeed = "93",
    agility = "86",
    balance = "88",
    jumping = "85",
    stamina = "92",
    strength = "84",
    reactions = "92",
    aggression = "70",
    composure = "88",
    interceptions = "53",
    positioning = "90",
    vision = "86",
    ballcontrol = "90",
    crossing = "75",
    dribbling = "91",
    finishing = "90",
    freekickaccuracy = "88",
    headingaccuracy = "81",
    longpassing = "84",
    shortpassing = "88",
    defensiveawareness = "43",
    shotpower = "90",
    longshots = "84",
    standingtackle = "52",
    slidingtackle = "49",
    volleys = "86",
    curve = "83",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "9306117",
    trait2 = "0",
    icontrait1 = "4194304",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Mia",
    lastname = "Hamm",
    surname = "Hamm",
    commonname = "Mia Hamm",
    playerjerseyname = "Hamm"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Mia Hamm (ID: %s).", entry.playerid))
