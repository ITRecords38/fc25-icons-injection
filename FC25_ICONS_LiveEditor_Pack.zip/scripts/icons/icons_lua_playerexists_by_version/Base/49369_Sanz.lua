-- ICON Player Script - PlayerExists Check Only
local playerid = 49369

if PlayerExists(playerid) then
    Log("Player with ID: 49369 exists")
else
    Log("Player with ID: 49369 doesn't exists")
end

local player_data = {
    playerid = "49369",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Sanz",
    overallrating = "87",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "88",
    agility = "85",
    balance = "80",
    jumping = "81",
    stamina = "82",
    strength = "75",
    reactions = "91",
    aggression = "63",
    composure = "86",
    interceptions = "36",
    positioning = "90",
    vision = "85",
    ballcontrol = "83",
    crossing = "75",
    dribbling = "85",
    finishing = "92",
    freekickaccuracy = "65",
    headingaccuracy = "80",
    longpassing = "56",
    shortpassing = "79",
    defensiveawareness = "35",
    shotpower = "84",
    longshots = "56",
    standingtackle = "44",
    slidingtackle = "38",
    volleys = "82",
    curve = "76",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21364754",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Fernando José Torres",
    lastname = "Sanz",
    surname = "Sanz",
    commonname = "Fernando José Torres Sanz",
    playerjerseyname = "Sanz"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Fernando José Torres Sanz (ID: %s).", entry.playerid))
