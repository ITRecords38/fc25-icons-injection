-- ICON Player Script - PlayerExists Check Only
local playerid = 247703

if PlayerExists(playerid) then
    Log("Player with ID: 247703 exists")
else
    Log("Player with ID: 247703 doesn't exists")
end

local player_data = {
    playerid = "247703",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Rush",
    overallrating = "87",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "82",
    sprintspeed = "85",
    agility = "77",
    balance = "76",
    jumping = "84",
    stamina = "81",
    strength = "79",
    reactions = "88",
    aggression = "72",
    composure = "89",
    interceptions = "32",
    positioning = "90",
    vision = "75",
    ballcontrol = "87",
    crossing = "64",
    dribbling = "82",
    finishing = "91",
    freekickaccuracy = "68",
    headingaccuracy = "89",
    longpassing = "52",
    shortpassing = "74",
    defensiveawareness = "37",
    shotpower = "85",
    longshots = "52",
    standingtackle = "45",
    slidingtackle = "31",
    volleys = "90",
    curve = "75",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "150994963",
    trait2 = "0",
    icontrait1 = "524288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ian",
    lastname = "Rush",
    surname = "Rush",
    commonname = "Ian Rush",
    playerjerseyname = "Rush"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ian Rush (ID: %s).", entry.playerid))
