-- ICON Player Script - PlayerExists Check Only
local playerid = 166691

if PlayerExists(playerid) then
    Log("Player with ID: 166691 exists")
else
    Log("Player with ID: 166691 doesn't exists")
end

local player_data = {
    playerid = "166691",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Coimbra",
    overallrating = "91",
    preferredposition1 = "18",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "87",
    sprintspeed = "90",
    agility = "89",
    balance = "85",
    jumping = "77",
    stamina = "81",
    strength = "75",
    reactions = "89",
    aggression = "45",
    composure = "89",
    interceptions = "61",
    positioning = "89",
    vision = "93",
    ballcontrol = "93",
    crossing = "86",
    dribbling = "92",
    finishing = "92",
    freekickaccuracy = "97",
    headingaccuracy = "73",
    longpassing = "87",
    shortpassing = "93",
    defensiveawareness = "56",
    shotpower = "92",
    longshots = "87",
    standingtackle = "66",
    slidingtackle = "60",
    volleys = "90",
    curve = "94",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17105184",
    trait2 = "0",
    icontrait1 = "8",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Arthur Antunes",
    lastname = "Coimbra",
    surname = "Coimbra",
    commonname = "Arthur Antunes Coimbra",
    playerjerseyname = "Coimbra"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Arthur Antunes Coimbra (ID: %s).", entry.playerid))
