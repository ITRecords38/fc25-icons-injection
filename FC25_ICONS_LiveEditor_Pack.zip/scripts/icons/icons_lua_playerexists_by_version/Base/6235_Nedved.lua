-- ICON Player Script - PlayerExists Check Only
local playerid = 6235

if PlayerExists(playerid) then
    Log("Player with ID: 6235 exists")
else
    Log("Player with ID: 6235 doesn't exists")
end

local player_data = {
    playerid = "6235",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Nedvěd",
    overallrating = "88",
    preferredposition1 = "16",
    preferredposition2 = "18",
    preferredposition3 = "27",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "84",
    sprintspeed = "84",
    agility = "80",
    balance = "77",
    jumping = "66",
    stamina = "88",
    strength = "71",
    reactions = "85",
    aggression = "81",
    composure = "82",
    interceptions = "62",
    positioning = "85",
    vision = "87",
    ballcontrol = "90",
    crossing = "86",
    dribbling = "89",
    finishing = "80",
    freekickaccuracy = "85",
    headingaccuracy = "74",
    longpassing = "85",
    shortpassing = "86",
    defensiveawareness = "61",
    shotpower = "88",
    longshots = "85",
    standingtackle = "51",
    slidingtackle = "48",
    volleys = "80",
    curve = "84",
    penalties = "82",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "9043976",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Pavel",
    lastname = "Nedvěd",
    surname = "Nedvěd",
    commonname = "Pavel Nedvěd",
    playerjerseyname = "Nedvěd"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Pavel Nedvěd (ID: %s).", entry.playerid))
