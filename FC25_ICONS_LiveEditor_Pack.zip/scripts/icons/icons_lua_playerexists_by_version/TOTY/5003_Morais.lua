-- ICON Player Script - PlayerExists Check Only
local playerid = 5003

if PlayerExists(playerid) then
    Log("Player with ID: 5003 exists")
else
    Log("Player with ID: 5003 doesn't exists")
end

local player_data = {
    playerid = "5003",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Morais",
    overallrating = "93",
    preferredposition1 = "3",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "94",
    sprintspeed = "93",
    agility = "85",
    balance = "85",
    jumping = "90",
    stamina = "97",
    strength = "90",
    reactions = "93",
    aggression = "81",
    composure = "90",
    interceptions = "94",
    positioning = "72",
    vision = "84",
    ballcontrol = "91",
    crossing = "93",
    dribbling = "91",
    finishing = "70",
    freekickaccuracy = "63",
    headingaccuracy = "82",
    longpassing = "73",
    shortpassing = "90",
    defensiveawareness = "92",
    shotpower = "71",
    longshots = "73",
    standingtackle = "94",
    slidingtackle = "90",
    volleys = "70",
    curve = "80",
    penalties = "73",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "86309376",
    trait2 = "0",
    icontrait1 = "8389632",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marcos de",
    lastname = "Morais",
    surname = "Morais",
    commonname = "Marcos de Morais",
    playerjerseyname = "Morais"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marcos de Morais (ID: %s).", entry.playerid))
