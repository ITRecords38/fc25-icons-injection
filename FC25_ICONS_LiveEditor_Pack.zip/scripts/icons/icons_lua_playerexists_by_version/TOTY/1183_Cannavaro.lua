-- ICON Player Script - PlayerExists Check Only
local playerid = 1183

if PlayerExists(playerid) then
    Log("Player with ID: 1183 exists")
else
    Log("Player with ID: 1183 doesn't exists")
end

local player_data = {
    playerid = "1183",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Cannavaro",
    overallrating = "91",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "85",
    agility = "88",
    balance = "86",
    jumping = "96",
    stamina = "85",
    strength = "93",
    reactions = "91",
    aggression = "92",
    composure = "86",
    interceptions = "95",
    positioning = "40",
    vision = "63",
    ballcontrol = "73",
    crossing = "70",
    dribbling = "70",
    finishing = "43",
    freekickaccuracy = "43",
    headingaccuracy = "90",
    longpassing = "81",
    shortpassing = "85",
    defensiveawareness = "94",
    shotpower = "64",
    longshots = "81",
    standingtackle = "94",
    slidingtackle = "93",
    volleys = "47",
    curve = "73",
    penalties = "58",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "144730112",
    trait2 = "0",
    icontrait1 = "33558528",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Fabio",
    lastname = "Cannavaro",
    surname = "Cannavaro",
    commonname = "Fabio Cannavaro",
    playerjerseyname = "Cannavaro"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Fabio Cannavaro (ID: %s).", entry.playerid))
