-- ICON Player Script - PlayerExists Check Only
local playerid = 1625

if PlayerExists(playerid) then
    Log("Player with ID: 1625 exists")
else
    Log("Player with ID: 1625 doesn't exists")
end

local player_data = {
    playerid = "1625",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Henry",
    overallrating = "93",
    preferredposition1 = "25",
    preferredposition2 = "27",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "94",
    sprintspeed = "94",
    agility = "92",
    balance = "80",
    jumping = "82",
    stamina = "97",
    strength = "93",
    reactions = "94",
    aggression = "75",
    composure = "90",
    interceptions = "61",
    positioning = "95",
    vision = "91",
    ballcontrol = "94",
    crossing = "90",
    dribbling = "93",
    finishing = "96",
    freekickaccuracy = "96",
    headingaccuracy = "90",
    longpassing = "86",
    shortpassing = "97",
    defensiveawareness = "54",
    shotpower = "90",
    longshots = "86",
    standingtackle = "59",
    slidingtackle = "53",
    volleys = "92",
    curve = "97",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "33357842",
    trait2 = "0",
    icontrait1 = "131073",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Thierry",
    lastname = "Henry",
    surname = "Henry",
    commonname = "Thierry Henry",
    playerjerseyname = "Henry"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Thierry Henry (ID: %s).", entry.playerid))
