-- ICON Player Script - PlayerExists Check Only
local playerid = 227002

if PlayerExists(playerid) then
    Log("Player with ID: 227002 exists")
else
    Log("Player with ID: 227002 doesn't exists")
end

local player_data = {
    playerid = "227002",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Miyama",
    overallrating = "92",
    preferredposition1 = "16",
    preferredposition2 = "14",
    preferredposition3 = "27",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "90",
    agility = "93",
    balance = "93",
    jumping = "91",
    stamina = "95",
    strength = "80",
    reactions = "88",
    aggression = "74",
    composure = "87",
    interceptions = "70",
    positioning = "90",
    vision = "92",
    ballcontrol = "93",
    crossing = "90",
    dribbling = "91",
    finishing = "90",
    freekickaccuracy = "93",
    headingaccuracy = "82",
    longpassing = "90",
    shortpassing = "90",
    defensiveawareness = "60",
    shotpower = "90",
    longshots = "90",
    standingtackle = "76",
    slidingtackle = "65",
    volleys = "88",
    curve = "87",
    penalties = "93",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "25756576",
    trait2 = "0",
    icontrait1 = "9",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Aya",
    lastname = "Miyama",
    surname = "Miyama",
    commonname = "Aya Miyama",
    playerjerseyname = "Miyama"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Aya Miyama (ID: %s).", entry.playerid))
