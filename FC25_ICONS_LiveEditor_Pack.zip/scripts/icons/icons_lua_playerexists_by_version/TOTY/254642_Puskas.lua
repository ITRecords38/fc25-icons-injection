-- ICON Player Script - PlayerExists Check Only
local playerid = 254642

if PlayerExists(playerid) then
    Log("Player with ID: 254642 exists")
else
    Log("Player with ID: 254642 doesn't exists")
end

local player_data = {
    playerid = "254642",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Puskás",
    overallrating = "94",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "91",
    agility = "93",
    balance = "94",
    jumping = "85",
    stamina = "94",
    strength = "93",
    reactions = "98",
    aggression = "70",
    composure = "98",
    interceptions = "50",
    positioning = "97",
    vision = "94",
    ballcontrol = "96",
    crossing = "90",
    dribbling = "93",
    finishing = "96",
    freekickaccuracy = "88",
    headingaccuracy = "81",
    longpassing = "90",
    shortpassing = "93",
    defensiveawareness = "50",
    shotpower = "95",
    longshots = "90",
    standingtackle = "52",
    slidingtackle = "45",
    volleys = "93",
    curve = "93",
    penalties = "93",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "23527810",
    trait2 = "0",
    icontrait1 = "524292",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ferenc",
    lastname = "Puskás",
    surname = "Puskás",
    commonname = "Ferenc Puskás",
    playerjerseyname = "Puskás"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ferenc Puskás (ID: %s).", entry.playerid))
