-- ICON Player Script - PlayerExists Check Only
local playerid = 167680

if PlayerExists(playerid) then
    Log("Player with ID: 167680 exists")
else
    Log("Player with ID: 167680 doesn't exists")
end

local player_data = {
    playerid = "167680",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Koeman",
    overallrating = "91",
    preferredposition1 = "5",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "83",
    sprintspeed = "82",
    agility = "80",
    balance = "80",
    jumping = "90",
    stamina = "91",
    strength = "92",
    reactions = "92",
    aggression = "91",
    composure = "90",
    interceptions = "93",
    positioning = "80",
    vision = "83",
    ballcontrol = "88",
    crossing = "82",
    dribbling = "80",
    finishing = "82",
    freekickaccuracy = "97",
    headingaccuracy = "85",
    longpassing = "97",
    shortpassing = "88",
    defensiveawareness = "88",
    shotpower = "97",
    longshots = "97",
    standingtackle = "91",
    slidingtackle = "90",
    volleys = "83",
    curve = "95",
    penalties = "96",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "29828",
    trait2 = "0",
    icontrait1 = "32776",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ronald",
    lastname = "Koeman",
    surname = "Koeman",
    commonname = "Ronald Koeman",
    playerjerseyname = "Koeman"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ronald Koeman (ID: %s).", entry.playerid))
