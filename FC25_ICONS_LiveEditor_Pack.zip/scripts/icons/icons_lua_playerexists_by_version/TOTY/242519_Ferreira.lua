-- ICON Player Script - PlayerExists Check Only
local playerid = 242519

if PlayerExists(playerid) then
    Log("Player with ID: 242519 exists")
else
    Log("Player with ID: 242519 doesn't exists")
end

local player_data = {
    playerid = "242519",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ferreira",
    overallrating = "95",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "93",
    sprintspeed = "94",
    agility = "96",
    balance = "94",
    jumping = "87",
    stamina = "92",
    strength = "78",
    reactions = "96",
    aggression = "78",
    composure = "96",
    interceptions = "43",
    positioning = "96",
    vision = "90",
    ballcontrol = "91",
    crossing = "88",
    dribbling = "98",
    finishing = "95",
    freekickaccuracy = "90",
    headingaccuracy = "94",
    longpassing = "86",
    shortpassing = "88",
    defensiveawareness = "45",
    shotpower = "95",
    longshots = "86",
    standingtackle = "43",
    slidingtackle = "37",
    volleys = "95",
    curve = "85",
    penalties = "95",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "12583171",
    trait2 = "0",
    icontrait1 = "131076",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Eusébio da Silva",
    lastname = "Ferreira",
    surname = "Ferreira",
    commonname = "Eusébio da Silva Ferreira",
    playerjerseyname = "Ferreira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Eusébio da Silva Ferreira (ID: %s).", entry.playerid))
