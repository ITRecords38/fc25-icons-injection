-- ICON Player Script - PlayerExists Check Only
local playerid = 237067

if PlayerExists(playerid) then
    Log("Player with ID: 237067 exists")
else
    Log("Player with ID: 237067 doesn't exists")
end

local player_data = {
    playerid = "237067",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Nascimento",
    overallrating = "96",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "94",
    sprintspeed = "94",
    agility = "93",
    balance = "92",
    jumping = "88",
    stamina = "87",
    strength = "80",
    reactions = "97",
    aggression = "70",
    composure = "97",
    interceptions = "67",
    positioning = "96",
    vision = "96",
    ballcontrol = "96",
    crossing = "90",
    dribbling = "95",
    finishing = "97",
    freekickaccuracy = "88",
    headingaccuracy = "95",
    longpassing = "87",
    shortpassing = "95",
    defensiveawareness = "56",
    shotpower = "94",
    longshots = "87",
    standingtackle = "52",
    slidingtackle = "50",
    volleys = "95",
    curve = "88",
    penalties = "92",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "9961637",
    trait2 = "0",
    icontrait1 = "4259840",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Edson Arantes",
    lastname = "Nascimento",
    surname = "Nascimento",
    commonname = "Edson Arantes Nascimento",
    playerjerseyname = "Nascimento"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Edson Arantes Nascimento (ID: %s).", entry.playerid))
