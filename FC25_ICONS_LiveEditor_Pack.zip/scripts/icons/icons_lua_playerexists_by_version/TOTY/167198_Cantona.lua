-- ICON Player Script - PlayerExists Check Only
local playerid = 167198

if PlayerExists(playerid) then
    Log("Player with ID: 167198 exists")
else
    Log("Player with ID: 167198 doesn't exists")
end

local player_data = {
    playerid = "167198",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Cantona",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "90",
    agility = "85",
    balance = "85",
    jumping = "91",
    stamina = "90",
    strength = "91",
    reactions = "90",
    aggression = "93",
    composure = "96",
    interceptions = "51",
    positioning = "92",
    vision = "94",
    ballcontrol = "94",
    crossing = "90",
    dribbling = "92",
    finishing = "91",
    freekickaccuracy = "88",
    headingaccuracy = "96",
    longpassing = "86",
    shortpassing = "90",
    defensiveawareness = "43",
    shotpower = "94",
    longshots = "86",
    standingtackle = "56",
    slidingtackle = "53",
    volleys = "97",
    curve = "92",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "26018080",
    trait2 = "0",
    icontrait1 = "6",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Eric",
    lastname = "Cantona",
    surname = "Cantona",
    commonname = "Eric Cantona",
    playerjerseyname = "Cantona"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Eric Cantona (ID: %s).", entry.playerid))
