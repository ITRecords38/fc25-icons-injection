-- ICON Player Script - PlayerExists Check Only
local playerid = 238430

if PlayerExists(playerid) then
    Log("Player with ID: 238430 exists")
else
    Log("Player with ID: 238430 doesn't exists")
end

local player_data = {
    playerid = "238430",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Rocha",
    overallrating = "92",
    preferredposition1 = "7",
    preferredposition2 = "16",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "3",
    acceleration = "93",
    sprintspeed = "91",
    agility = "82",
    balance = "91",
    jumping = "90",
    stamina = "95",
    strength = "90",
    reactions = "97",
    aggression = "88",
    composure = "88",
    interceptions = "95",
    positioning = "80",
    vision = "78",
    ballcontrol = "90",
    crossing = "93",
    dribbling = "81",
    finishing = "81",
    freekickaccuracy = "97",
    headingaccuracy = "80",
    longpassing = "87",
    shortpassing = "88",
    defensiveawareness = "90",
    shotpower = "97",
    longshots = "87",
    standingtackle = "90",
    slidingtackle = "92",
    volleys = "81",
    curve = "97",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "88224900",
    trait2 = "0",
    icontrait1 = "520",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Roberto Carlos da Silva",
    lastname = "Rocha",
    surname = "Rocha",
    commonname = "Roberto Carlos da Silva Rocha",
    playerjerseyname = "Rocha"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Roberto Carlos da Silva Rocha (ID: %s).", entry.playerid))
