-- ICON Player Script - PlayerExists Check Only
local playerid = 45197

if PlayerExists(playerid) then
    Log("Player with ID: 45197 exists")
else
    Log("Player with ID: 45197 doesn't exists")
end

local player_data = {
    playerid = "45197",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Olano",
    overallrating = "90",
    preferredposition1 = "10",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "83",
    sprintspeed = "87",
    agility = "83",
    balance = "84",
    jumping = "71",
    stamina = "90",
    strength = "81",
    reactions = "88",
    aggression = "84",
    composure = "91",
    interceptions = "90",
    positioning = "75",
    vision = "93",
    ballcontrol = "90",
    crossing = "87",
    dribbling = "80",
    finishing = "72",
    freekickaccuracy = "90",
    headingaccuracy = "77",
    longpassing = "95",
    shortpassing = "95",
    defensiveawareness = "88",
    shotpower = "93",
    longshots = "95",
    standingtackle = "90",
    slidingtackle = "83",
    volleys = "80",
    curve = "85",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "643076",
    trait2 = "0",
    icontrait1 = "160",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Xabier Alonso",
    lastname = "Olano",
    surname = "Olano",
    commonname = "Xabier Alonso Olano",
    playerjerseyname = "Olano"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Xabier Alonso Olano (ID: %s).", entry.playerid))
