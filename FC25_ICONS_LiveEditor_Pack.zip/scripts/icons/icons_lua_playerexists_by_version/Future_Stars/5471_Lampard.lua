-- ICON Player Script - PlayerExists Check Only
local playerid = 5471

if PlayerExists(playerid) then
    Log("Player with ID: 5471 exists")
else
    Log("Player with ID: 5471 doesn't exists")
end

local player_data = {
    playerid = "5471",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lampard",
    overallrating = "90",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "86",
    sprintspeed = "89",
    agility = "87",
    balance = "88",
    jumping = "86",
    stamina = "96",
    strength = "87",
    reactions = "90",
    aggression = "81",
    composure = "90",
    interceptions = "92",
    positioning = "86",
    vision = "86",
    ballcontrol = "93",
    crossing = "84",
    dribbling = "90",
    finishing = "90",
    freekickaccuracy = "89",
    headingaccuracy = "82",
    longpassing = "94",
    shortpassing = "95",
    defensiveawareness = "85",
    shotpower = "93",
    longshots = "94",
    standingtackle = "88",
    slidingtackle = "73",
    volleys = "87",
    curve = "86",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18874696",
    trait2 = "0",
    icontrait1 = "36",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Frank",
    lastname = "Lampard",
    surname = "Lampard",
    commonname = "Frank Lampard",
    playerjerseyname = "Lampard"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Frank Lampard (ID: %s).", entry.playerid))
