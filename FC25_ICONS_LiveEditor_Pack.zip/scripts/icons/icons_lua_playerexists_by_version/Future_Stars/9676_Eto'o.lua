-- ICON Player Script - PlayerExists Check Only
local playerid = 9676

if PlayerExists(playerid) then
    Log("Player with ID: 9676 exists")
else
    Log("Player with ID: 9676 doesn't exists")
end

local player_data = {
    playerid = "9676",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Eto'o",
    overallrating = "94",
    preferredposition1 = "25",
    preferredposition2 = "27",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "94",
    sprintspeed = "95",
    agility = "90",
    balance = "83",
    jumping = "95",
    stamina = "93",
    strength = "84",
    reactions = "95",
    aggression = "81",
    composure = "93",
    interceptions = "47",
    positioning = "95",
    vision = "88",
    ballcontrol = "91",
    crossing = "82",
    dribbling = "90",
    finishing = "96",
    freekickaccuracy = "90",
    headingaccuracy = "94",
    longpassing = "74",
    shortpassing = "88",
    defensiveawareness = "52",
    shotpower = "92",
    longshots = "74",
    standingtackle = "45",
    slidingtackle = "39",
    volleys = "91",
    curve = "85",
    penalties = "92",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17367297",
    trait2 = "0",
    icontrait1 = "4194308",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Samuel",
    lastname = "Eto'o",
    surname = "Eto'o",
    commonname = "Samuel Eto'o",
    playerjerseyname = "Eto'o"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Samuel Eto'o (ID: %s).", entry.playerid))
