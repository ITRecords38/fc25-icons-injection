-- ICON Player Script - PlayerExists Check Only
local playerid = 48940

if PlayerExists(playerid) then
    Log("Player with ID: 48940 exists")
else
    Log("Player with ID: 48940 doesn't exists")
end

local player_data = {
    playerid = "48940",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Cech",
    overallrating = "89",
    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "0",
    weakfootabilitytypecode = "4",
    acceleration = "57",
    sprintspeed = "53",
    agility = "67",
    balance = "64",
    jumping = "72",
    stamina = "44",
    strength = "76",
    reactions = "89",
    aggression = "26",
    composure = "69",
    interceptions = "23",
    positioning = "12",
    vision = "60",
    ballcontrol = "23",
    crossing = "21",
    dribbling = "18",
    finishing = "13",
    freekickaccuracy = "22",
    headingaccuracy = "27",
    longpassing = "40",
    shortpassing = "37",
    defensiveawareness = "26",
    shotpower = "57",
    longshots = "40",
    standingtackle = "14",
    slidingtackle = "23",
    volleys = "12",
    curve = "22",
    penalties = "27",
    gkdiving = "88",
    gkhandling = "86",
    gkkicking = "80",
    gkreflexes = "90",
    gkpositioning = "91",
    trait1 = "0",
    trait2 = "5",
    icontrait1 = "268435456",
    icontrait2 = "8",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Petr",
    lastname = "Cech",
    surname = "Cech",
    commonname = "Petr Cech",
    playerjerseyname = "Cech"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Petr Cech (ID: %s).", entry.playerid))
