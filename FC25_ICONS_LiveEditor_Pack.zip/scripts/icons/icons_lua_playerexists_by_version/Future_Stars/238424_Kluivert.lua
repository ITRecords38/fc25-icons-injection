-- ICON Player Script - PlayerExists Check Only
local playerid = 238424

if PlayerExists(playerid) then
    Log("Player with ID: 238424 exists")
else
    Log("Player with ID: 238424 doesn't exists")
end

local player_data = {
    playerid = "238424",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Kluivert",
    overallrating = "90",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "90",
    sprintspeed = "90",
    agility = "85",
    balance = "84",
    jumping = "90",
    stamina = "90",
    strength = "88",
    reactions = "90",
    aggression = "83",
    composure = "82",
    interceptions = "37",
    positioning = "90",
    vision = "84",
    ballcontrol = "88",
    crossing = "70",
    dribbling = "84",
    finishing = "93",
    freekickaccuracy = "80",
    headingaccuracy = "90",
    longpassing = "80",
    shortpassing = "85",
    defensiveawareness = "36",
    shotpower = "92",
    longshots = "80",
    standingtackle = "34",
    slidingtackle = "40",
    volleys = "86",
    curve = "80",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "44695569",
    trait2 = "0",
    icontrait1 = "16777220",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Patrick",
    lastname = "Kluivert",
    surname = "Kluivert",
    commonname = "Patrick Kluivert",
    playerjerseyname = "Kluivert"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Patrick Kluivert (ID: %s).", entry.playerid))
