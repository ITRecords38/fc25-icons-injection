-- ICON Player Script - PlayerExists Check Only
local playerid = 190045

if PlayerExists(playerid) then
    Log("Player with ID: 190045 exists")
else
    Log("Player with ID: 190045 doesn't exists")
end

local player_data = {
    playerid = "190045",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Cruyff",
    overallrating = "96",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "94",
    sprintspeed = "92",
    agility = "94",
    balance = "86",
    jumping = "70",
    stamina = "85",
    strength = "76",
    reactions = "96",
    aggression = "74",
    composure = "95",
    interceptions = "46",
    positioning = "96",
    vision = "96",
    ballcontrol = "97",
    crossing = "88",
    dribbling = "96",
    finishing = "96",
    freekickaccuracy = "86",
    headingaccuracy = "67",
    longpassing = "90",
    shortpassing = "95",
    defensiveawareness = "45",
    shotpower = "88",
    longshots = "90",
    standingtackle = "37",
    slidingtackle = "41",
    volleys = "96",
    curve = "95",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18088226",
    trait2 = "0",
    icontrait1 = "524289",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Johan",
    lastname = "Cruyff",
    surname = "Cruyff",
    commonname = "Johan Cruyff",
    playerjerseyname = "Cruyff"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Johan Cruyff (ID: %s).", entry.playerid))
