-- ICON Player Script - PlayerExists Check Only
local playerid = 226369

if PlayerExists(playerid) then
    Log("Player with ID: 226369 exists")
else
    Log("Player with ID: 226369 doesn't exists")
end

local player_data = {
    playerid = "226369",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Schelin",
    overallrating = "91",
    preferredposition1 = "25",
    preferredposition2 = "16",
    preferredposition3 = "27",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "92",
    agility = "85",
    balance = "85",
    jumping = "82",
    stamina = "87",
    strength = "91",
    reactions = "87",
    aggression = "62",
    composure = "90",
    interceptions = "40",
    positioning = "96",
    vision = "86",
    ballcontrol = "91",
    crossing = "80",
    dribbling = "92",
    finishing = "95",
    freekickaccuracy = "77",
    headingaccuracy = "88",
    longpassing = "78",
    shortpassing = "87",
    defensiveawareness = "44",
    shotpower = "87",
    longshots = "78",
    standingtackle = "45",
    slidingtackle = "39",
    volleys = "91",
    curve = "83",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "6881286",
    trait2 = "0",
    icontrait1 = "131073",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lotta",
    lastname = "Schelin",
    surname = "Schelin",
    commonname = "Lotta Schelin",
    playerjerseyname = "Schelin"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lotta Schelin (ID: %s).", entry.playerid))
