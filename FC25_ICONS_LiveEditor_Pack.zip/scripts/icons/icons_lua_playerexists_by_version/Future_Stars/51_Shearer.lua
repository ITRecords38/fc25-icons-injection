-- ICON Player Script - PlayerExists Check Only
local playerid = 51

if PlayerExists(playerid) then
    Log("Player with ID: 51 exists")
else
    Log("Player with ID: 51 doesn't exists")
end

local player_data = {
    playerid = "51",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Shearer",
    overallrating = "91",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "91",
    sprintspeed = "89",
    agility = "82",
    balance = "82",
    jumping = "89",
    stamina = "85",
    strength = "89",
    reactions = "90",
    aggression = "81",
    composure = "90",
    interceptions = "46",
    positioning = "93",
    vision = "81",
    ballcontrol = "87",
    crossing = "83",
    dribbling = "83",
    finishing = "95",
    freekickaccuracy = "92",
    headingaccuracy = "95",
    longpassing = "68",
    shortpassing = "90",
    defensiveawareness = "29",
    shotpower = "95",
    longshots = "68",
    standingtackle = "60",
    slidingtackle = "56",
    volleys = "94",
    curve = "87",
    penalties = "94",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "19398678",
    trait2 = "0",
    icontrait1 = "134217729",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Alan",
    lastname = "Shearer",
    surname = "Shearer",
    commonname = "Alan Shearer",
    playerjerseyname = "Shearer"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Alan Shearer (ID: %s).", entry.playerid))
