-- ICON Player Script - PlayerExists Check Only
local playerid = 247553

if PlayerExists(playerid) then
    Log("Player with ID: 247553 exists")
else
    Log("Player with ID: 247553 doesn't exists")
end

local player_data = {
    playerid = "247553",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Santos",
    overallrating = "94",
    preferredposition1 = "23",
    preferredposition2 = "12",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "92",
    agility = "95",
    balance = "92",
    jumping = "67",
    stamina = "85",
    strength = "68",
    reactions = "96",
    aggression = "55",
    composure = "93",
    interceptions = "46",
    positioning = "92",
    vision = "94",
    ballcontrol = "96",
    crossing = "95",
    dribbling = "98",
    finishing = "90",
    freekickaccuracy = "90",
    headingaccuracy = "68",
    longpassing = "92",
    shortpassing = "94",
    defensiveawareness = "36",
    shotpower = "87",
    longshots = "92",
    standingtackle = "39",
    slidingtackle = "36",
    volleys = "86",
    curve = "92",
    penalties = "83",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "22282752",
    trait2 = "0",
    icontrait1 = "196608",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Manuel Franc. dos",
    lastname = "Santos",
    surname = "Santos",
    commonname = "Manuel Franc. dos Santos",
    playerjerseyname = "Santos"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Manuel Franc. dos Santos (ID: %s).", entry.playerid))
