-- ICON Player Script - PlayerExists Check Only
local playerid = 191695

if PlayerExists(playerid) then
    Log("Player with ID: 191695 exists")
else
    Log("Player with ID: 191695 doesn't exists")
end

local player_data = {
    playerid = "191695",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Santos",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "95",
    sprintspeed = "95",
    agility = "93",
    balance = "91",
    jumping = "87",
    stamina = "88",
    strength = "67",
    reactions = "92",
    aggression = "53",
    composure = "90",
    interceptions = "47",
    positioning = "93",
    vision = "90",
    ballcontrol = "93",
    crossing = "77",
    dribbling = "93",
    finishing = "96",
    freekickaccuracy = "80",
    headingaccuracy = "91",
    longpassing = "64",
    shortpassing = "88",
    defensiveawareness = "35",
    shotpower = "90",
    longshots = "64",
    standingtackle = "34",
    slidingtackle = "33",
    volleys = "88",
    curve = "83",
    penalties = "82",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21757955",
    trait2 = "0",
    icontrait1 = "65540",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Emilio Butragueño",
    lastname = "Santos",
    surname = "Santos",
    commonname = "Emilio Butragueño Santos",
    playerjerseyname = "Santos"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Emilio Butragueño Santos (ID: %s).", entry.playerid))
