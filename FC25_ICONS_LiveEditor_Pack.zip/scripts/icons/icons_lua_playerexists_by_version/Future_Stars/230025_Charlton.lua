-- ICON Player Script - PlayerExists Check Only
local playerid = 230025

if PlayerExists(playerid) then
    Log("Player with ID: 230025 exists")
else
    Log("Player with ID: 230025 doesn't exists")
end

local player_data = {
    playerid = "230025",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Charlton",
    overallrating = "94",
    preferredposition1 = "25",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "92",
    sprintspeed = "92",
    agility = "93",
    balance = "94",
    jumping = "87",
    stamina = "88",
    strength = "70",
    reactions = "95",
    aggression = "74",
    composure = "94",
    interceptions = "50",
    positioning = "94",
    vision = "94",
    ballcontrol = "90",
    crossing = "85",
    dribbling = "94",
    finishing = "93",
    freekickaccuracy = "91",
    headingaccuracy = "81",
    longpassing = "92",
    shortpassing = "91",
    defensiveawareness = "52",
    shotpower = "95",
    longshots = "92",
    standingtackle = "49",
    slidingtackle = "32",
    volleys = "91",
    curve = "87",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4784288",
    trait2 = "0",
    icontrait1 = "16777220",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Bobby",
    lastname = "Charlton",
    surname = "Charlton",
    commonname = "Bobby Charlton",
    playerjerseyname = "Charlton"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Bobby Charlton (ID: %s).", entry.playerid))
