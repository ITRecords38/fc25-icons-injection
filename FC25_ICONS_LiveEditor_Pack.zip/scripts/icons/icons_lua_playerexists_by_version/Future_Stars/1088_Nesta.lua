-- ICON Player Script - PlayerExists Check Only
local playerid = 1088

if PlayerExists(playerid) then
    Log("Player with ID: 1088 exists")
else
    Log("Player with ID: 1088 doesn't exists")
end

local player_data = {
    playerid = "1088",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Nesta",
    overallrating = "90",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "80",
    sprintspeed = "87",
    agility = "70",
    balance = "70",
    jumping = "84",
    stamina = "80",
    strength = "90",
    reactions = "87",
    aggression = "86",
    composure = "84",
    interceptions = "92",
    positioning = "37",
    vision = "58",
    ballcontrol = "77",
    crossing = "55",
    dribbling = "75",
    finishing = "42",
    freekickaccuracy = "33",
    headingaccuracy = "85",
    longpassing = "70",
    shortpassing = "79",
    defensiveawareness = "94",
    shotpower = "53",
    longshots = "70",
    standingtackle = "94",
    slidingtackle = "93",
    volleys = "43",
    curve = "46",
    penalties = "52",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "167816192",
    trait2 = "0",
    icontrait1 = "20480",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Alessandro",
    lastname = "Nesta",
    surname = "Nesta",
    commonname = "Alessandro Nesta",
    playerjerseyname = "Nesta"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Alessandro Nesta (ID: %s).", entry.playerid))
