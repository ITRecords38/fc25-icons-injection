-- ICON Player Script - PlayerExists Check Only
local playerid = 5589

if PlayerExists(playerid) then
    Log("Player with ID: 5589 exists")
else
    Log("Player with ID: 5589 doesn't exists")
end

local player_data = {
    playerid = "5589",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Figo",
    overallrating = "91",
    preferredposition1 = "23",
    preferredposition2 = "12",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "93",
    sprintspeed = "90",
    agility = "91",
    balance = "85",
    jumping = "70",
    stamina = "88",
    strength = "78",
    reactions = "89",
    aggression = "78",
    composure = "89",
    interceptions = "40",
    positioning = "91",
    vision = "87",
    ballcontrol = "93",
    crossing = "92",
    dribbling = "94",
    finishing = "88",
    freekickaccuracy = "83",
    headingaccuracy = "61",
    longpassing = "83",
    shortpassing = "90",
    defensiveawareness = "35",
    shotpower = "84",
    longshots = "83",
    standingtackle = "40",
    slidingtackle = "38",
    volleys = "80",
    curve = "77",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17170957",
    trait2 = "0",
    icontrait1 = "1114112",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Luís Filipe Madeira Caeiro",
    lastname = "Figo",
    surname = "Figo",
    commonname = "Luís Filipe Madeira Caeiro Figo",
    playerjerseyname = "Figo"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Luís Filipe Madeira Caeiro Figo (ID: %s).", entry.playerid))
