-- ICON Player Script - PlayerExists Check Only
local playerid = 190044

if PlayerExists(playerid) then
    Log("Player with ID: 190044 exists")
else
    Log("Player with ID: 190044 doesn't exists")
end

local player_data = {
    playerid = "190044",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Moore",
    overallrating = "91",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "4",
    acceleration = "81",
    sprintspeed = "80",
    agility = "82",
    balance = "83",
    jumping = "87",
    stamina = "92",
    strength = "87",
    reactions = "93",
    aggression = "83",
    composure = "94",
    interceptions = "93",
    positioning = "61",
    vision = "80",
    ballcontrol = "86",
    crossing = "72",
    dribbling = "66",
    finishing = "55",
    freekickaccuracy = "65",
    headingaccuracy = "88",
    longpassing = "89",
    shortpassing = "91",
    defensiveawareness = "95",
    shotpower = "76",
    longshots = "89",
    standingtackle = "94",
    slidingtackle = "92",
    volleys = "63",
    curve = "72",
    penalties = "75",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2152576",
    trait2 = "0",
    icontrait1 = "9216",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Bobby",
    lastname = "Moore",
    surname = "Moore",
    commonname = "Bobby Moore",
    playerjerseyname = "Moore"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Bobby Moore (ID: %s).", entry.playerid))
