-- ICON Player Script - PlayerExists Check Only
local playerid = 239261

if PlayerExists(playerid) then
    Log("Player with ID: 239261 exists")
else
    Log("Player with ID: 239261 doesn't exists")
end

local player_data = {
    playerid = "239261",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Larsson",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "90",
    agility = "90",
    balance = "88",
    jumping = "94",
    stamina = "88",
    strength = "67",
    reactions = "92",
    aggression = "75",
    composure = "87",
    interceptions = "44",
    positioning = "91",
    vision = "75",
    ballcontrol = "86",
    crossing = "71",
    dribbling = "85",
    finishing = "94",
    freekickaccuracy = "82",
    headingaccuracy = "96",
    longpassing = "74",
    shortpassing = "78",
    defensiveawareness = "35",
    shotpower = "86",
    longshots = "74",
    standingtackle = "48",
    slidingtackle = "47",
    volleys = "91",
    curve = "88",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "8978469",
    trait2 = "0",
    icontrait1 = "4194306",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Henrik",
    lastname = "Larsson",
    surname = "Larsson",
    commonname = "Henrik Larsson",
    playerjerseyname = "Larsson"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Henrik Larsson (ID: %s).", entry.playerid))
