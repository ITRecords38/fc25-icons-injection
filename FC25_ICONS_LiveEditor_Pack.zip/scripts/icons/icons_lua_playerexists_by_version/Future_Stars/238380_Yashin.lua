-- ICON Player Script - PlayerExists Check Only
local playerid = 238380

if PlayerExists(playerid) then
    Log("Player with ID: 238380 exists")
else
    Log("Player with ID: 238380 doesn't exists")
end

local player_data = {
    playerid = "238380",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Yashin",
    overallrating = "93",
    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "65",
    sprintspeed = "54",
    agility = "68",
    balance = "63",
    jumping = "85",
    stamina = "44",
    strength = "76",
    reactions = "91",
    aggression = "59",
    composure = "68",
    interceptions = "29",
    positioning = "19",
    vision = "70",
    ballcontrol = "42",
    crossing = "32",
    dribbling = "24",
    finishing = "14",
    freekickaccuracy = "29",
    headingaccuracy = "19",
    longpassing = "32",
    shortpassing = "33",
    defensiveawareness = "20",
    shotpower = "56",
    longshots = "32",
    standingtackle = "20",
    slidingtackle = "19",
    volleys = "22",
    curve = "24",
    penalties = "45",
    gkdiving = "94",
    gkhandling = "91",
    gkkicking = "77",
    gkreflexes = "95",
    gkpositioning = "94",
    trait1 = "536871040",
    trait2 = "2",
    icontrait1 = "0",
    icontrait2 = "5",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lev",
    lastname = "Yashin",
    surname = "Yashin",
    commonname = "Lev Yashin",
    playerjerseyname = "Yashin"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lev Yashin (ID: %s).", entry.playerid))
