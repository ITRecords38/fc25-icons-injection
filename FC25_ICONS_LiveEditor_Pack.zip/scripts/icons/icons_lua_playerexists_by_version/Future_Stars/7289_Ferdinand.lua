-- ICON Player Script - PlayerExists Check Only
local playerid = 7289

if PlayerExists(playerid) then
    Log("Player with ID: 7289 exists")
else
    Log("Player with ID: 7289 doesn't exists")
end

local player_data = {
    playerid = "7289",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ferdinand",
    overallrating = "92",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "87",
    sprintspeed = "85",
    agility = "70",
    balance = "70",
    jumping = "84",
    stamina = "85",
    strength = "89",
    reactions = "86",
    aggression = "88",
    composure = "90",
    interceptions = "92",
    positioning = "50",
    vision = "58",
    ballcontrol = "75",
    crossing = "56",
    dribbling = "70",
    finishing = "47",
    freekickaccuracy = "33",
    headingaccuracy = "88",
    longpassing = "81",
    shortpassing = "87",
    defensiveawareness = "94",
    shotpower = "68",
    longshots = "81",
    standingtackle = "94",
    slidingtackle = "91",
    volleys = "60",
    curve = "56",
    penalties = "64",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "33604624",
    trait2 = "0",
    icontrait1 = "134225920",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Rio",
    lastname = "Ferdinand",
    surname = "Ferdinand",
    commonname = "Rio Ferdinand",
    playerjerseyname = "Ferdinand"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Rio Ferdinand (ID: %s).", entry.playerid))
