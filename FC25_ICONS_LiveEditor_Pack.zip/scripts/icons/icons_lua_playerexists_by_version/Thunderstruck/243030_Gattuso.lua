-- ICON Player Script - PlayerExists Check Only
local playerid = 243030

if PlayerExists(playerid) then
    Log("Player with ID: 243030 exists")
else
    Log("Player with ID: 243030 doesn't exists")
end

local player_data = {
    playerid = "243030",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Gattuso",
    overallrating = "88",
    preferredposition1 = "10",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "82",
    sprintspeed = "81",
    agility = "77",
    balance = "81",
    jumping = "65",
    stamina = "93",
    strength = "86",
    reactions = "94",
    aggression = "95",
    composure = "82",
    interceptions = "94",
    positioning = "71",
    vision = "81",
    ballcontrol = "74",
    crossing = "61",
    dribbling = "66",
    finishing = "60",
    freekickaccuracy = "39",
    headingaccuracy = "63",
    longpassing = "84",
    shortpassing = "88",
    defensiveawareness = "92",
    shotpower = "75",
    longshots = "84",
    standingtackle = "93",
    slidingtackle = "91",
    volleys = "57",
    curve = "53",
    penalties = "61",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "56384",
    trait2 = "0",
    icontrait1 = "8388608",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gennaro",
    lastname = "Gattuso",
    surname = "Gattuso",
    commonname = "Gennaro Gattuso",
    playerjerseyname = "Gattuso"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gennaro Gattuso (ID: %s).", entry.playerid))
