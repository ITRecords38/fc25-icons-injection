-- ICON Player Script - PlayerExists Check Only
local playerid = 1615

if PlayerExists(playerid) then
    Log("Player with ID: 1615 exists")
else
    Log("Player with ID: 1615 doesn't exists")
end

local player_data = {
    playerid = "1615",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Thuram",
    overallrating = "90",
    preferredposition1 = "3",
    preferredposition2 = "5",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "3",
    acceleration = "91",
    sprintspeed = "90",
    agility = "79",
    balance = "85",
    jumping = "88",
    stamina = "91",
    strength = "92",
    reactions = "85",
    aggression = "92",
    composure = "86",
    interceptions = "90",
    positioning = "71",
    vision = "77",
    ballcontrol = "79",
    crossing = "77",
    dribbling = "73",
    finishing = "60",
    freekickaccuracy = "44",
    headingaccuracy = "89",
    longpassing = "81",
    shortpassing = "86",
    defensiveawareness = "94",
    shotpower = "66",
    longshots = "81",
    standingtackle = "90",
    slidingtackle = "96",
    volleys = "58",
    curve = "66",
    penalties = "44",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134261760",
    trait2 = "0",
    icontrait1 = "16384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lilian",
    lastname = "Thuram",
    surname = "Thuram",
    commonname = "Lilian Thuram",
    playerjerseyname = "Thuram"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lilian Thuram (ID: %s).", entry.playerid))
