-- ICON Player Script - PlayerExists Check Only
local playerid = 240

if PlayerExists(playerid) then
    Log("Player with ID: 240 exists")
else
    Log("Player with ID: 240 doesn't exists")
end

local player_data = {
    playerid = "240",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Keane",
    overallrating = "88",
    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "81",
    sprintspeed = "81",
    agility = "75",
    balance = "78",
    jumping = "79",
    stamina = "93",
    strength = "86",
    reactions = "92",
    aggression = "95",
    composure = "91",
    interceptions = "95",
    positioning = "70",
    vision = "86",
    ballcontrol = "86",
    crossing = "73",
    dribbling = "78",
    finishing = "71",
    freekickaccuracy = "72",
    headingaccuracy = "78",
    longpassing = "88",
    shortpassing = "91",
    defensiveawareness = "81",
    shotpower = "65",
    longshots = "88",
    standingtackle = "92",
    slidingtackle = "87",
    volleys = "58",
    curve = "70",
    penalties = "70",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "11030816",
    trait2 = "0",
    icontrait1 = "64",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Roy",
    lastname = "Keane",
    surname = "Keane",
    commonname = "Roy Keane",
    playerjerseyname = "Keane"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Roy Keane (ID: %s).", entry.playerid))
