-- ICON Player Script - PlayerExists Check Only
local playerid = 227263

if PlayerExists(playerid) then
    Log("Player with ID: 227263 exists")
else
    Log("Player with ID: 227263 doesn't exists")
end

local player_data = {
    playerid = "227263",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Smith",
    overallrating = "91",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "90",
    agility = "84",
    balance = "85",
    jumping = "83",
    stamina = "88",
    strength = "86",
    reactions = "92",
    aggression = "61",
    composure = "91",
    interceptions = "38",
    positioning = "93",
    vision = "89",
    ballcontrol = "92",
    crossing = "85",
    dribbling = "92",
    finishing = "94",
    freekickaccuracy = "93",
    headingaccuracy = "89",
    longpassing = "73",
    shortpassing = "89",
    defensiveawareness = "37",
    shotpower = "89",
    longshots = "73",
    standingtackle = "53",
    slidingtackle = "49",
    volleys = "88",
    curve = "92",
    penalties = "83",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "135921688",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Kelly",
    lastname = "Smith",
    surname = "Smith",
    commonname = "Kelly Smith",
    playerjerseyname = "Smith"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Kelly Smith (ID: %s).", entry.playerid))
