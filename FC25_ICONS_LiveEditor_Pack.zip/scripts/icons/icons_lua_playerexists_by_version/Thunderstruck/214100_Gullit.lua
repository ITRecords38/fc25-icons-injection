-- ICON Player Script - PlayerExists Check Only
local playerid = 214100

if PlayerExists(playerid) then
    Log("Player with ID: 214100 exists")
else
    Log("Player with ID: 214100 doesn't exists")
end

local player_data = {
    playerid = "214100",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Gullit",
    overallrating = "93",
    preferredposition1 = "18",
    preferredposition2 = "14",
    preferredposition3 = "25",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "86",
    sprintspeed = "89",
    agility = "81",
    balance = "85",
    jumping = "86",
    stamina = "95",
    strength = "89",
    reactions = "95",
    aggression = "87",
    composure = "91",
    interceptions = "82",
    positioning = "94",
    vision = "94",
    ballcontrol = "92",
    crossing = "90",
    dribbling = "89",
    finishing = "89",
    freekickaccuracy = "94",
    headingaccuracy = "95",
    longpassing = "96",
    shortpassing = "94",
    defensiveawareness = "80",
    shotpower = "96",
    longshots = "96",
    standingtackle = "83",
    slidingtackle = "78",
    volleys = "88",
    curve = "92",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "8519766",
    trait2 = "0",
    icontrait1 = "134217728",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ruud",
    lastname = "Gullit",
    surname = "Gullit",
    commonname = "Ruud Gullit",
    playerjerseyname = "Gullit"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ruud Gullit (ID: %s).", entry.playerid))
