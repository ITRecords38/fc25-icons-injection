-- ICON Player Script - PlayerExists Check Only
local playerid = 268513

if PlayerExists(playerid) then
    Log("Player with ID: 268513 exists")
else
    Log("Player with ID: 268513 doesn't exists")
end

local player_data = {
    playerid = "268513",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Filho",
    overallrating = "91",
    preferredposition1 = "23",
    preferredposition2 = "12",
    preferredposition3 = "25",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "95",
    sprintspeed = "92",
    agility = "92",
    balance = "87",
    jumping = "86",
    stamina = "85",
    strength = "83",
    reactions = "90",
    aggression = "46",
    composure = "93",
    interceptions = "49",
    positioning = "91",
    vision = "92",
    ballcontrol = "90",
    crossing = "85",
    dribbling = "95",
    finishing = "94",
    freekickaccuracy = "79",
    headingaccuracy = "89",
    longpassing = "81",
    shortpassing = "88",
    defensiveawareness = "45",
    shotpower = "93",
    longshots = "81",
    standingtackle = "47",
    slidingtackle = "45",
    volleys = "88",
    curve = "84",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "56360964",
    trait2 = "0",
    icontrait1 = "131072",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Jair Ventura",
    lastname = "Filho",
    surname = "Filho",
    commonname = "Jair Ventura Filho",
    playerjerseyname = "Filho"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Jair Ventura Filho (ID: %s).", entry.playerid))
