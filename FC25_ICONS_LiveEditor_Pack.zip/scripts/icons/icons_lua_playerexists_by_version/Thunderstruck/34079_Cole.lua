-- ICON Player Script - PlayerExists Check Only
local playerid = 34079

if PlayerExists(playerid) then
    Log("Player with ID: 34079 exists")
else
    Log("Player with ID: 34079 doesn't exists")
end

local player_data = {
    playerid = "34079",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Cole",
    overallrating = "88",
    preferredposition1 = "7",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "88",
    agility = "85",
    balance = "86",
    jumping = "83",
    stamina = "93",
    strength = "73",
    reactions = "87",
    aggression = "87",
    composure = "84",
    interceptions = "89",
    positioning = "77",
    vision = "81",
    ballcontrol = "82",
    crossing = "85",
    dribbling = "81",
    finishing = "57",
    freekickaccuracy = "64",
    headingaccuracy = "64",
    longpassing = "81",
    shortpassing = "82",
    defensiveawareness = "89",
    shotpower = "75",
    longshots = "81",
    standingtackle = "89",
    slidingtackle = "92",
    volleys = "72",
    curve = "83",
    penalties = "74",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "25385472",
    trait2 = "0",
    icontrait1 = "1024",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ashley",
    lastname = "Cole",
    surname = "Cole",
    commonname = "Ashley Cole",
    playerjerseyname = "Cole"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ashley Cole (ID: %s).", entry.playerid))
