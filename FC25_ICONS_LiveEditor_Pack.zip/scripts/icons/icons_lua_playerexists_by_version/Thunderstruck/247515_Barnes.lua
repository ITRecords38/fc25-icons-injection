-- ICON Player Script - PlayerExists Check Only
local playerid = 247515

if PlayerExists(playerid) then
    Log("Player with ID: 247515 exists")
else
    Log("Player with ID: 247515 doesn't exists")
end

local player_data = {
    playerid = "247515",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Barnes",
    overallrating = "89",
    preferredposition1 = "27",
    preferredposition2 = "16",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "89",
    sprintspeed = "93",
    agility = "86",
    balance = "84",
    jumping = "72",
    stamina = "91",
    strength = "87",
    reactions = "87",
    aggression = "83",
    composure = "91",
    interceptions = "33",
    positioning = "87",
    vision = "87",
    ballcontrol = "92",
    crossing = "88",
    dribbling = "93",
    finishing = "89",
    freekickaccuracy = "88",
    headingaccuracy = "75",
    longpassing = "81",
    shortpassing = "87",
    defensiveawareness = "47",
    shotpower = "86",
    longshots = "81",
    standingtackle = "47",
    slidingtackle = "37",
    volleys = "84",
    curve = "86",
    penalties = "73",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21365281",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "John",
    lastname = "Barnes",
    surname = "Barnes",
    commonname = "John Barnes",
    playerjerseyname = "Barnes"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - John Barnes (ID: %s).", entry.playerid))
