-- ICON Player Script - PlayerExists Check Only
local playerid = 238435

if PlayerExists(playerid) then
    Log("Player with ID: 238435 exists")
else
    Log("Player with ID: 238435 doesn't exists")
end

local player_data = {
    playerid = "238435",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Matthäus",
    overallrating = "92",
    preferredposition1 = "14",
    preferredposition2 = "5",
    preferredposition3 = "10",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "94",
    sprintspeed = "87",
    agility = "79",
    balance = "81",
    jumping = "74",
    stamina = "93",
    strength = "78",
    reactions = "91",
    aggression = "92",
    composure = "91",
    interceptions = "94",
    positioning = "89",
    vision = "92",
    ballcontrol = "89",
    crossing = "85",
    dribbling = "79",
    finishing = "81",
    freekickaccuracy = "93",
    headingaccuracy = "82",
    longpassing = "94",
    shortpassing = "94",
    defensiveawareness = "91",
    shotpower = "97",
    longshots = "94",
    standingtackle = "95",
    slidingtackle = "92",
    volleys = "90",
    curve = "78",
    penalties = "95",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "12726400",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lothar",
    lastname = "Matthäus",
    surname = "Matthäus",
    commonname = "Lothar Matthäus",
    playerjerseyname = "Matthäus"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lothar Matthäus (ID: %s).", entry.playerid))
