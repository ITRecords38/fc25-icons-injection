-- ICON Player Script - PlayerExists Check Only
local playerid = 23174

if PlayerExists(playerid) then
    Log("Player with ID: 23174 exists")
else
    Log("Player with ID: 23174 doesn't exists")
end

local player_data = {
    playerid = "23174",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Riquelme",
    overallrating = "90",
    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "81",
    sprintspeed = "83",
    agility = "81",
    balance = "87",
    jumping = "63",
    stamina = "73",
    strength = "73",
    reactions = "85",
    aggression = "52",
    composure = "94",
    interceptions = "33",
    positioning = "84",
    vision = "94",
    ballcontrol = "95",
    crossing = "90",
    dribbling = "94",
    finishing = "83",
    freekickaccuracy = "92",
    headingaccuracy = "59",
    longpassing = "92",
    shortpassing = "93",
    defensiveawareness = "29",
    shotpower = "89",
    longshots = "92",
    standingtackle = "36",
    slidingtackle = "34",
    volleys = "78",
    curve = "90",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17563692",
    trait2 = "0",
    icontrait1 = "1048576",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Juan Román",
    lastname = "Riquelme",
    surname = "Riquelme",
    commonname = "Juan Román Riquelme",
    playerjerseyname = "Riquelme"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Juan Román Riquelme (ID: %s).", entry.playerid))
