-- ICON Player Script - PlayerExists Check Only
local playerid = 238427

if PlayerExists(playerid) then
    Log("Player with ID: 238427 exists")
else
    Log("Player with ID: 238427 doesn't exists")
end

local player_data = {
    playerid = "238427",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Vieira",
    overallrating = "90",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "85",
    sprintspeed = "84",
    agility = "81",
    balance = "75",
    jumping = "81",
    stamina = "95",
    strength = "91",
    reactions = "91",
    aggression = "93",
    composure = "91",
    interceptions = "94",
    positioning = "81",
    vision = "89",
    ballcontrol = "89",
    crossing = "67",
    dribbling = "84",
    finishing = "78",
    freekickaccuracy = "60",
    headingaccuracy = "84",
    longpassing = "89",
    shortpassing = "89",
    defensiveawareness = "86",
    shotpower = "86",
    longshots = "89",
    standingtackle = "94",
    slidingtackle = "87",
    volleys = "69",
    curve = "66",
    penalties = "76",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10545232",
    trait2 = "0",
    icontrait1 = "4096",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Patrick",
    lastname = "Vieira",
    surname = "Vieira",
    commonname = "Patrick Vieira",
    playerjerseyname = "Vieira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Patrick Vieira (ID: %s).", entry.playerid))
