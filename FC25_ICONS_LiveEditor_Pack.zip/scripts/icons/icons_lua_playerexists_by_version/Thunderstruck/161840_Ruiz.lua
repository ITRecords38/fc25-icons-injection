-- ICON Player Script - PlayerExists Check Only
local playerid = 161840

if PlayerExists(playerid) then
    Log("Player with ID: 161840 exists")
else
    Log("Player with ID: 161840 doesn't exists")
end

local player_data = {
    playerid = "161840",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ruiz",
    overallrating = "90",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "81",
    sprintspeed = "81",
    agility = "71",
    balance = "86",
    jumping = "94",
    stamina = "85",
    strength = "91",
    reactions = "86",
    aggression = "85",
    composure = "89",
    interceptions = "94",
    positioning = "66",
    vision = "72",
    ballcontrol = "74",
    crossing = "64",
    dribbling = "63",
    finishing = "56",
    freekickaccuracy = "75",
    headingaccuracy = "95",
    longpassing = "88",
    shortpassing = "81",
    defensiveawareness = "95",
    shotpower = "84",
    longshots = "88",
    standingtackle = "96",
    slidingtackle = "79",
    volleys = "77",
    curve = "66",
    penalties = "75",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134248600",
    trait2 = "0",
    icontrait1 = "32768",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Fernando Hierro",
    lastname = "Ruiz",
    surname = "Ruiz",
    commonname = "Fernando Hierro Ruiz",
    playerjerseyname = "Ruiz"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Fernando Hierro Ruiz (ID: %s).", entry.playerid))
