-- ICON Player Script - PlayerExists Check Only
local playerid = 247703

if PlayerExists(playerid) then
    Log("Player with ID: 247703 exists")
else
    Log("Player with ID: 247703 doesn't exists")
end

local player_data = {
    playerid = "247703",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Rush",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "86",
    sprintspeed = "88",
    agility = "81",
    balance = "81",
    jumping = "87",
    stamina = "84",
    strength = "82",
    reactions = "91",
    aggression = "75",
    composure = "91",
    interceptions = "34",
    positioning = "92",
    vision = "77",
    ballcontrol = "89",
    crossing = "66",
    dribbling = "85",
    finishing = "93",
    freekickaccuracy = "70",
    headingaccuracy = "92",
    longpassing = "54",
    shortpassing = "76",
    defensiveawareness = "39",
    shotpower = "87",
    longshots = "54",
    standingtackle = "47",
    slidingtackle = "33",
    volleys = "92",
    curve = "77",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "157286423",
    trait2 = "0",
    icontrait1 = "524288",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ian",
    lastname = "Rush",
    surname = "Rush",
    commonname = "Ian Rush",
    playerjerseyname = "Rush"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ian Rush (ID: %s).", entry.playerid))
