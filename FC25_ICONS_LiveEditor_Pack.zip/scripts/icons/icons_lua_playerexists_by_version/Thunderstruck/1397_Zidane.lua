-- ICON Player Script - PlayerExists Check Only
local playerid = 1397

if PlayerExists(playerid) then
    Log("Player with ID: 1397 exists")
else
    Log("Player with ID: 1397 doesn't exists")
end

local player_data = {
    playerid = "1397",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Zidane",
    overallrating = "96",
    preferredposition1 = "18",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "87",
    sprintspeed = "85",
    agility = "83",
    balance = "87",
    jumping = "75",
    stamina = "88",
    strength = "88",
    reactions = "96",
    aggression = "79",
    composure = "98",
    interceptions = "86",
    positioning = "92",
    vision = "98",
    ballcontrol = "98",
    crossing = "94",
    dribbling = "98",
    finishing = "91",
    freekickaccuracy = "92",
    headingaccuracy = "89",
    longpassing = "97",
    shortpassing = "98",
    defensiveawareness = "66",
    shotpower = "91",
    longshots = "97",
    standingtackle = "79",
    slidingtackle = "68",
    volleys = "93",
    curve = "89",
    penalties = "91",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17629313",
    trait2 = "0",
    icontrait1 = "32",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Zinedine",
    lastname = "Zidane",
    surname = "Zidane",
    commonname = "Zinedine Zidane",
    playerjerseyname = "Zidane"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Zinedine Zidane (ID: %s).", entry.playerid))
