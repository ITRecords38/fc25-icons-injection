-- ICON Player Script - PlayerExists Check Only
local playerid = 166691

if PlayerExists(playerid) then
    Log("Player with ID: 166691 exists")
else
    Log("Player with ID: 166691 doesn't exists")
end

local player_data = {
    playerid = "166691",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Coimbra",
    overallrating = "93",
    preferredposition1 = "18",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "89",
    sprintspeed = "92",
    agility = "91",
    balance = "87",
    jumping = "81",
    stamina = "84",
    strength = "78",
    reactions = "91",
    aggression = "48",
    composure = "91",
    interceptions = "64",
    positioning = "91",
    vision = "95",
    ballcontrol = "95",
    crossing = "88",
    dribbling = "94",
    finishing = "94",
    freekickaccuracy = "99",
    headingaccuracy = "76",
    longpassing = "89",
    shortpassing = "95",
    defensiveawareness = "59",
    shotpower = "94",
    longshots = "89",
    standingtackle = "69",
    slidingtackle = "63",
    volleys = "92",
    curve = "96",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18088233",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Arthur Antunes",
    lastname = "Coimbra",
    surname = "Coimbra",
    commonname = "Arthur Antunes Coimbra",
    playerjerseyname = "Coimbra"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Arthur Antunes Coimbra (ID: %s).", entry.playerid))
