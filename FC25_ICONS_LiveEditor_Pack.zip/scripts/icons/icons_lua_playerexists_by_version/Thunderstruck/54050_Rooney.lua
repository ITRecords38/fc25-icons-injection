-- ICON Player Script - PlayerExists Check Only
local playerid = 54050

if PlayerExists(playerid) then
    Log("Player with ID: 54050 exists")
else
    Log("Player with ID: 54050 doesn't exists")
end

local player_data = {
    playerid = "54050",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Rooney",
    overallrating = "91",
    preferredposition1 = "25",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "92",
    sprintspeed = "91",
    agility = "85",
    balance = "85",
    jumping = "88",
    stamina = "92",
    strength = "88",
    reactions = "93",
    aggression = "91",
    composure = "88",
    interceptions = "46",
    positioning = "92",
    vision = "83",
    ballcontrol = "92",
    crossing = "81",
    dribbling = "87",
    finishing = "91",
    freekickaccuracy = "86",
    headingaccuracy = "93",
    longpassing = "87",
    shortpassing = "88",
    defensiveawareness = "55",
    shotpower = "94",
    longshots = "87",
    standingtackle = "59",
    slidingtackle = "46",
    volleys = "92",
    curve = "88",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "59375747",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Wayne",
    lastname = "Rooney",
    surname = "Rooney",
    commonname = "Wayne Rooney",
    playerjerseyname = "Rooney"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Wayne Rooney (ID: %s).", entry.playerid))
