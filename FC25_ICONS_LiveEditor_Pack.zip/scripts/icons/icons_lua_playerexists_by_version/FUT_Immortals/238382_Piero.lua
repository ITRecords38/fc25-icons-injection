-- ICON Player Script - PlayerExists Check Only
local playerid = 238382

if PlayerExists(playerid) then
    Log("Player with ID: 238382 exists")
else
    Log("Player with ID: 238382 doesn't exists")
end

local player_data = {
    playerid = "238382",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Piero",
    overallrating = "92",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "92",
    sprintspeed = "91",
    agility = "87",
    balance = "86",
    jumping = "61",
    stamina = "85",
    strength = "66",
    reactions = "90",
    aggression = "65",
    composure = "93",
    interceptions = "41",
    positioning = "94",
    vision = "97",
    ballcontrol = "95",
    crossing = "92",
    dribbling = "95",
    finishing = "95",
    freekickaccuracy = "94",
    headingaccuracy = "76",
    longpassing = "86",
    shortpassing = "92",
    defensiveawareness = "38",
    shotpower = "86",
    longshots = "86",
    standingtackle = "42",
    slidingtackle = "36",
    volleys = "87",
    curve = "93",
    penalties = "94",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "12910632",
    trait2 = "48",
    icontrait1 = "524353",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Alessandro Del",
    lastname = "Piero",
    surname = "Piero",
    commonname = "Alessandro Del Piero",
    playerjerseyname = "Piero"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Alessandro Del Piero (ID: %s).", entry.playerid))
