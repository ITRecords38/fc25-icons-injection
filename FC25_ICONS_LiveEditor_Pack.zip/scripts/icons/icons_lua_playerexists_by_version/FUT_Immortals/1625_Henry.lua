-- ICON Player Script - PlayerExists Check Only
local playerid = 1625

if PlayerExists(playerid) then
    Log("Player with ID: 1625 exists")
else
    Log("Player with ID: 1625 doesn't exists")
end

local player_data = {
    playerid = "1625",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Henry",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "27",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "94",
    sprintspeed = "94",
    agility = "88",
    balance = "85",
    jumping = "81",
    stamina = "94",
    strength = "92",
    reactions = "93",
    aggression = "74",
    composure = "88",
    interceptions = "60",
    positioning = "94",
    vision = "90",
    ballcontrol = "93",
    crossing = "88",
    dribbling = "92",
    finishing = "95",
    freekickaccuracy = "95",
    headingaccuracy = "88",
    longpassing = "85",
    shortpassing = "96",
    defensiveawareness = "51",
    shotpower = "88",
    longshots = "85",
    standingtackle = "57",
    slidingtackle = "52",
    volleys = "91",
    curve = "96",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "22872071",
    trait2 = "0",
    icontrait1 = "131072",
    icontrait2 = "48",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Thierry",
    lastname = "Henry",
    surname = "Henry",
    commonname = "Thierry Henry",
    playerjerseyname = "Henry"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Thierry Henry (ID: %s).", entry.playerid))
