-- ICON Player Script - PlayerExists Check Only
local playerid = 227006

if PlayerExists(playerid) then
    Log("Player with ID: 227006 exists")
else
    Log("Player with ID: 227006 doesn't exists")
end

local player_data = {
    playerid = "227006",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Sawa",
    overallrating = "94",
    preferredposition1 = "14",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "91",
    sprintspeed = "86",
    agility = "91",
    balance = "85",
    jumping = "82",
    stamina = "97",
    strength = "73",
    reactions = "94",
    aggression = "75",
    composure = "96",
    interceptions = "87",
    positioning = "94",
    vision = "95",
    ballcontrol = "95",
    crossing = "90",
    dribbling = "94",
    finishing = "95",
    freekickaccuracy = "83",
    headingaccuracy = "92",
    longpassing = "97",
    shortpassing = "98",
    defensiveawareness = "86",
    shotpower = "82",
    longshots = "97",
    standingtackle = "90",
    slidingtackle = "71",
    volleys = "77",
    curve = "90",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "13172832",
    trait2 = "48",
    icontrait1 = "2097536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Homare",
    lastname = "Sawa",
    surname = "Sawa",
    commonname = "Homare Sawa",
    playerjerseyname = "Sawa"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Homare Sawa (ID: %s).", entry.playerid))
