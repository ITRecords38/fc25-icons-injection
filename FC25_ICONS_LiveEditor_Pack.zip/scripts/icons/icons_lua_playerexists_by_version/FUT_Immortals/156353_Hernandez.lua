-- ICON Player Script - PlayerExists Check Only
local playerid = 156353

if PlayerExists(playerid) then
    Log("Player with ID: 156353 exists")
else
    Log("Player with ID: 156353 doesn't exists")
end

local player_data = {
    playerid = "156353",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Hernández",
    overallrating = "90",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "95",
    sprintspeed = "92",
    agility = "92",
    balance = "89",
    jumping = "93",
    stamina = "90",
    strength = "78",
    reactions = "89",
    aggression = "70",
    composure = "89",
    interceptions = "36",
    positioning = "93",
    vision = "81",
    ballcontrol = "90",
    crossing = "76",
    dribbling = "90",
    finishing = "93",
    freekickaccuracy = "91",
    headingaccuracy = "95",
    longpassing = "80",
    shortpassing = "84",
    defensiveawareness = "42",
    shotpower = "88",
    longshots = "80",
    standingtackle = "50",
    slidingtackle = "54",
    volleys = "85",
    curve = "83",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "151715863",
    trait2 = "0",
    icontrait1 = "4194304",
    icontrait2 = "48",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Luis",
    lastname = "Hernández",
    surname = "Hernández",
    commonname = "Luis Hernández",
    playerjerseyname = "Hernández"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Luis Hernández (ID: %s).", entry.playerid))
