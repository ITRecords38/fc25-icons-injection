-- ICON Player Script - PlayerExists Check Only
local playerid = 54050

if PlayerExists(playerid) then
    Log("Player with ID: 54050 exists")
else
    Log("Player with ID: 54050 doesn't exists")
end

local player_data = {
    playerid = "54050",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Rooney",
    overallrating = "89",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "88",
    agility = "85",
    balance = "85",
    jumping = "86",
    stamina = "90",
    strength = "86",
    reactions = "93",
    aggression = "89",
    composure = "88",
    interceptions = "49",
    positioning = "91",
    vision = "88",
    ballcontrol = "92",
    crossing = "87",
    dribbling = "87",
    finishing = "90",
    freekickaccuracy = "92",
    headingaccuracy = "94",
    longpassing = "92",
    shortpassing = "93",
    defensiveawareness = "58",
    shotpower = "93",
    longshots = "92",
    standingtackle = "62",
    slidingtackle = "49",
    volleys = "91",
    curve = "91",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "58720710",
    trait2 = "0",
    icontrait1 = "65537",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Wayne",
    lastname = "Rooney",
    surname = "Rooney",
    commonname = "Wayne Rooney",
    playerjerseyname = "Rooney"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Wayne Rooney (ID: %s).", entry.playerid))
