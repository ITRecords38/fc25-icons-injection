-- ICON Player Script - PlayerExists Check Only
local playerid = 156616

if PlayerExists(playerid) then
    Log("Player with ID: 156616 exists")
else
    Log("Player with ID: 156616 doesn't exists")
end

local player_data = {
    playerid = "156616",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ribéry",
    overallrating = "96",
    preferredposition1 = "16",
    preferredposition2 = "18",
    preferredposition3 = "27",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "97",
    sprintspeed = "95",
    agility = "96",
    balance = "95",
    jumping = "62",
    stamina = "96",
    strength = "76",
    reactions = "93",
    aggression = "75",
    composure = "92",
    interceptions = "52",
    positioning = "92",
    vision = "96",
    ballcontrol = "98",
    crossing = "92",
    dribbling = "97",
    finishing = "92",
    freekickaccuracy = "93",
    headingaccuracy = "66",
    longpassing = "92",
    shortpassing = "96",
    defensiveawareness = "54",
    shotpower = "90",
    longshots = "92",
    standingtackle = "50",
    slidingtackle = "44",
    volleys = "95",
    curve = "92",
    penalties = "89",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18088746",
    trait2 = "0",
    icontrait1 = "12648449",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Franck",
    lastname = "Ribéry",
    surname = "Ribéry",
    commonname = "Franck Ribéry",
    playerjerseyname = "Ribéry"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Franck Ribéry (ID: %s).", entry.playerid))
