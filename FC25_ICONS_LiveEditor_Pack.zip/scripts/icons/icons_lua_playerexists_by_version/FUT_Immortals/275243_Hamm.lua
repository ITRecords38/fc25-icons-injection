-- ICON Player Script - PlayerExists Check Only
local playerid = 275243

if PlayerExists(playerid) then
    Log("Player with ID: 275243 exists")
else
    Log("Player with ID: 275243 doesn't exists")
end

local player_data = {
    playerid = "275243",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Hamm",
    overallrating = "96",
    preferredposition1 = "25",
    preferredposition2 = "18",
    preferredposition3 = "23",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "96",
    sprintspeed = "94",
    agility = "90",
    balance = "92",
    jumping = "86",
    stamina = "93",
    strength = "85",
    reactions = "96",
    aggression = "71",
    composure = "92",
    interceptions = "58",
    positioning = "96",
    vision = "90",
    ballcontrol = "94",
    crossing = "81",
    dribbling = "95",
    finishing = "96",
    freekickaccuracy = "94",
    headingaccuracy = "90",
    longpassing = "90",
    shortpassing = "94",
    defensiveawareness = "48",
    shotpower = "97",
    longshots = "90",
    standingtackle = "58",
    slidingtackle = "55",
    volleys = "92",
    curve = "89",
    penalties = "91",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "9306163",
    trait2 = "0",
    icontrait1 = "6291460",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Mia",
    lastname = "Hamm",
    surname = "Hamm",
    commonname = "Mia Hamm",
    playerjerseyname = "Hamm"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Mia Hamm (ID: %s).", entry.playerid))
