-- ICON Player Script - PlayerExists Check Only
local playerid = 71557

if PlayerExists(playerid) then
    Log("Player with ID: 71557 exists")
else
    Log("Player with ID: 71557 doesn't exists")
end

local player_data = {
    playerid = "71557",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Bale",
    overallrating = "90",
    preferredposition1 = "7",
    preferredposition2 = "16",
    preferredposition3 = "25",
    preferredposition4 = "27",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "97",
    sprintspeed = "97",
    agility = "90",
    balance = "88",
    jumping = "86",
    stamina = "89",
    strength = "81",
    reactions = "92",
    aggression = "69",
    composure = "90",
    interceptions = "90",
    positioning = "87",
    vision = "86",
    ballcontrol = "90",
    crossing = "88",
    dribbling = "91",
    finishing = "89",
    freekickaccuracy = "91",
    headingaccuracy = "99",
    longpassing = "86",
    shortpassing = "89",
    defensiveawareness = "90",
    shotpower = "93",
    longshots = "86",
    standingtackle = "90",
    slidingtackle = "82",
    volleys = "88",
    curve = "90",
    penalties = "83",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "180367872",
    trait2 = "48",
    icontrait1 = "132096",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gareth",
    lastname = "Bale",
    surname = "Bale",
    commonname = "Gareth Bale",
    playerjerseyname = "Bale"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gareth Bale (ID: %s).", entry.playerid))
