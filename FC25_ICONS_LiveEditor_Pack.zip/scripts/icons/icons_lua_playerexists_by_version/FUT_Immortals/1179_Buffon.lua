-- ICON Player Script - PlayerExists Check Only
local playerid = 1179

if PlayerExists(playerid) then
    Log("Player with ID: 1179 exists")
else
    Log("Player with ID: 1179 doesn't exists")
end

local player_data = {
    playerid = "1179",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Buffon",
    overallrating = "95",
    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "0",
    weakfootabilitytypecode = "4",
    acceleration = "70",
    sprintspeed = "63",
    agility = "64",
    balance = "58",
    jumping = "78",
    stamina = "42",
    strength = "75",
    reactions = "88",
    aggression = "42",
    composure = "70",
    interceptions = "28",
    positioning = "14",
    vision = "67",
    ballcontrol = "26",
    crossing = "13",
    dribbling = "25",
    finishing = "19",
    freekickaccuracy = "17",
    headingaccuracy = "13",
    longpassing = "35",
    shortpassing = "37",
    defensiveawareness = "18",
    shotpower = "59",
    longshots = "35",
    standingtackle = "16",
    slidingtackle = "14",
    volleys = "18",
    curve = "23",
    penalties = "25",
    gkdiving = "98",
    gkhandling = "90",
    gkkicking = "85",
    gkreflexes = "97",
    gkpositioning = "94",
    trait1 = "805306560",
    trait2 = "2",
    icontrait1 = "0",
    icontrait2 = "12",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gianluigi",
    lastname = "Buffon",
    surname = "Buffon",
    commonname = "Gianluigi Buffon",
    playerjerseyname = "Buffon"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gianluigi Buffon (ID: %s).", entry.playerid))
