-- ICON Player Script - PlayerExists Check Only
local playerid = 1041

if PlayerExists(playerid) then
    Log("Player with ID: 1041 exists")
else
    Log("Player with ID: 1041 doesn't exists")
end

local player_data = {
    playerid = "1041",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Zanetti",
    overallrating = "89",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "90",
    agility = "86",
    balance = "87",
    jumping = "54",
    stamina = "96",
    strength = "80",
    reactions = "90",
    aggression = "90",
    composure = "89",
    interceptions = "92",
    positioning = "88",
    vision = "94",
    ballcontrol = "91",
    crossing = "94",
    dribbling = "85",
    finishing = "84",
    freekickaccuracy = "62",
    headingaccuracy = "84",
    longpassing = "95",
    shortpassing = "97",
    defensiveawareness = "88",
    shotpower = "88",
    longshots = "95",
    standingtackle = "90",
    slidingtackle = "88",
    volleys = "81",
    curve = "71",
    penalties = "92",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10560676",
    trait2 = "0",
    icontrait1 = "4160",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Javier",
    lastname = "Zanetti",
    surname = "Zanetti",
    commonname = "Javier Zanetti",
    playerjerseyname = "Zanetti"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Javier Zanetti (ID: %s).", entry.playerid))
