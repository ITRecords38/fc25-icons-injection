-- ICON Player Script - PlayerExists Check Only
local playerid = 227263

if PlayerExists(playerid) then
    Log("Player with ID: 227263 exists")
else
    Log("Player with ID: 227263 doesn't exists")
end

local player_data = {
    playerid = "227263",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Smith",
    overallrating = "90",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "91",
    agility = "88",
    balance = "88",
    jumping = "82",
    stamina = "88",
    strength = "85",
    reactions = "92",
    aggression = "59",
    composure = "92",
    interceptions = "37",
    positioning = "94",
    vision = "90",
    ballcontrol = "93",
    crossing = "86",
    dribbling = "92",
    finishing = "95",
    freekickaccuracy = "94",
    headingaccuracy = "88",
    longpassing = "74",
    shortpassing = "90",
    defensiveawareness = "36",
    shotpower = "90",
    longshots = "74",
    standingtackle = "52",
    slidingtackle = "48",
    volleys = "89",
    curve = "93",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134873114",
    trait2 = "0",
    icontrait1 = "1048577",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Kelly",
    lastname = "Smith",
    surname = "Smith",
    commonname = "Kelly Smith",
    playerjerseyname = "Smith"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Kelly Smith (ID: %s).", entry.playerid))
