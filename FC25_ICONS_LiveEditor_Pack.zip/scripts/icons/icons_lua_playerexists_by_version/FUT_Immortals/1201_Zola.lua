-- ICON Player Script - PlayerExists Check Only
local playerid = 1201

if PlayerExists(playerid) then
    Log("Player with ID: 1201 exists")
else
    Log("Player with ID: 1201 doesn't exists")
end

local player_data = {
    playerid = "1201",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Zola",
    overallrating = "88",
    preferredposition1 = "25",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "92",
    sprintspeed = "90",
    agility = "88",
    balance = "90",
    jumping = "54",
    stamina = "81",
    strength = "62",
    reactions = "90",
    aggression = "67",
    composure = "87",
    interceptions = "33",
    positioning = "94",
    vision = "90",
    ballcontrol = "90",
    crossing = "85",
    dribbling = "94",
    finishing = "94",
    freekickaccuracy = "93",
    headingaccuracy = "66",
    longpassing = "85",
    shortpassing = "89",
    defensiveawareness = "42",
    shotpower = "93",
    longshots = "85",
    standingtackle = "45",
    slidingtackle = "39",
    volleys = "86",
    curve = "90",
    penalties = "89",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18153484",
    trait2 = "48",
    icontrait1 = "4194305",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gianfranco",
    lastname = "Zola",
    surname = "Zola",
    commonname = "Gianfranco Zola",
    playerjerseyname = "Zola"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gianfranco Zola (ID: %s).", entry.playerid))
