-- ICON Player Script - PlayerExists Check Only
local playerid = 227324

if PlayerExists(playerid) then
    Log("Player with ID: 227324 exists")
else
    Log("Player with ID: 227324 doesn't exists")
end

local player_data = {
    playerid = "227324",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Abily",
    overallrating = "93",
    preferredposition1 = "14",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "91",
    sprintspeed = "90",
    agility = "90",
    balance = "88",
    jumping = "71",
    stamina = "90",
    strength = "82",
    reactions = "92",
    aggression = "80",
    composure = "93",
    interceptions = "90",
    positioning = "91",
    vision = "95",
    ballcontrol = "96",
    crossing = "87",
    dribbling = "91",
    finishing = "91",
    freekickaccuracy = "96",
    headingaccuracy = "71",
    longpassing = "94",
    shortpassing = "96",
    defensiveawareness = "86",
    shotpower = "91",
    longshots = "94",
    standingtackle = "87",
    slidingtackle = "84",
    volleys = "95",
    curve = "93",
    penalties = "81",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "34406475",
    trait2 = "0",
    icontrait1 = "4384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Camille",
    lastname = "Abily",
    surname = "Abily",
    commonname = "Camille Abily",
    playerjerseyname = "Abily"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Camille Abily (ID: %s).", entry.playerid))
