-- ICON Player Script - PlayerExists Check Only
local playerid = 268513

if PlayerExists(playerid) then
    Log("Player with ID: 268513 exists")
else
    Log("Player with ID: 268513 doesn't exists")
end

local player_data = {
    playerid = "268513",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Filho",
    overallrating = "93",
    preferredposition1 = "23",
    preferredposition2 = "12",
    preferredposition3 = "25",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "96",
    sprintspeed = "94",
    agility = "94",
    balance = "92",
    jumping = "87",
    stamina = "88",
    strength = "85",
    reactions = "92",
    aggression = "60",
    composure = "95",
    interceptions = "51",
    positioning = "92",
    vision = "95",
    ballcontrol = "92",
    crossing = "91",
    dribbling = "97",
    finishing = "95",
    freekickaccuracy = "82",
    headingaccuracy = "93",
    longpassing = "86",
    shortpassing = "91",
    defensiveawareness = "47",
    shotpower = "94",
    longshots = "86",
    standingtackle = "49",
    slidingtackle = "47",
    volleys = "90",
    curve = "87",
    penalties = "82",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "55312932",
    trait2 = "0",
    icontrait1 = "1245184",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Jair Ventura",
    lastname = "Filho",
    surname = "Filho",
    commonname = "Jair Ventura Filho",
    playerjerseyname = "Filho"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Jair Ventura Filho (ID: %s).", entry.playerid))
