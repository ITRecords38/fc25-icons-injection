-- ICON Player Script - PlayerExists Check Only
local playerid = 250890

if PlayerExists(playerid) then
    Log("Player with ID: 250890 exists")
else
    Log("Player with ID: 250890 doesn't exists")
end

local player_data = {
    playerid = "250890",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Zambrotta",
    overallrating = "89",
    preferredposition1 = "12",
    preferredposition2 = "3",
    preferredposition3 = "7",
    preferredposition4 = "16",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "92",
    agility = "90",
    balance = "87",
    jumping = "80",
    stamina = "89",
    strength = "83",
    reactions = "93",
    aggression = "87",
    composure = "92",
    interceptions = "87",
    positioning = "90",
    vision = "89",
    ballcontrol = "93",
    crossing = "95",
    dribbling = "91",
    finishing = "86",
    freekickaccuracy = "67",
    headingaccuracy = "80",
    longpassing = "88",
    shortpassing = "90",
    defensiveawareness = "86",
    shotpower = "92",
    longshots = "88",
    standingtackle = "91",
    slidingtackle = "89",
    volleys = "85",
    curve = "90",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10570241",
    trait2 = "0",
    icontrait1 = "4194336",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gianluca",
    lastname = "Zambrotta",
    surname = "Zambrotta",
    commonname = "Gianluca Zambrotta",
    playerjerseyname = "Zambrotta"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gianluca Zambrotta (ID: %s).", entry.playerid))
