-- ICON Player Script - PlayerExists Check Only
local playerid = 166691

if PlayerExists(playerid) then
    Log("Player with ID: 166691 exists")
else
    Log("Player with ID: 166691 doesn't exists")
end

local player_data = {
    playerid = "166691",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Coimbra",
    overallrating = "94",
    preferredposition1 = "18",
    preferredposition2 = "14",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "93",
    agility = "92",
    balance = "90",
    jumping = "82",
    stamina = "88",
    strength = "78",
    reactions = "92",
    aggression = "50",
    composure = "92",
    interceptions = "66",
    positioning = "92",
    vision = "96",
    ballcontrol = "96",
    crossing = "90",
    dribbling = "95",
    finishing = "95",
    freekickaccuracy = "99",
    headingaccuracy = "78",
    longpassing = "90",
    shortpassing = "96",
    defensiveawareness = "61",
    shotpower = "95",
    longshots = "90",
    standingtackle = "70",
    slidingtackle = "65",
    volleys = "93",
    curve = "97",
    penalties = "91",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "18612545",
    trait2 = "0",
    icontrait1 = "65576",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Arthur Antunes",
    lastname = "Coimbra",
    surname = "Coimbra",
    commonname = "Arthur Antunes Coimbra",
    playerjerseyname = "Coimbra"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Arthur Antunes Coimbra (ID: %s).", entry.playerid))
