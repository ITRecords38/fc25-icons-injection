-- ICON Player Script - PlayerExists Check Only
local playerid = 238435

if PlayerExists(playerid) then
    Log("Player with ID: 238435 exists")
else
    Log("Player with ID: 238435 doesn't exists")
end

local player_data = {
    playerid = "238435",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Matthäus",
    overallrating = "90",
    preferredposition1 = "5",
    preferredposition2 = "10",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "94",
    sprintspeed = "87",
    agility = "78",
    balance = "80",
    jumping = "84",
    stamina = "96",
    strength = "85",
    reactions = "87",
    aggression = "94",
    composure = "88",
    interceptions = "94",
    positioning = "85",
    vision = "90",
    ballcontrol = "84",
    crossing = "83",
    dribbling = "75",
    finishing = "77",
    freekickaccuracy = "91",
    headingaccuracy = "82",
    longpassing = "92",
    shortpassing = "92",
    defensiveawareness = "91",
    shotpower = "92",
    longshots = "92",
    standingtackle = "95",
    slidingtackle = "92",
    volleys = "86",
    curve = "76",
    penalties = "91",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "12611712",
    trait2 = "0",
    icontrait1 = "34816",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lothar",
    lastname = "Matthäus",
    surname = "Matthäus",
    commonname = "Lothar Matthäus",
    playerjerseyname = "Matthäus"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lothar Matthäus (ID: %s).", entry.playerid))
