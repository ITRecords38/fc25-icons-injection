-- ICON Player Script - PlayerExists Check Only
local playerid = 238443

if PlayerExists(playerid) then
    Log("Player with ID: 238443 exists")
else
    Log("Player with ID: 238443 doesn't exists")
end

local player_data = {
    playerid = "238443",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Blanc",
    overallrating = "89",
    preferredposition1 = "18",
    preferredposition2 = "5",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "84",
    sprintspeed = "88",
    agility = "88",
    balance = "85",
    jumping = "77",
    stamina = "88",
    strength = "85",
    reactions = "94",
    aggression = "87",
    composure = "93",
    interceptions = "90",
    positioning = "84",
    vision = "88",
    ballcontrol = "93",
    crossing = "80",
    dribbling = "85",
    finishing = "84",
    freekickaccuracy = "85",
    headingaccuracy = "85",
    longpassing = "92",
    shortpassing = "93",
    defensiveawareness = "92",
    shotpower = "88",
    longshots = "92",
    standingtackle = "93",
    slidingtackle = "88",
    volleys = "86",
    curve = "87",
    penalties = "95",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "138486049",
    trait2 = "0",
    icontrait1 = "524352",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Laurent",
    lastname = "Blanc",
    surname = "Blanc",
    commonname = "Laurent Blanc",
    playerjerseyname = "Blanc"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Laurent Blanc (ID: %s).", entry.playerid))
