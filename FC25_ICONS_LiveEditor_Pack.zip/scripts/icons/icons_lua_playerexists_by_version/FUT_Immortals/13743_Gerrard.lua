-- ICON Player Script - PlayerExists Check Only
local playerid = 13743

if PlayerExists(playerid) then
    Log("Player with ID: 13743 exists")
else
    Log("Player with ID: 13743 doesn't exists")
end

local player_data = {
    playerid = "13743",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Gerrard",
    overallrating = "93",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "87",
    sprintspeed = "89",
    agility = "88",
    balance = "87",
    jumping = "76",
    stamina = "91",
    strength = "84",
    reactions = "90",
    aggression = "87",
    composure = "88",
    interceptions = "88",
    positioning = "90",
    vision = "92",
    ballcontrol = "93",
    crossing = "90",
    dribbling = "88",
    finishing = "90",
    freekickaccuracy = "85",
    headingaccuracy = "84",
    longpassing = "99",
    shortpassing = "96",
    defensiveawareness = "87",
    shotpower = "94",
    longshots = "99",
    standingtackle = "89",
    slidingtackle = "84",
    volleys = "87",
    curve = "87",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "16844480",
    trait2 = "0",
    icontrait1 = "4132",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Steven",
    lastname = "Gerrard",
    surname = "Gerrard",
    commonname = "Steven Gerrard",
    playerjerseyname = "Gerrard"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Steven Gerrard (ID: %s).", entry.playerid))
