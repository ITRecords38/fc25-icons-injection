-- ICON Player Script - PlayerExists Check Only
local playerid = 37576

if PlayerExists(playerid) then
    Log("Player with ID: 37576 exists")
else
    Log("Player with ID: 37576 doesn't exists")
end

local player_data = {
    playerid = "37576",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lima",
    overallrating = "96",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "97",
    sprintspeed = "96",
    agility = "91",
    balance = "90",
    jumping = "84",
    stamina = "86",
    strength = "88",
    reactions = "96",
    aggression = "53",
    composure = "91",
    interceptions = "42",
    positioning = "97",
    vision = "82",
    ballcontrol = "96",
    crossing = "74",
    dribbling = "98",
    finishing = "99",
    freekickaccuracy = "90",
    headingaccuracy = "88",
    longpassing = "75",
    shortpassing = "86",
    defensiveawareness = "38",
    shotpower = "95",
    longshots = "75",
    standingtackle = "42",
    slidingtackle = "37",
    volleys = "97",
    curve = "87",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "7930112",
    trait2 = "0",
    icontrait1 = "131073",
    icontrait2 = "48",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ronaldo Luís Nazário de",
    lastname = "Lima",
    surname = "Lima",
    commonname = "Ronaldo Luís Nazário de Lima",
    playerjerseyname = "Lima"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ronaldo Luís Nazário de Lima (ID: %s).", entry.playerid))
