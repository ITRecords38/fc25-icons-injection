-- ICON Player Script - PlayerExists Check Only
local playerid = 237067

if PlayerExists(playerid) then
    Log("Player with ID: 237067 exists")
else
    Log("Player with ID: 237067 doesn't exists")
end

local player_data = {
    playerid = "237067",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Nascimento",
    overallrating = "97",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "95",
    sprintspeed = "95",
    agility = "94",
    balance = "93",
    jumping = "94",
    stamina = "90",
    strength = "82",
    reactions = "98",
    aggression = "71",
    composure = "98",
    interceptions = "68",
    positioning = "97",
    vision = "97",
    ballcontrol = "97",
    crossing = "91",
    dribbling = "96",
    finishing = "99",
    freekickaccuracy = "89",
    headingaccuracy = "97",
    longpassing = "88",
    shortpassing = "96",
    defensiveawareness = "57",
    shotpower = "95",
    longshots = "88",
    standingtackle = "53",
    slidingtackle = "51",
    volleys = "96",
    curve = "89",
    penalties = "93",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "14155941",
    trait2 = "0",
    icontrait1 = "65792",
    icontrait2 = "48",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Edson Arantes",
    lastname = "Nascimento",
    surname = "Nascimento",
    commonname = "Edson Arantes Nascimento",
    playerjerseyname = "Nascimento"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Edson Arantes Nascimento (ID: %s).", entry.playerid))
