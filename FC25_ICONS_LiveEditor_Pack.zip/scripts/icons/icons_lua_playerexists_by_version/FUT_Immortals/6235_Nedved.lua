-- ICON Player Script - PlayerExists Check Only
local playerid = 6235

if PlayerExists(playerid) then
    Log("Player with ID: 6235 exists")
else
    Log("Player with ID: 6235 doesn't exists")
end

local player_data = {
    playerid = "6235",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Nedved",
    overallrating = "94",
    preferredposition1 = "16",
    preferredposition2 = "18",
    preferredposition3 = "27",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "92",
    sprintspeed = "92",
    agility = "91",
    balance = "90",
    jumping = "73",
    stamina = "97",
    strength = "80",
    reactions = "92",
    aggression = "90",
    composure = "90",
    interceptions = "70",
    positioning = "90",
    vision = "95",
    ballcontrol = "95",
    crossing = "94",
    dribbling = "96",
    finishing = "84",
    freekickaccuracy = "93",
    headingaccuracy = "83",
    longpassing = "93",
    shortpassing = "94",
    defensiveawareness = "70",
    shotpower = "92",
    longshots = "93",
    standingtackle = "57",
    slidingtackle = "54",
    volleys = "84",
    curve = "92",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "9110025",
    trait2 = "0",
    icontrait1 = "16777284",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Pavel",
    lastname = "Nedved",
    surname = "Nedved",
    commonname = "Pavel Nedved",
    playerjerseyname = "Nedved"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Pavel Nedved (ID: %s).", entry.playerid))
