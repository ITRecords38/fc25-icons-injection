-- ICON Player Script - PlayerExists Check Only
local playerid = 168473

if PlayerExists(playerid) then
    Log("Player with ID: 168473 exists")
else
    Log("Player with ID: 168473 doesn't exists")
end

local player_data = {
    playerid = "168473",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Beckenbauer",
    overallrating = "96",
    preferredposition1 = "5",
    preferredposition2 = "10",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "86",
    agility = "87",
    balance = "84",
    jumping = "99",
    stamina = "94",
    strength = "88",
    reactions = "95",
    aggression = "86",
    composure = "92",
    interceptions = "98",
    positioning = "78",
    vision = "94",
    ballcontrol = "94",
    crossing = "80",
    dribbling = "83",
    finishing = "74",
    freekickaccuracy = "86",
    headingaccuracy = "93",
    longpassing = "98",
    shortpassing = "99",
    defensiveawareness = "98",
    shotpower = "78",
    longshots = "98",
    standingtackle = "96",
    slidingtackle = "94",
    volleys = "72",
    curve = "81",
    penalties = "70",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "151099488",
    trait2 = "0",
    icontrait1 = "9344",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Franz",
    lastname = "Beckenbauer",
    surname = "Beckenbauer",
    commonname = "Franz Beckenbauer",
    playerjerseyname = "Beckenbauer"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Franz Beckenbauer (ID: %s).", entry.playerid))
