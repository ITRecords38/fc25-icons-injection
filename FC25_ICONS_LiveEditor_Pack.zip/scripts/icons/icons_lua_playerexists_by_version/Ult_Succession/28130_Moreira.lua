-- ICON Player Script - PlayerExists Check Only
local playerid = 28130

if PlayerExists(playerid) then
    Log("Player with ID: 28130 exists")
else
    Log("Player with ID: 28130 doesn't exists")
end

local player_data = {
    playerid = "28130",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Moreira",
    overallrating = "94",
    preferredposition1 = "27",
    preferredposition2 = "16",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "94",
    sprintspeed = "91",
    agility = "95",
    balance = "90",
    jumping = "87",
    stamina = "84",
    strength = "85",
    reactions = "93",
    aggression = "70",
    composure = "95",
    interceptions = "33",
    positioning = "90",
    vision = "93",
    ballcontrol = "96",
    crossing = "90",
    dribbling = "97",
    finishing = "93",
    freekickaccuracy = "92",
    headingaccuracy = "55",
    longpassing = "86",
    shortpassing = "92",
    defensiveawareness = "39",
    shotpower = "87",
    longshots = "86",
    standingtackle = "42",
    slidingtackle = "33",
    volleys = "83",
    curve = "90",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17629193",
    trait2 = "0",
    icontrait1 = "1048576",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ronaldo de Assis",
    lastname = "Moreira",
    surname = "Moreira",
    commonname = "Ronaldo de Assis Moreira",
    playerjerseyname = "Moreira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ronaldo de Assis Moreira (ID: %s).", entry.playerid))
