-- ICON Player Script - PlayerExists Check Only
local playerid = 166906

if PlayerExists(playerid) then
    Log("Player with ID: 166906 exists")
else
    Log("Player with ID: 166906 doesn't exists")
end

local player_data = {
    playerid = "166906",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Baresi",
    overallrating = "92",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "3",
    acceleration = "75",
    sprintspeed = "80",
    agility = "74",
    balance = "76",
    jumping = "87",
    stamina = "87",
    strength = "80",
    reactions = "94",
    aggression = "87",
    composure = "85",
    interceptions = "95",
    positioning = "41",
    vision = "71",
    ballcontrol = "87",
    crossing = "64",
    dribbling = "56",
    finishing = "46",
    freekickaccuracy = "45",
    headingaccuracy = "90",
    longpassing = "86",
    shortpassing = "88",
    defensiveawareness = "95",
    shotpower = "55",
    longshots = "86",
    standingtackle = "95",
    slidingtackle = "95",
    volleys = "51",
    curve = "58",
    penalties = "65",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "38016",
    trait2 = "0",
    icontrait1 = "16384",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Franco",
    lastname = "Baresi",
    surname = "Baresi",
    commonname = "Franco Baresi",
    playerjerseyname = "Baresi"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Franco Baresi (ID: %s).", entry.playerid))
