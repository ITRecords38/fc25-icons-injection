-- ICON Player Script - PlayerExists Check Only
local playerid = 121939

if PlayerExists(playerid) then
    Log("Player with ID: 121939 exists")
else
    Log("Player with ID: 121939 doesn't exists")
end

local player_data = {
    playerid = "121939",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lahm",
    overallrating = "90",
    preferredposition1 = "3",
    preferredposition2 = "7",
    preferredposition3 = "10",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "86",
    sprintspeed = "84",
    agility = "84",
    balance = "92",
    jumping = "76",
    stamina = "92",
    strength = "63",
    reactions = "90",
    aggression = "70",
    composure = "92",
    interceptions = "93",
    positioning = "74",
    vision = "82",
    ballcontrol = "87",
    crossing = "88",
    dribbling = "80",
    finishing = "66",
    freekickaccuracy = "60",
    headingaccuracy = "70",
    longpassing = "84",
    shortpassing = "85",
    defensiveawareness = "94",
    shotpower = "70",
    longshots = "84",
    standingtackle = "90",
    slidingtackle = "95",
    volleys = "64",
    curve = "84",
    penalties = "76",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2122368",
    trait2 = "0",
    icontrait1 = "4096",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Philipp",
    lastname = "Lahm",
    surname = "Lahm",
    commonname = "Philipp Lahm",
    playerjerseyname = "Lahm"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Philipp Lahm (ID: %s).", entry.playerid))
