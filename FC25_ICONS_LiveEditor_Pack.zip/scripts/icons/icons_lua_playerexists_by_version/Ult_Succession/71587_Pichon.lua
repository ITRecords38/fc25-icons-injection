-- ICON Player Script - PlayerExists Check Only
local playerid = 71587

if PlayerExists(playerid) then
    Log("Player with ID: 71587 exists")
else
    Log("Player with ID: 71587 doesn't exists")
end

local player_data = {
    playerid = "71587",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Pichon",
    overallrating = "89",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "86",
    sprintspeed = "88",
    agility = "88",
    balance = "86",
    jumping = "83",
    stamina = "90",
    strength = "75",
    reactions = "88",
    aggression = "60",
    composure = "87",
    interceptions = "42",
    positioning = "92",
    vision = "83",
    ballcontrol = "91",
    crossing = "74",
    dribbling = "90",
    finishing = "93",
    freekickaccuracy = "80",
    headingaccuracy = "82",
    longpassing = "78",
    shortpassing = "86",
    defensiveawareness = "38",
    shotpower = "85",
    longshots = "78",
    standingtackle = "44",
    slidingtackle = "34",
    volleys = "93",
    curve = "83",
    penalties = "83",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "51118081",
    trait2 = "0",
    icontrait1 = "65536",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marinette",
    lastname = "Pichon",
    surname = "Pichon",
    commonname = "Marinette Pichon",
    playerjerseyname = "Pichon"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marinette Pichon (ID: %s).", entry.playerid))
