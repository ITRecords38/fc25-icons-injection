-- ICON Player Script - PlayerExists Check Only
local playerid = 238439

if PlayerExists(playerid) then
    Log("Player with ID: 238439 exists")
else
    Log("Player with ID: 238439 doesn't exists")
end

local player_data = {
    playerid = "238439",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Maldini",
    overallrating = "93",
    preferredposition1 = "5",
    preferredposition2 = "7",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "4",
    acceleration = "85",
    sprintspeed = "86",
    agility = "66",
    balance = "70",
    jumping = "86",
    stamina = "83",
    strength = "87",
    reactions = "95",
    aggression = "81",
    composure = "95",
    interceptions = "96",
    positioning = "40",
    vision = "70",
    ballcontrol = "75",
    crossing = "76",
    dribbling = "63",
    finishing = "57",
    freekickaccuracy = "31",
    headingaccuracy = "94",
    longpassing = "81",
    shortpassing = "87",
    defensiveawareness = "95",
    shotpower = "73",
    longshots = "81",
    standingtackle = "97",
    slidingtackle = "96",
    volleys = "65",
    curve = "41",
    penalties = "54",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "134246400",
    trait2 = "0",
    icontrait1 = "1024",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Paolo",
    lastname = "Maldini",
    surname = "Maldini",
    commonname = "Paolo Maldini",
    playerjerseyname = "Maldini"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Paolo Maldini (ID: %s).", entry.playerid))
