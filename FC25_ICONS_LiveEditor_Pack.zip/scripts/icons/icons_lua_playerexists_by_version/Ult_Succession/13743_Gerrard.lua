-- ICON Player Script - PlayerExists Check Only
local playerid = 13743

if PlayerExists(playerid) then
    Log("Player with ID: 13743 exists")
else
    Log("Player with ID: 13743 doesn't exists")
end

local player_data = {
    playerid = "13743",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Gerrard",
    overallrating = "89",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "2",
    weakfootabilitytypecode = "4",
    acceleration = "80",
    sprintspeed = "80",
    agility = "80",
    balance = "78",
    jumping = "73",
    stamina = "88",
    strength = "81",
    reactions = "85",
    aggression = "84",
    composure = "84",
    interceptions = "75",
    positioning = "87",
    vision = "89",
    ballcontrol = "91",
    crossing = "87",
    dribbling = "84",
    finishing = "87",
    freekickaccuracy = "82",
    headingaccuracy = "73",
    longpassing = "95",
    shortpassing = "93",
    defensiveawareness = "75",
    shotpower = "91",
    longshots = "95",
    standingtackle = "78",
    slidingtackle = "73",
    volleys = "84",
    curve = "84",
    penalties = "84",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "16777952",
    trait2 = "0",
    icontrait1 = "4",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Steven",
    lastname = "Gerrard",
    surname = "Gerrard",
    commonname = "Steven Gerrard",
    playerjerseyname = "Gerrard"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Steven Gerrard (ID: %s).", entry.playerid))
