-- ICON Player Script - PlayerExists Check Only
local playerid = 138449

if PlayerExists(playerid) then
    Log("Player with ID: 138449 exists")
else
    Log("Player with ID: 138449 doesn't exists")
end

local player_data = {
    playerid = "138449",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Leite",
    overallrating = "90",
    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "91",
    sprintspeed = "90",
    agility = "87",
    balance = "85",
    jumping = "56",
    stamina = "86",
    strength = "77",
    reactions = "90",
    aggression = "48",
    composure = "94",
    interceptions = "47",
    positioning = "86",
    vision = "91",
    ballcontrol = "91",
    crossing = "87",
    dribbling = "92",
    finishing = "86",
    freekickaccuracy = "82",
    headingaccuracy = "61",
    longpassing = "84",
    shortpassing = "90",
    defensiveawareness = "45",
    shotpower = "88",
    longshots = "84",
    standingtackle = "38",
    slidingtackle = "36",
    volleys = "86",
    curve = "90",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "4194593",
    trait2 = "0",
    icontrait1 = "131072",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ricardo Izecson dos Santos",
    lastname = "Leite",
    surname = "Leite",
    commonname = "Ricardo Izecson dos Santos Leite",
    playerjerseyname = "Leite"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ricardo Izecson dos Santos Leite (ID: %s).", entry.playerid))
