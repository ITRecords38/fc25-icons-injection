-- ICON Player Script - PlayerExists Check Only
local playerid = 243029

if PlayerExists(playerid) then
    Log("Player with ID: 243029 exists")
else
    Log("Player with ID: 243029 doesn't exists")
end

local player_data = {
    playerid = "243029",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Campbell",
    overallrating = "93",
    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "87",
    sprintspeed = "93",
    agility = "72",
    balance = "72",
    jumping = "95",
    stamina = "87",
    strength = "99",
    reactions = "97",
    aggression = "95",
    composure = "93",
    interceptions = "92",
    positioning = "40",
    vision = "65",
    ballcontrol = "77",
    crossing = "60",
    dribbling = "58",
    finishing = "50",
    freekickaccuracy = "33",
    headingaccuracy = "96",
    longpassing = "77",
    shortpassing = "83",
    defensiveawareness = "95",
    shotpower = "68",
    longshots = "77",
    standingtackle = "92",
    slidingtackle = "98",
    volleys = "46",
    curve = "45",
    penalties = "55",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "167807056",
    trait2 = "0",
    icontrait1 = "20480",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Sol",
    lastname = "Campbell",
    surname = "Campbell",
    commonname = "Sol Campbell",
    playerjerseyname = "Campbell"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Sol Campbell (ID: %s).", entry.playerid))
