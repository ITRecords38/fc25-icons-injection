-- ICON Player Script - PlayerExists Check Only
local playerid = 247699

if PlayerExists(playerid) then
    Log("Player with ID: 247699 exists")
else
    Log("Player with ID: 247699 doesn't exists")
end

local player_data = {
    playerid = "247699",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Dalglish",
    overallrating = "94",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "95",
    sprintspeed = "92",
    agility = "95",
    balance = "94",
    jumping = "87",
    stamina = "93",
    strength = "74",
    reactions = "96",
    aggression = "77",
    composure = "93",
    interceptions = "35",
    positioning = "96",
    vision = "81",
    ballcontrol = "93",
    crossing = "81",
    dribbling = "93",
    finishing = "96",
    freekickaccuracy = "95",
    headingaccuracy = "96",
    longpassing = "60",
    shortpassing = "91",
    defensiveawareness = "39",
    shotpower = "92",
    longshots = "60",
    standingtackle = "44",
    slidingtackle = "41",
    volleys = "95",
    curve = "88",
    penalties = "93",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "21299206",
    trait2 = "0",
    icontrait1 = "1",
    icontrait2 = "48",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Kenny",
    lastname = "Dalglish",
    surname = "Dalglish",
    commonname = "Kenny Dalglish",
    playerjerseyname = "Dalglish"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Kenny Dalglish (ID: %s).", entry.playerid))
