-- ICON Player Script - PlayerExists Check Only
local playerid = 238427

if PlayerExists(playerid) then
    Log("Player with ID: 238427 exists")
else
    Log("Player with ID: 238427 doesn't exists")
end

local player_data = {
    playerid = "238427",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Vieira",
    overallrating = "94",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "89",
    sprintspeed = "87",
    agility = "86",
    balance = "85",
    jumping = "84",
    stamina = "98",
    strength = "95",
    reactions = "93",
    aggression = "97",
    composure = "93",
    interceptions = "98",
    positioning = "84",
    vision = "96",
    ballcontrol = "93",
    crossing = "72",
    dribbling = "88",
    finishing = "84",
    freekickaccuracy = "64",
    headingaccuracy = "88",
    longpassing = "96",
    shortpassing = "96",
    defensiveawareness = "90",
    shotpower = "88",
    longshots = "96",
    standingtackle = "97",
    slidingtackle = "91",
    volleys = "72",
    curve = "70",
    penalties = "80",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10545168",
    trait2 = "0",
    icontrait1 = "4160",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Patrick",
    lastname = "Vieira",
    surname = "Vieira",
    commonname = "Patrick Vieira",
    playerjerseyname = "Vieira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Patrick Vieira (ID: %s).", entry.playerid))
