-- ICON Player Script - PlayerExists Check Only
local playerid = 28130

if PlayerExists(playerid) then
    Log("Player with ID: 28130 exists")
else
    Log("Player with ID: 28130 doesn't exists")
end

local player_data = {
    playerid = "28130",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Moreira",
    overallrating = "95",
    preferredposition1 = "27",
    preferredposition2 = "16",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "96",
    sprintspeed = "93",
    agility = "96",
    balance = "93",
    jumping = "88",
    stamina = "87",
    strength = "86",
    reactions = "94",
    aggression = "71",
    composure = "96",
    interceptions = "34",
    positioning = "91",
    vision = "95",
    ballcontrol = "97",
    crossing = "92",
    dribbling = "98",
    finishing = "94",
    freekickaccuracy = "94",
    headingaccuracy = "57",
    longpassing = "88",
    shortpassing = "94",
    defensiveawareness = "40",
    shotpower = "89",
    longshots = "88",
    standingtackle = "43",
    slidingtackle = "34",
    volleys = "84",
    curve = "92",
    penalties = "88",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "17563945",
    trait2 = "0",
    icontrait1 = "1114112",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ronaldo de Assis",
    lastname = "Moreira",
    surname = "Moreira",
    commonname = "Ronaldo de Assis Moreira",
    playerjerseyname = "Moreira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ronaldo de Assis Moreira (ID: %s).", entry.playerid))
