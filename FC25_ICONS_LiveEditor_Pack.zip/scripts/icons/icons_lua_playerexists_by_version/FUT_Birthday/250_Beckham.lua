-- ICON Player Script - PlayerExists Check Only
local playerid = 250

if PlayerExists(playerid) then
    Log("Player with ID: 250 exists")
else
    Log("Player with ID: 250 doesn't exists")
end

local player_data = {
    playerid = "250",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Beckham",
    overallrating = "94",
    preferredposition1 = "14",
    preferredposition2 = "12",
    preferredposition3 = "23",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "93",
    agility = "90",
    balance = "90",
    jumping = "87",
    stamina = "97",
    strength = "81",
    reactions = "95",
    aggression = "84",
    composure = "96",
    interceptions = "84",
    positioning = "94",
    vision = "97",
    ballcontrol = "93",
    crossing = "99",
    dribbling = "90",
    finishing = "90",
    freekickaccuracy = "99",
    headingaccuracy = "88",
    longpassing = "98",
    shortpassing = "95",
    defensiveawareness = "81",
    shotpower = "92",
    longshots = "98",
    standingtackle = "83",
    slidingtackle = "76",
    volleys = "87",
    curve = "99",
    penalties = "94",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "8454882",
    trait2 = "48",
    icontrait1 = "9",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "David",
    lastname = "Beckham",
    surname = "Beckham",
    commonname = "David Beckham",
    playerjerseyname = "Beckham"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - David Beckham (ID: %s).", entry.playerid))
