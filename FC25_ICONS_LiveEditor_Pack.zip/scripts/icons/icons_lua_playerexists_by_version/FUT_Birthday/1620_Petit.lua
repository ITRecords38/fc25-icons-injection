-- ICON Player Script - PlayerExists Check Only
local playerid = 1620

if PlayerExists(playerid) then
    Log("Player with ID: 1620 exists")
else
    Log("Player with ID: 1620 doesn't exists")
end

local player_data = {
    playerid = "1620",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Petit",
    overallrating = "91",
    preferredposition1 = "14",
    preferredposition2 = "7",
    preferredposition3 = "10",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "84",
    sprintspeed = "86",
    agility = "88",
    balance = "85",
    jumping = "80",
    stamina = "94",
    strength = "90",
    reactions = "94",
    aggression = "92",
    composure = "97",
    interceptions = "90",
    positioning = "86",
    vision = "90",
    ballcontrol = "96",
    crossing = "83",
    dribbling = "84",
    finishing = "80",
    freekickaccuracy = "80",
    headingaccuracy = "80",
    longpassing = "93",
    shortpassing = "95",
    defensiveawareness = "84",
    shotpower = "95",
    longshots = "93",
    standingtackle = "90",
    slidingtackle = "86",
    volleys = "82",
    curve = "83",
    penalties = "68",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2125861",
    trait2 = "0",
    icontrait1 = "8454144",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Emmanuel",
    lastname = "Petit",
    surname = "Petit",
    commonname = "Emmanuel Petit",
    playerjerseyname = "Petit"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Emmanuel Petit (ID: %s).", entry.playerid))
