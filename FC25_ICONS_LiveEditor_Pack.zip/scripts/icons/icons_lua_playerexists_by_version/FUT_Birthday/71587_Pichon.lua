-- ICON Player Script - PlayerExists Check Only
local playerid = 71587

if PlayerExists(playerid) then
    Log("Player with ID: 71587 exists")
else
    Log("Player with ID: 71587 doesn't exists")
end

local player_data = {
    playerid = "71587",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Pichon",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "88",
    sprintspeed = "92",
    agility = "92",
    balance = "90",
    jumping = "87",
    stamina = "92",
    strength = "80",
    reactions = "91",
    aggression = "65",
    composure = "90",
    interceptions = "47",
    positioning = "95",
    vision = "86",
    ballcontrol = "94",
    crossing = "77",
    dribbling = "93",
    finishing = "96",
    freekickaccuracy = "83",
    headingaccuracy = "91",
    longpassing = "79",
    shortpassing = "89",
    defensiveawareness = "42",
    shotpower = "90",
    longshots = "79",
    standingtackle = "49",
    slidingtackle = "38",
    volleys = "96",
    curve = "86",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "52166657",
    trait2 = "48",
    icontrait1 = "196608",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marinette",
    lastname = "Pichon",
    surname = "Pichon",
    commonname = "Marinette Pichon",
    playerjerseyname = "Pichon"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marinette Pichon (ID: %s).", entry.playerid))
