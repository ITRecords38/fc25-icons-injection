-- ICON Player Script - PlayerExists Check Only
local playerid = 214267

if PlayerExists(playerid) then
    Log("Player with ID: 214267 exists")
else
    Log("Player with ID: 214267 doesn't exists")
end

local player_data = {
    playerid = "214267",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lineker",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "91",
    sprintspeed = "90",
    agility = "88",
    balance = "86",
    jumping = "79",
    stamina = "85",
    strength = "80",
    reactions = "95",
    aggression = "57",
    composure = "90",
    interceptions = "44",
    positioning = "95",
    vision = "80",
    ballcontrol = "92",
    crossing = "66",
    dribbling = "90",
    finishing = "96",
    freekickaccuracy = "73",
    headingaccuracy = "91",
    longpassing = "80",
    shortpassing = "91",
    defensiveawareness = "30",
    shotpower = "90",
    longshots = "80",
    standingtackle = "37",
    slidingtackle = "35",
    volleys = "92",
    curve = "75",
    penalties = "89",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10027047",
    trait2 = "0",
    icontrait1 = "4194304",
    icontrait2 = "48",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Gary",
    lastname = "Lineker",
    surname = "Lineker",
    commonname = "Gary Lineker",
    playerjerseyname = "Lineker"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Gary Lineker (ID: %s).", entry.playerid))
