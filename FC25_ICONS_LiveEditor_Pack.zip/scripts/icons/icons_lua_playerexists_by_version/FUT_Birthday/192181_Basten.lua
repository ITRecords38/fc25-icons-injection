-- ICON Player Script - PlayerExists Check Only
local playerid = 192181

if PlayerExists(playerid) then
    Log("Player with ID: 192181 exists")
else
    Log("Player with ID: 192181 doesn't exists")
end

local player_data = {
    playerid = "192181",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Basten",
    overallrating = "92",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "91",
    sprintspeed = "90",
    agility = "90",
    balance = "86",
    jumping = "85",
    stamina = "81",
    strength = "81",
    reactions = "95",
    aggression = "52",
    composure = "92",
    interceptions = "46",
    positioning = "95",
    vision = "81",
    ballcontrol = "93",
    crossing = "80",
    dribbling = "91",
    finishing = "96",
    freekickaccuracy = "82",
    headingaccuracy = "90",
    longpassing = "70",
    shortpassing = "84",
    defensiveawareness = "25",
    shotpower = "93",
    longshots = "70",
    standingtackle = "32",
    slidingtackle = "31",
    volleys = "97",
    curve = "82",
    penalties = "89",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "62980145",
    trait2 = "0",
    icontrait1 = "524292",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marco van",
    lastname = "Basten",
    surname = "Basten",
    commonname = "Marco van Basten",
    playerjerseyname = "Basten"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marco van Basten (ID: %s).", entry.playerid))
