-- ICON Player Script - PlayerExists Check Only
local playerid = 1615

if PlayerExists(playerid) then
    Log("Player with ID: 1615 exists")
else
    Log("Player with ID: 1615 doesn't exists")
end

local player_data = {
    playerid = "1615",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Thuram",
    overallrating = "94",
    preferredposition1 = "3",
    preferredposition2 = "5",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "92",
    sprintspeed = "91",
    agility = "87",
    balance = "88",
    jumping = "90",
    stamina = "93",
    strength = "94",
    reactions = "87",
    aggression = "94",
    composure = "90",
    interceptions = "92",
    positioning = "72",
    vision = "78",
    ballcontrol = "86",
    crossing = "78",
    dribbling = "85",
    finishing = "61",
    freekickaccuracy = "45",
    headingaccuracy = "90",
    longpassing = "82",
    shortpassing = "87",
    defensiveawareness = "96",
    shotpower = "67",
    longshots = "82",
    standingtackle = "92",
    slidingtackle = "97",
    volleys = "60",
    curve = "67",
    penalties = "45",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "142644224",
    trait2 = "0",
    icontrait1 = "26624",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Lilian",
    lastname = "Thuram",
    surname = "Thuram",
    commonname = "Lilian Thuram",
    playerjerseyname = "Thuram"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Lilian Thuram (ID: %s).", entry.playerid))
