-- ICON Player Script - PlayerExists Check Only
local playerid = 1116

if PlayerExists(playerid) then
    Log("Player with ID: 1116 exists")
else
    Log("Player with ID: 1116 doesn't exists")
end

local player_data = {
    playerid = "1116",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Desailly",
    overallrating = "92",
    preferredposition1 = "5",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "86",
    sprintspeed = "88",
    agility = "75",
    balance = "75",
    jumping = "86",
    stamina = "87",
    strength = "94",
    reactions = "90",
    aggression = "95",
    composure = "95",
    interceptions = "93",
    positioning = "54",
    vision = "87",
    ballcontrol = "80",
    crossing = "63",
    dribbling = "66",
    finishing = "43",
    freekickaccuracy = "50",
    headingaccuracy = "91",
    longpassing = "87",
    shortpassing = "91",
    defensiveawareness = "94",
    shotpower = "77",
    longshots = "87",
    standingtackle = "91",
    slidingtackle = "90",
    volleys = "54",
    curve = "60",
    penalties = "57",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "136343632",
    trait2 = "0",
    icontrait1 = "34816",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Marcel",
    lastname = "Desailly",
    surname = "Desailly",
    commonname = "Marcel Desailly",
    playerjerseyname = "Desailly"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Marcel Desailly (ID: %s).", entry.playerid))
