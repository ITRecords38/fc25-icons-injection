-- ICON Player Script - PlayerExists Check Only
local playerid = 138449

if PlayerExists(playerid) then
    Log("Player with ID: 138449 exists")
else
    Log("Player with ID: 138449 doesn't exists")
end

local player_data = {
    playerid = "138449",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Leite",
    overallrating = "94",
    preferredposition1 = "18",
    preferredposition2 = "25",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "92",
    sprintspeed = "92",
    agility = "90",
    balance = "88",
    jumping = "82",
    stamina = "92",
    strength = "93",
    reactions = "92",
    aggression = "80",
    composure = "97",
    interceptions = "51",
    positioning = "90",
    vision = "93",
    ballcontrol = "94",
    crossing = "90",
    dribbling = "95",
    finishing = "90",
    freekickaccuracy = "84",
    headingaccuracy = "67",
    longpassing = "86",
    shortpassing = "92",
    defensiveawareness = "50",
    shotpower = "92",
    longshots = "86",
    standingtackle = "41",
    slidingtackle = "40",
    volleys = "90",
    curve = "91",
    penalties = "90",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "15204708",
    trait2 = "0",
    icontrait1 = "131073",
    icontrait2 = "48",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Ricardo Izecson dos Santos",
    lastname = "Leite",
    surname = "Leite",
    commonname = "Ricardo Izecson dos Santos Leite",
    playerjerseyname = "Leite"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Ricardo Izecson dos Santos Leite (ID: %s).", entry.playerid))
