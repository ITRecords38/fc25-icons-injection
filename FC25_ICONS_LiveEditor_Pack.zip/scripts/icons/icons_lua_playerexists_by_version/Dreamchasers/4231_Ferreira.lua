-- ICON Player Script - PlayerExists Check Only
local playerid = 4231

if PlayerExists(playerid) then
    Log("Player with ID: 4231 exists")
else
    Log("Player with ID: 4231 doesn't exists")
end

local player_data = {
    playerid = "4231",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Ferreira",
    overallrating = "94",
    preferredposition1 = "27",
    preferredposition2 = "16",
    preferredposition3 = "18",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "91",
    agility = "93",
    balance = "91",
    jumping = "82",
    stamina = "92",
    strength = "87",
    reactions = "94",
    aggression = "82",
    composure = "94",
    interceptions = "40",
    positioning = "93",
    vision = "91",
    ballcontrol = "95",
    crossing = "90",
    dribbling = "95",
    finishing = "90",
    freekickaccuracy = "94",
    headingaccuracy = "80",
    longpassing = "87",
    shortpassing = "91",
    defensiveawareness = "41",
    shotpower = "95",
    longshots = "87",
    standingtackle = "46",
    slidingtackle = "42",
    volleys = "94",
    curve = "97",
    penalties = "89",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "35389453",
    trait2 = "48",
    icontrait1 = "196672",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Rivaldo Vítor Borba",
    lastname = "Ferreira",
    surname = "Ferreira",
    commonname = "Rivaldo Vítor Borba Ferreira",
    playerjerseyname = "Ferreira"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Rivaldo Vítor Borba Ferreira (ID: %s).", entry.playerid))
