-- ICON Player Script - PlayerExists Check Only
local playerid = 121939

if PlayerExists(playerid) then
    Log("Player with ID: 121939 exists")
else
    Log("Player with ID: 121939 doesn't exists")
end

local player_data = {
    playerid = "121939",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Lahm",
    overallrating = "92",
    preferredposition1 = "3",
    preferredposition2 = "7",
    preferredposition3 = "10",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "91",
    sprintspeed = "90",
    agility = "90",
    balance = "93",
    jumping = "86",
    stamina = "94",
    strength = "73",
    reactions = "91",
    aggression = "80",
    composure = "94",
    interceptions = "95",
    positioning = "85",
    vision = "90",
    ballcontrol = "90",
    crossing = "93",
    dribbling = "90",
    finishing = "75",
    freekickaccuracy = "62",
    headingaccuracy = "71",
    longpassing = "88",
    shortpassing = "89",
    defensiveawareness = "96",
    shotpower = "80",
    longshots = "88",
    standingtackle = "92",
    slidingtackle = "97",
    volleys = "73",
    curve = "88",
    penalties = "87",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "2644544",
    trait2 = "0",
    icontrait1 = "8320",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Philipp",
    lastname = "Lahm",
    surname = "Lahm",
    commonname = "Philipp Lahm",
    playerjerseyname = "Lahm"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Philipp Lahm (ID: %s).", entry.playerid))
