-- ICON Player Script - PlayerExists Check Only
local playerid = 45661

if PlayerExists(playerid) then
    Log("Player with ID: 45661 exists")
else
    Log("Player with ID: 45661 doesn't exists")
end

local player_data = {
    playerid = "45661",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Blanco",
    overallrating = "94",
    preferredposition1 = "25",
    preferredposition2 = "18",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "4",
    weakfootabilitytypecode = "4",
    acceleration = "90",
    sprintspeed = "92",
    agility = "91",
    balance = "93",
    jumping = "95",
    stamina = "91",
    strength = "77",
    reactions = "95",
    aggression = "48",
    composure = "95",
    interceptions = "41",
    positioning = "98",
    vision = "96",
    ballcontrol = "95",
    crossing = "86",
    dribbling = "90",
    finishing = "98",
    freekickaccuracy = "87",
    headingaccuracy = "99",
    longpassing = "80",
    shortpassing = "93",
    defensiveawareness = "47",
    shotpower = "92",
    longshots = "80",
    standingtackle = "47",
    slidingtackle = "34",
    volleys = "93",
    curve = "84",
    penalties = "86",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "151846918",
    trait2 = "0",
    icontrait1 = "4194305",
    icontrait2 = "48",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Raúl González",
    lastname = "Blanco",
    surname = "Blanco",
    commonname = "Raúl González Blanco",
    playerjerseyname = "Blanco"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Raúl González Blanco (ID: %s).", entry.playerid))
