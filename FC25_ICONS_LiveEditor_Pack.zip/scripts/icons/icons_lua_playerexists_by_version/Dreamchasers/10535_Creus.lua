-- ICON Player Script - PlayerExists Check Only
local playerid = 10535

if PlayerExists(playerid) then
    Log("Player with ID: 10535 exists")
else
    Log("Player with ID: 10535 doesn't exists")
end

local player_data = {
    playerid = "10535",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Creus",
    overallrating = "94",
    preferredposition1 = "14",
    preferredposition2 = "10",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "88",
    agility = "93",
    balance = "97",
    jumping = "82",
    stamina = "97",
    strength = "85",
    reactions = "96",
    aggression = "83",
    composure = "97",
    interceptions = "96",
    positioning = "98",
    vision = "99",
    ballcontrol = "98",
    crossing = "99",
    dribbling = "93",
    finishing = "83",
    freekickaccuracy = "99",
    headingaccuracy = "61",
    longpassing = "99",
    shortpassing = "99",
    defensiveawareness = "85",
    shotpower = "90",
    longshots = "99",
    standingtackle = "83",
    slidingtackle = "80",
    volleys = "75",
    curve = "99",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "28181120",
    trait2 = "0",
    icontrait1 = "352",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Xavier Hernández",
    lastname = "Creus",
    surname = "Creus",
    commonname = "Xavier Hernández Creus",
    playerjerseyname = "Creus"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Xavier Hernández Creus (ID: %s).", entry.playerid))
