-- ICON Player Script - PlayerExists Check Only
local playerid = 1668

if PlayerExists(playerid) then
    Log("Player with ID: 1668 exists")
else
    Log("Player with ID: 1668 doesn't exists")
end

local player_data = {
    playerid = "1668",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Makélélé",
    overallrating = "92",
    preferredposition1 = "10",
    preferredposition2 = "12",
    preferredposition3 = "14",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "4",
    acceleration = "88",
    sprintspeed = "86",
    agility = "88",
    balance = "92",
    jumping = "89",
    stamina = "95",
    strength = "88",
    reactions = "93",
    aggression = "92",
    composure = "91",
    interceptions = "96",
    positioning = "66",
    vision = "90",
    ballcontrol = "91",
    crossing = "79",
    dribbling = "85",
    finishing = "46",
    freekickaccuracy = "39",
    headingaccuracy = "61",
    longpassing = "92",
    shortpassing = "99",
    defensiveawareness = "93",
    shotpower = "66",
    longshots = "92",
    standingtackle = "98",
    slidingtackle = "90",
    volleys = "45",
    curve = "56",
    penalties = "54",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "10537344",
    trait2 = "0",
    icontrait1 = "5120",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Claude",
    lastname = "Makélélé",
    surname = "Makélélé",
    commonname = "Claude Makélélé",
    playerjerseyname = "Makélélé"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Claude Makélélé (ID: %s).", entry.playerid))
