-- ICON Player Script - PlayerExists Check Only
local playerid = 275276

if PlayerExists(playerid) then
    Log("Player with ID: 275276 exists")
else
    Log("Player with ID: 275276 doesn't exists")
end

local player_data = {
    playerid = "275276",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Prinz",
    overallrating = "94",
    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "3",
    weakfootabilitytypecode = "5",
    acceleration = "90",
    sprintspeed = "90",
    agility = "87",
    balance = "86",
    jumping = "87",
    stamina = "86",
    strength = "97",
    reactions = "94",
    aggression = "84",
    composure = "93",
    interceptions = "47",
    positioning = "96",
    vision = "86",
    ballcontrol = "94",
    crossing = "72",
    dribbling = "91",
    finishing = "96",
    freekickaccuracy = "84",
    headingaccuracy = "97",
    longpassing = "72",
    shortpassing = "89",
    defensiveawareness = "48",
    shotpower = "96",
    longshots = "72",
    standingtackle = "55",
    slidingtackle = "43",
    volleys = "93",
    curve = "79",
    penalties = "85",
    gkdiving = "10",
    gkhandling = "10",
    gkkicking = "10",
    gkreflexes = "10",
    gkpositioning = "10",
    trait1 = "155779092",
    trait2 = "48",
    icontrait1 = "2097153",
    icontrait2 = "0",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Birgit",
    lastname = "Prinz",
    surname = "Prinz",
    commonname = "Birgit Prinz",
    playerjerseyname = "Prinz"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Birgit Prinz (ID: %s).", entry.playerid))
