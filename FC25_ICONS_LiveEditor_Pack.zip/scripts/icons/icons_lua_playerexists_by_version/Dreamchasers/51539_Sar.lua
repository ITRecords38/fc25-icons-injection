-- ICON Player Script - PlayerExists Check Only
local playerid = 51539

if PlayerExists(playerid) then
    Log("Player with ID: 51539 exists")
else
    Log("Player with ID: 51539 doesn't exists")
end

local player_data = {
    playerid = "51539",
    nationality = "18",
    contractvaliduntil = "2029",
    birthdate = "154758",
    height = "180",
    weight = "75",
    attackingworkrate = "0",
    defensiveworkrate = "0",
    playerjerseyname = "Sar",
    overallrating = "93",
    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",
    skillmoves = "1",
    weakfootabilitytypecode = "4",
    acceleration = "61",
    sprintspeed = "60",
    agility = "41",
    balance = "44",
    jumping = "73",
    stamina = "41",
    strength = "74",
    reactions = "82",
    aggression = "25",
    composure = "64",
    interceptions = "24",
    positioning = "15",
    vision = "68",
    ballcontrol = "30",
    crossing = "10",
    dribbling = "8",
    finishing = "6",
    freekickaccuracy = "9",
    headingaccuracy = "10",
    longpassing = "46",
    shortpassing = "46",
    defensiveawareness = "10",
    shotpower = "59",
    longshots = "46",
    standingtackle = "10",
    slidingtackle = "10",
    volleys = "11",
    curve = "8",
    penalties = "17",
    gkdiving = "93",
    gkhandling = "91",
    gkkicking = "86",
    gkreflexes = "91",
    gkpositioning = "94",
    trait1 = "268435456",
    trait2 = "3",
    icontrait1 = "536870976",
    icontrait2 = "8",
}

local created_playerid = CreatePlayer(playerid, player_data)

local entry = {
    playerid = string.format("%d", created_playerid),
    firstname = "Edwin van der",
    lastname = "Sar",
    surname = "Sar",
    commonname = "Edwin van der Sar",
    playerjerseyname = "Sar"
}
local row = InsertDBTableRow("editedplayernames", entry)
Log(string.format("Created Player - Edwin van der Sar (ID: %s).", entry.playerid))
